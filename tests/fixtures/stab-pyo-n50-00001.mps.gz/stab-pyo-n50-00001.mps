* Source:     Pyomo MPS Writer
* Format:     Free MPS
*
NAME unknown
OBJSENSE
 MIN
ROWS
 N  obj
 L  c_u_edge_eqs(1)_
 L  c_u_edge_eqs(2)_
 L  c_u_edge_eqs(3)_
 L  c_u_edge_eqs(4)_
 L  c_u_edge_eqs(5)_
 L  c_u_edge_eqs(6)_
 L  c_u_edge_eqs(7)_
 L  c_u_edge_eqs(8)_
 L  c_u_edge_eqs(9)_
 L  c_u_edge_eqs(10)_
 L  c_u_edge_eqs(11)_
 L  c_u_edge_eqs(12)_
 L  c_u_edge_eqs(13)_
 L  c_u_edge_eqs(14)_
 L  c_u_edge_eqs(15)_
 L  c_u_edge_eqs(16)_
 L  c_u_edge_eqs(17)_
 L  c_u_edge_eqs(18)_
 L  c_u_edge_eqs(19)_
 L  c_u_edge_eqs(20)_
 L  c_u_edge_eqs(21)_
 L  c_u_edge_eqs(22)_
 L  c_u_edge_eqs(23)_
 L  c_u_edge_eqs(24)_
 L  c_u_edge_eqs(25)_
 L  c_u_edge_eqs(26)_
 L  c_u_edge_eqs(27)_
 L  c_u_edge_eqs(28)_
 L  c_u_edge_eqs(29)_
 L  c_u_edge_eqs(30)_
 L  c_u_edge_eqs(31)_
 L  c_u_edge_eqs(32)_
 L  c_u_edge_eqs(33)_
 L  c_u_edge_eqs(34)_
 L  c_u_edge_eqs(35)_
 L  c_u_edge_eqs(36)_
 L  c_u_edge_eqs(37)_
 L  c_u_edge_eqs(38)_
 L  c_u_edge_eqs(39)_
 L  c_u_edge_eqs(40)_
 L  c_u_edge_eqs(41)_
 L  c_u_edge_eqs(42)_
 L  c_u_edge_eqs(43)_
 L  c_u_edge_eqs(44)_
 L  c_u_edge_eqs(45)_
 L  c_u_edge_eqs(46)_
 L  c_u_edge_eqs(47)_
 L  c_u_edge_eqs(48)_
 L  c_u_edge_eqs(49)_
 L  c_u_edge_eqs(50)_
 L  c_u_edge_eqs(51)_
 L  c_u_edge_eqs(52)_
 L  c_u_edge_eqs(53)_
 L  c_u_edge_eqs(54)_
 L  c_u_edge_eqs(55)_
 L  c_u_edge_eqs(56)_
 L  c_u_edge_eqs(57)_
 L  c_u_edge_eqs(58)_
 L  c_u_edge_eqs(59)_
 L  c_u_edge_eqs(60)_
 L  c_u_edge_eqs(61)_
 L  c_u_edge_eqs(62)_
 L  c_u_edge_eqs(63)_
 L  c_u_edge_eqs(64)_
 L  c_u_edge_eqs(65)_
 L  c_u_edge_eqs(66)_
 L  c_u_edge_eqs(67)_
 L  c_u_edge_eqs(68)_
 L  c_u_edge_eqs(69)_
 L  c_u_edge_eqs(70)_
 L  c_u_edge_eqs(71)_
 L  c_u_edge_eqs(72)_
 L  c_u_edge_eqs(73)_
 L  c_u_edge_eqs(74)_
 L  c_u_edge_eqs(75)_
 L  c_u_edge_eqs(76)_
 L  c_u_edge_eqs(77)_
 L  c_u_edge_eqs(78)_
 L  c_u_edge_eqs(79)_
 L  c_u_edge_eqs(80)_
 L  c_u_edge_eqs(81)_
 L  c_u_edge_eqs(82)_
 L  c_u_edge_eqs(83)_
 L  c_u_edge_eqs(84)_
 L  c_u_edge_eqs(85)_
 L  c_u_edge_eqs(86)_
 L  c_u_edge_eqs(87)_
 L  c_u_edge_eqs(88)_
 L  c_u_edge_eqs(89)_
 L  c_u_edge_eqs(90)_
 L  c_u_edge_eqs(91)_
 L  c_u_edge_eqs(92)_
 L  c_u_edge_eqs(93)_
 L  c_u_edge_eqs(94)_
 L  c_u_edge_eqs(95)_
 L  c_u_edge_eqs(96)_
 L  c_u_edge_eqs(97)_
 L  c_u_edge_eqs(98)_
 L  c_u_edge_eqs(99)_
 L  c_u_edge_eqs(100)_
 L  c_u_edge_eqs(101)_
 L  c_u_edge_eqs(102)_
 L  c_u_edge_eqs(103)_
 L  c_u_edge_eqs(104)_
 L  c_u_edge_eqs(105)_
 L  c_u_edge_eqs(106)_
 L  c_u_edge_eqs(107)_
 L  c_u_edge_eqs(108)_
 L  c_u_edge_eqs(109)_
 L  c_u_edge_eqs(110)_
 L  c_u_edge_eqs(111)_
 L  c_u_edge_eqs(112)_
 L  c_u_edge_eqs(113)_
 L  c_u_edge_eqs(114)_
 L  c_u_edge_eqs(115)_
 L  c_u_edge_eqs(116)_
 L  c_u_edge_eqs(117)_
 L  c_u_edge_eqs(118)_
 L  c_u_edge_eqs(119)_
 L  c_u_edge_eqs(120)_
 L  c_u_edge_eqs(121)_
 L  c_u_edge_eqs(122)_
 L  c_u_edge_eqs(123)_
 L  c_u_edge_eqs(124)_
 L  c_u_edge_eqs(125)_
 L  c_u_edge_eqs(126)_
 L  c_u_edge_eqs(127)_
 L  c_u_edge_eqs(128)_
 L  c_u_edge_eqs(129)_
 L  c_u_edge_eqs(130)_
 L  c_u_edge_eqs(131)_
 L  c_u_edge_eqs(132)_
 L  c_u_edge_eqs(133)_
 L  c_u_edge_eqs(134)_
 L  c_u_edge_eqs(135)_
 L  c_u_edge_eqs(136)_
 L  c_u_edge_eqs(137)_
 L  c_u_edge_eqs(138)_
 L  c_u_edge_eqs(139)_
 L  c_u_edge_eqs(140)_
 L  c_u_edge_eqs(141)_
 L  c_u_edge_eqs(142)_
 L  c_u_edge_eqs(143)_
 L  c_u_edge_eqs(144)_
 L  c_u_edge_eqs(145)_
 L  c_u_edge_eqs(146)_
 L  c_u_edge_eqs(147)_
 L  c_u_edge_eqs(148)_
 L  c_u_edge_eqs(149)_
 L  c_u_edge_eqs(150)_
 L  c_u_edge_eqs(151)_
 L  c_u_edge_eqs(152)_
 L  c_u_edge_eqs(153)_
 L  c_u_edge_eqs(154)_
 L  c_u_edge_eqs(155)_
 L  c_u_edge_eqs(156)_
 L  c_u_edge_eqs(157)_
 L  c_u_edge_eqs(158)_
 L  c_u_edge_eqs(159)_
 L  c_u_edge_eqs(160)_
 L  c_u_edge_eqs(161)_
 L  c_u_edge_eqs(162)_
 L  c_u_edge_eqs(163)_
 L  c_u_edge_eqs(164)_
 L  c_u_edge_eqs(165)_
 L  c_u_edge_eqs(166)_
 L  c_u_edge_eqs(167)_
 L  c_u_edge_eqs(168)_
 L  c_u_edge_eqs(169)_
 L  c_u_edge_eqs(170)_
 L  c_u_edge_eqs(171)_
 L  c_u_edge_eqs(172)_
 L  c_u_edge_eqs(173)_
 L  c_u_edge_eqs(174)_
 L  c_u_edge_eqs(175)_
 L  c_u_edge_eqs(176)_
 L  c_u_edge_eqs(177)_
 L  c_u_edge_eqs(178)_
 L  c_u_edge_eqs(179)_
 L  c_u_edge_eqs(180)_
 L  c_u_edge_eqs(181)_
 L  c_u_edge_eqs(182)_
 L  c_u_edge_eqs(183)_
 L  c_u_edge_eqs(184)_
 L  c_u_edge_eqs(185)_
 L  c_u_edge_eqs(186)_
 L  c_u_edge_eqs(187)_
 L  c_u_edge_eqs(188)_
 L  c_u_edge_eqs(189)_
 L  c_u_edge_eqs(190)_
 L  c_u_edge_eqs(191)_
 L  c_u_edge_eqs(192)_
 L  c_u_edge_eqs(193)_
 L  c_u_edge_eqs(194)_
 L  c_u_edge_eqs(195)_
 L  c_u_edge_eqs(196)_
 L  c_u_edge_eqs(197)_
 L  c_u_edge_eqs(198)_
 L  c_u_edge_eqs(199)_
 L  c_u_edge_eqs(200)_
 L  c_u_edge_eqs(201)_
 L  c_u_edge_eqs(202)_
 L  c_u_edge_eqs(203)_
 L  c_u_edge_eqs(204)_
 L  c_u_edge_eqs(205)_
 L  c_u_edge_eqs(206)_
 L  c_u_edge_eqs(207)_
 L  c_u_edge_eqs(208)_
 L  c_u_edge_eqs(209)_
 L  c_u_edge_eqs(210)_
 L  c_u_edge_eqs(211)_
 L  c_u_edge_eqs(212)_
 L  c_u_edge_eqs(213)_
 L  c_u_edge_eqs(214)_
 L  c_u_edge_eqs(215)_
 L  c_u_edge_eqs(216)_
 L  c_u_edge_eqs(217)_
 L  c_u_edge_eqs(218)_
 L  c_u_edge_eqs(219)_
 L  c_u_edge_eqs(220)_
 L  c_u_edge_eqs(221)_
 L  c_u_edge_eqs(222)_
 L  c_u_edge_eqs(223)_
 L  c_u_edge_eqs(224)_
 L  c_u_edge_eqs(225)_
 L  c_u_edge_eqs(226)_
 L  c_u_edge_eqs(227)_
 L  c_u_edge_eqs(228)_
 L  c_u_edge_eqs(229)_
 L  c_u_edge_eqs(230)_
 L  c_u_edge_eqs(231)_
 L  c_u_edge_eqs(232)_
 L  c_u_edge_eqs(233)_
 L  c_u_edge_eqs(234)_
 L  c_u_edge_eqs(235)_
 L  c_u_edge_eqs(236)_
 L  c_u_edge_eqs(237)_
 L  c_u_edge_eqs(238)_
 L  c_u_edge_eqs(239)_
 L  c_u_edge_eqs(240)_
 L  c_u_edge_eqs(241)_
 L  c_u_edge_eqs(242)_
 L  c_u_edge_eqs(243)_
 L  c_u_edge_eqs(244)_
 L  c_u_edge_eqs(245)_
 L  c_u_edge_eqs(246)_
 L  c_u_edge_eqs(247)_
 L  c_u_edge_eqs(248)_
 L  c_u_edge_eqs(249)_
 L  c_u_edge_eqs(250)_
 L  c_u_edge_eqs(251)_
 L  c_u_edge_eqs(252)_
 L  c_u_edge_eqs(253)_
 L  c_u_edge_eqs(254)_
 L  c_u_edge_eqs(255)_
 L  c_u_edge_eqs(256)_
 L  c_u_edge_eqs(257)_
 L  c_u_edge_eqs(258)_
 L  c_u_edge_eqs(259)_
 L  c_u_edge_eqs(260)_
 L  c_u_edge_eqs(261)_
 L  c_u_edge_eqs(262)_
 L  c_u_edge_eqs(263)_
 L  c_u_edge_eqs(264)_
 L  c_u_edge_eqs(265)_
 L  c_u_edge_eqs(266)_
 L  c_u_edge_eqs(267)_
 L  c_u_edge_eqs(268)_
 L  c_u_edge_eqs(269)_
 L  c_u_edge_eqs(270)_
 L  c_u_edge_eqs(271)_
 L  c_u_edge_eqs(272)_
 L  c_u_edge_eqs(273)_
 L  c_u_edge_eqs(274)_
 L  c_u_edge_eqs(275)_
 L  c_u_edge_eqs(276)_
 L  c_u_edge_eqs(277)_
 L  c_u_edge_eqs(278)_
 L  c_u_edge_eqs(279)_
 L  c_u_edge_eqs(280)_
 L  c_u_edge_eqs(281)_
 L  c_u_edge_eqs(282)_
 L  c_u_edge_eqs(283)_
 L  c_u_edge_eqs(284)_
 L  c_u_edge_eqs(285)_
 L  c_u_edge_eqs(286)_
 L  c_u_edge_eqs(287)_
 L  c_u_edge_eqs(288)_
 L  c_u_edge_eqs(289)_
 L  c_u_edge_eqs(290)_
 L  c_u_edge_eqs(291)_
 L  c_u_edge_eqs(292)_
 L  c_u_edge_eqs(293)_
 L  c_u_edge_eqs(294)_
 L  c_u_edge_eqs(295)_
 L  c_u_edge_eqs(296)_
 L  c_u_edge_eqs(297)_
 L  c_u_edge_eqs(298)_
 L  c_u_edge_eqs(299)_
 L  c_u_edge_eqs(300)_
 L  c_u_edge_eqs(301)_
 L  c_u_edge_eqs(302)_
 L  c_u_edge_eqs(303)_
 L  c_u_edge_eqs(304)_
 L  c_u_edge_eqs(305)_
 L  c_u_edge_eqs(306)_
 L  c_u_edge_eqs(307)_
 L  c_u_edge_eqs(308)_
 L  c_u_edge_eqs(309)_
 L  c_u_edge_eqs(310)_
 L  c_u_edge_eqs(311)_
 L  c_u_edge_eqs(312)_
 L  c_u_edge_eqs(313)_
 L  c_u_edge_eqs(314)_
 L  c_u_edge_eqs(315)_
 L  c_u_edge_eqs(316)_
 L  c_u_edge_eqs(317)_
 L  c_u_edge_eqs(318)_
 L  c_u_edge_eqs(319)_
 L  c_u_edge_eqs(320)_
 L  c_u_edge_eqs(321)_
 L  c_u_edge_eqs(322)_
 L  c_u_edge_eqs(323)_
 L  c_u_edge_eqs(324)_
 L  c_u_edge_eqs(325)_
 L  c_u_edge_eqs(326)_
 L  c_u_edge_eqs(327)_
 L  c_u_edge_eqs(328)_
 L  c_u_edge_eqs(329)_
 L  c_u_edge_eqs(330)_
 L  c_u_edge_eqs(331)_
 L  c_u_edge_eqs(332)_
 L  c_u_edge_eqs(333)_
 L  c_u_edge_eqs(334)_
 L  c_u_edge_eqs(335)_
 L  c_u_edge_eqs(336)_
 L  c_u_edge_eqs(337)_
 L  c_u_edge_eqs(338)_
 L  c_u_edge_eqs(339)_
 L  c_u_edge_eqs(340)_
 L  c_u_edge_eqs(341)_
 L  c_u_edge_eqs(342)_
 L  c_u_edge_eqs(343)_
 L  c_u_edge_eqs(344)_
 L  c_u_edge_eqs(345)_
 L  c_u_edge_eqs(346)_
 L  c_u_edge_eqs(347)_
 L  c_u_edge_eqs(348)_
 L  c_u_edge_eqs(349)_
 L  c_u_edge_eqs(350)_
 L  c_u_edge_eqs(351)_
 L  c_u_edge_eqs(352)_
 L  c_u_edge_eqs(353)_
 L  c_u_edge_eqs(354)_
 L  c_u_edge_eqs(355)_
 L  c_u_edge_eqs(356)_
 L  c_u_edge_eqs(357)_
 L  c_u_edge_eqs(358)_
 L  c_u_edge_eqs(359)_
 L  c_u_edge_eqs(360)_
 L  c_u_edge_eqs(361)_
 L  c_u_edge_eqs(362)_
 L  c_u_edge_eqs(363)_
 L  c_u_edge_eqs(364)_
 L  c_u_edge_eqs(365)_
 L  c_u_edge_eqs(366)_
 L  c_u_edge_eqs(367)_
 L  c_u_edge_eqs(368)_
 L  c_u_edge_eqs(369)_
 L  c_u_edge_eqs(370)_
 L  c_u_edge_eqs(371)_
 L  c_u_edge_eqs(372)_
 L  c_u_edge_eqs(373)_
 L  c_u_edge_eqs(374)_
 L  c_u_edge_eqs(375)_
 L  c_u_edge_eqs(376)_
 L  c_u_edge_eqs(377)_
 L  c_u_edge_eqs(378)_
 L  c_u_edge_eqs(379)_
 L  c_u_edge_eqs(380)_
 L  c_u_edge_eqs(381)_
 L  c_u_edge_eqs(382)_
 L  c_u_edge_eqs(383)_
 L  c_u_edge_eqs(384)_
 L  c_u_edge_eqs(385)_
 L  c_u_edge_eqs(386)_
 L  c_u_edge_eqs(387)_
 L  c_u_edge_eqs(388)_
 L  c_u_edge_eqs(389)_
 L  c_u_edge_eqs(390)_
 L  c_u_edge_eqs(391)_
 L  c_u_edge_eqs(392)_
 L  c_u_edge_eqs(393)_
 L  c_u_edge_eqs(394)_
 L  c_u_edge_eqs(395)_
 L  c_u_edge_eqs(396)_
 L  c_u_edge_eqs(397)_
 L  c_u_edge_eqs(398)_
 L  c_u_edge_eqs(399)_
 L  c_u_edge_eqs(400)_
 L  c_u_edge_eqs(401)_
 L  c_u_edge_eqs(402)_
 L  c_u_edge_eqs(403)_
 L  c_u_edge_eqs(404)_
 L  c_u_edge_eqs(405)_
 L  c_u_edge_eqs(406)_
 L  c_u_edge_eqs(407)_
 L  c_u_edge_eqs(408)_
 L  c_u_edge_eqs(409)_
 L  c_u_edge_eqs(410)_
 L  c_u_edge_eqs(411)_
 L  c_u_edge_eqs(412)_
 L  c_u_edge_eqs(413)_
 L  c_u_edge_eqs(414)_
 L  c_u_edge_eqs(415)_
 L  c_u_edge_eqs(416)_
 L  c_u_edge_eqs(417)_
 L  c_u_edge_eqs(418)_
 L  c_u_edge_eqs(419)_
 L  c_u_edge_eqs(420)_
 L  c_u_edge_eqs(421)_
 L  c_u_edge_eqs(422)_
 L  c_u_edge_eqs(423)_
 L  c_u_edge_eqs(424)_
 L  c_u_edge_eqs(425)_
 L  c_u_edge_eqs(426)_
 L  c_u_edge_eqs(427)_
 L  c_u_edge_eqs(428)_
 L  c_u_edge_eqs(429)_
 L  c_u_edge_eqs(430)_
 L  c_u_edge_eqs(431)_
 L  c_u_edge_eqs(432)_
 L  c_u_edge_eqs(433)_
 L  c_u_edge_eqs(434)_
 L  c_u_edge_eqs(435)_
 L  c_u_edge_eqs(436)_
 L  c_u_edge_eqs(437)_
 L  c_u_edge_eqs(438)_
 L  c_u_edge_eqs(439)_
 L  c_u_edge_eqs(440)_
 L  c_u_edge_eqs(441)_
 L  c_u_edge_eqs(442)_
 L  c_u_edge_eqs(443)_
 L  c_u_edge_eqs(444)_
 L  c_u_edge_eqs(445)_
 L  c_u_edge_eqs(446)_
 L  c_u_edge_eqs(447)_
 L  c_u_edge_eqs(448)_
 L  c_u_edge_eqs(449)_
 L  c_u_edge_eqs(450)_
 L  c_u_edge_eqs(451)_
 L  c_u_edge_eqs(452)_
 L  c_u_edge_eqs(453)_
 L  c_u_edge_eqs(454)_
 L  c_u_edge_eqs(455)_
 L  c_u_edge_eqs(456)_
 L  c_u_edge_eqs(457)_
 L  c_u_edge_eqs(458)_
 L  c_u_edge_eqs(459)_
 L  c_u_edge_eqs(460)_
 L  c_u_edge_eqs(461)_
 L  c_u_edge_eqs(462)_
 L  c_u_edge_eqs(463)_
 L  c_u_edge_eqs(464)_
 L  c_u_edge_eqs(465)_
 L  c_u_edge_eqs(466)_
 L  c_u_edge_eqs(467)_
 L  c_u_edge_eqs(468)_
 L  c_u_edge_eqs(469)_
 L  c_u_edge_eqs(470)_
 L  c_u_edge_eqs(471)_
 L  c_u_edge_eqs(472)_
 L  c_u_edge_eqs(473)_
 L  c_u_edge_eqs(474)_
 L  c_u_edge_eqs(475)_
 L  c_u_edge_eqs(476)_
 L  c_u_edge_eqs(477)_
 L  c_u_edge_eqs(478)_
 L  c_u_edge_eqs(479)_
 L  c_u_edge_eqs(480)_
 L  c_u_edge_eqs(481)_
 L  c_u_edge_eqs(482)_
 L  c_u_edge_eqs(483)_
 L  c_u_edge_eqs(484)_
 L  c_u_edge_eqs(485)_
 L  c_u_edge_eqs(486)_
 L  c_u_edge_eqs(487)_
 L  c_u_edge_eqs(488)_
 L  c_u_edge_eqs(489)_
 L  c_u_edge_eqs(490)_
 L  c_u_edge_eqs(491)_
 L  c_u_edge_eqs(492)_
 L  c_u_edge_eqs(493)_
 L  c_u_edge_eqs(494)_
 L  c_u_edge_eqs(495)_
 L  c_u_edge_eqs(496)_
 L  c_u_edge_eqs(497)_
 L  c_u_edge_eqs(498)_
 L  c_u_edge_eqs(499)_
 L  c_u_edge_eqs(500)_
 L  c_u_edge_eqs(501)_
 L  c_u_edge_eqs(502)_
 L  c_u_edge_eqs(503)_
 L  c_u_edge_eqs(504)_
 L  c_u_edge_eqs(505)_
 L  c_u_edge_eqs(506)_
 L  c_u_edge_eqs(507)_
 L  c_u_edge_eqs(508)_
 L  c_u_edge_eqs(509)_
 L  c_u_edge_eqs(510)_
 L  c_u_edge_eqs(511)_
 L  c_u_edge_eqs(512)_
 L  c_u_edge_eqs(513)_
 L  c_u_edge_eqs(514)_
 L  c_u_edge_eqs(515)_
 L  c_u_edge_eqs(516)_
 L  c_u_edge_eqs(517)_
 L  c_u_edge_eqs(518)_
 L  c_u_edge_eqs(519)_
 L  c_u_edge_eqs(520)_
 L  c_u_edge_eqs(521)_
 L  c_u_edge_eqs(522)_
 L  c_u_edge_eqs(523)_
 L  c_u_edge_eqs(524)_
 L  c_u_edge_eqs(525)_
 L  c_u_edge_eqs(526)_
 L  c_u_edge_eqs(527)_
 L  c_u_edge_eqs(528)_
 L  c_u_edge_eqs(529)_
 L  c_u_edge_eqs(530)_
 L  c_u_edge_eqs(531)_
 L  c_u_edge_eqs(532)_
 L  c_u_edge_eqs(533)_
 L  c_u_edge_eqs(534)_
 L  c_u_edge_eqs(535)_
 L  c_u_edge_eqs(536)_
 L  c_u_edge_eqs(537)_
 L  c_u_edge_eqs(538)_
 L  c_u_edge_eqs(539)_
 L  c_u_edge_eqs(540)_
 L  c_u_edge_eqs(541)_
 L  c_u_edge_eqs(542)_
 L  c_u_edge_eqs(543)_
 L  c_u_edge_eqs(544)_
 L  c_u_edge_eqs(545)_
 L  c_u_edge_eqs(546)_
 L  c_u_edge_eqs(547)_
 L  c_u_edge_eqs(548)_
 L  c_u_edge_eqs(549)_
 L  c_u_edge_eqs(550)_
 L  c_u_edge_eqs(551)_
 L  c_u_edge_eqs(552)_
 L  c_u_edge_eqs(553)_
 L  c_u_edge_eqs(554)_
 L  c_u_edge_eqs(555)_
 L  c_u_edge_eqs(556)_
 L  c_u_edge_eqs(557)_
 L  c_u_edge_eqs(558)_
 L  c_u_edge_eqs(559)_
 L  c_u_edge_eqs(560)_
 L  c_u_edge_eqs(561)_
 L  c_u_edge_eqs(562)_
 L  c_u_edge_eqs(563)_
 L  c_u_edge_eqs(564)_
 L  c_u_edge_eqs(565)_
 L  c_u_edge_eqs(566)_
 L  c_u_edge_eqs(567)_
 L  c_u_edge_eqs(568)_
 L  c_u_edge_eqs(569)_
 L  c_u_edge_eqs(570)_
 L  c_u_edge_eqs(571)_
 L  c_u_edge_eqs(572)_
 L  c_u_edge_eqs(573)_
 L  c_u_edge_eqs(574)_
 L  c_u_edge_eqs(575)_
 L  c_u_edge_eqs(576)_
 L  c_u_edge_eqs(577)_
 L  c_u_edge_eqs(578)_
 L  c_u_edge_eqs(579)_
 L  c_u_edge_eqs(580)_
 L  c_u_edge_eqs(581)_
 L  c_u_edge_eqs(582)_
 L  c_u_edge_eqs(583)_
 L  c_u_edge_eqs(584)_
 L  c_u_edge_eqs(585)_
 L  c_u_edge_eqs(586)_
 L  c_u_edge_eqs(587)_
 L  c_u_clique_eqs(1)_
 L  c_u_clique_eqs(2)_
 L  c_u_clique_eqs(3)_
 L  c_u_clique_eqs(4)_
 L  c_u_clique_eqs(5)_
 L  c_u_clique_eqs(6)_
 L  c_u_clique_eqs(7)_
 L  c_u_clique_eqs(8)_
 L  c_u_clique_eqs(9)_
 L  c_u_clique_eqs(10)_
 L  c_u_clique_eqs(11)_
 L  c_u_clique_eqs(12)_
 L  c_u_clique_eqs(13)_
 L  c_u_clique_eqs(14)_
 L  c_u_clique_eqs(15)_
 L  c_u_clique_eqs(16)_
 L  c_u_clique_eqs(17)_
 L  c_u_clique_eqs(18)_
 L  c_u_clique_eqs(19)_
 L  c_u_clique_eqs(20)_
 L  c_u_clique_eqs(21)_
 L  c_u_clique_eqs(22)_
 L  c_u_clique_eqs(23)_
 L  c_u_clique_eqs(24)_
 L  c_u_clique_eqs(25)_
 L  c_u_clique_eqs(26)_
 L  c_u_clique_eqs(27)_
 L  c_u_clique_eqs(28)_
 L  c_u_clique_eqs(29)_
 L  c_u_clique_eqs(30)_
 L  c_u_clique_eqs(31)_
 L  c_u_clique_eqs(32)_
 L  c_u_clique_eqs(33)_
 L  c_u_clique_eqs(34)_
 L  c_u_clique_eqs(35)_
 L  c_u_clique_eqs(36)_
 L  c_u_clique_eqs(37)_
 L  c_u_clique_eqs(38)_
 L  c_u_clique_eqs(39)_
 L  c_u_clique_eqs(40)_
 L  c_u_clique_eqs(41)_
 L  c_u_clique_eqs(42)_
 L  c_u_clique_eqs(43)_
 L  c_u_clique_eqs(44)_
 L  c_u_clique_eqs(45)_
 L  c_u_clique_eqs(46)_
 L  c_u_clique_eqs(47)_
 L  c_u_clique_eqs(48)_
 L  c_u_clique_eqs(49)_
 L  c_u_clique_eqs(50)_
 L  c_u_clique_eqs(51)_
 L  c_u_clique_eqs(52)_
 L  c_u_clique_eqs(53)_
 L  c_u_clique_eqs(54)_
 L  c_u_clique_eqs(55)_
 L  c_u_clique_eqs(56)_
 L  c_u_clique_eqs(57)_
 L  c_u_clique_eqs(58)_
 L  c_u_clique_eqs(59)_
 L  c_u_clique_eqs(60)_
 L  c_u_clique_eqs(61)_
 L  c_u_clique_eqs(62)_
 L  c_u_clique_eqs(63)_
 L  c_u_clique_eqs(64)_
 L  c_u_clique_eqs(65)_
 L  c_u_clique_eqs(66)_
 L  c_u_clique_eqs(67)_
 L  c_u_clique_eqs(68)_
 L  c_u_clique_eqs(69)_
 L  c_u_clique_eqs(70)_
 L  c_u_clique_eqs(71)_
 L  c_u_clique_eqs(72)_
 L  c_u_clique_eqs(73)_
 L  c_u_clique_eqs(74)_
 L  c_u_clique_eqs(75)_
 L  c_u_clique_eqs(76)_
 L  c_u_clique_eqs(77)_
 L  c_u_clique_eqs(78)_
 L  c_u_clique_eqs(79)_
 L  c_u_clique_eqs(80)_
 L  c_u_clique_eqs(81)_
 L  c_u_clique_eqs(82)_
 L  c_u_clique_eqs(83)_
 L  c_u_clique_eqs(84)_
 L  c_u_clique_eqs(85)_
 L  c_u_clique_eqs(86)_
 L  c_u_clique_eqs(87)_
 L  c_u_clique_eqs(88)_
 L  c_u_clique_eqs(89)_
 L  c_u_clique_eqs(90)_
 L  c_u_clique_eqs(91)_
 L  c_u_clique_eqs(92)_
 L  c_u_clique_eqs(93)_
 L  c_u_clique_eqs(94)_
 L  c_u_clique_eqs(95)_
 L  c_u_clique_eqs(96)_
 L  c_u_clique_eqs(97)_
 L  c_u_clique_eqs(98)_
 L  c_u_clique_eqs(99)_
 L  c_u_clique_eqs(100)_
 L  c_u_clique_eqs(101)_
 L  c_u_clique_eqs(102)_
 L  c_u_clique_eqs(103)_
 L  c_u_clique_eqs(104)_
 L  c_u_clique_eqs(105)_
 L  c_u_clique_eqs(106)_
 L  c_u_clique_eqs(107)_
 L  c_u_clique_eqs(108)_
 L  c_u_clique_eqs(109)_
 L  c_u_clique_eqs(110)_
 L  c_u_clique_eqs(111)_
 L  c_u_clique_eqs(112)_
 L  c_u_clique_eqs(113)_
 L  c_u_clique_eqs(114)_
 L  c_u_clique_eqs(115)_
 L  c_u_clique_eqs(116)_
 L  c_u_clique_eqs(117)_
 L  c_u_clique_eqs(118)_
 L  c_u_clique_eqs(119)_
 L  c_u_clique_eqs(120)_
 L  c_u_clique_eqs(121)_
 L  c_u_clique_eqs(122)_
 L  c_u_clique_eqs(123)_
 L  c_u_clique_eqs(124)_
 L  c_u_clique_eqs(125)_
 L  c_u_clique_eqs(126)_
 L  c_u_clique_eqs(127)_
 L  c_u_clique_eqs(128)_
 L  c_u_clique_eqs(129)_
 L  c_u_clique_eqs(130)_
 L  c_u_clique_eqs(131)_
 L  c_u_clique_eqs(132)_
 L  c_u_clique_eqs(133)_
 L  c_u_clique_eqs(134)_
 L  c_u_clique_eqs(135)_
 L  c_u_clique_eqs(136)_
 L  c_u_clique_eqs(137)_
 L  c_u_clique_eqs(138)_
 L  c_u_clique_eqs(139)_
 L  c_u_clique_eqs(140)_
 L  c_u_clique_eqs(141)_
 L  c_u_clique_eqs(142)_
 L  c_u_clique_eqs(143)_
 L  c_u_clique_eqs(144)_
 L  c_u_clique_eqs(145)_
 L  c_u_clique_eqs(146)_
 L  c_u_clique_eqs(147)_
 L  c_u_clique_eqs(148)_
 L  c_u_clique_eqs(149)_
 L  c_u_clique_eqs(150)_
 L  c_u_clique_eqs(151)_
 L  c_u_clique_eqs(152)_
 L  c_u_clique_eqs(153)_
 L  c_u_clique_eqs(154)_
 L  c_u_clique_eqs(155)_
 L  c_u_clique_eqs(156)_
 L  c_u_clique_eqs(157)_
 L  c_u_clique_eqs(158)_
 L  c_u_clique_eqs(159)_
 L  c_u_clique_eqs(160)_
 L  c_u_clique_eqs(161)_
 L  c_u_clique_eqs(162)_
 L  c_u_clique_eqs(163)_
 L  c_u_clique_eqs(164)_
 L  c_u_clique_eqs(165)_
 L  c_u_clique_eqs(166)_
 L  c_u_clique_eqs(167)_
 L  c_u_clique_eqs(168)_
 L  c_u_clique_eqs(169)_
 L  c_u_clique_eqs(170)_
 L  c_u_clique_eqs(171)_
 L  c_u_clique_eqs(172)_
 L  c_u_clique_eqs(173)_
 L  c_u_clique_eqs(174)_
 L  c_u_clique_eqs(175)_
 L  c_u_clique_eqs(176)_
 L  c_u_clique_eqs(177)_
 L  c_u_clique_eqs(178)_
 L  c_u_clique_eqs(179)_
 L  c_u_clique_eqs(180)_
 L  c_u_clique_eqs(181)_
 L  c_u_clique_eqs(182)_
 L  c_u_clique_eqs(183)_
 L  c_u_clique_eqs(184)_
 L  c_u_clique_eqs(185)_
 L  c_u_clique_eqs(186)_
 L  c_u_clique_eqs(187)_
 L  c_u_clique_eqs(188)_
 L  c_u_clique_eqs(189)_
 L  c_u_clique_eqs(190)_
 L  c_u_clique_eqs(191)_
 L  c_u_clique_eqs(192)_
 L  c_u_clique_eqs(193)_
 L  c_u_clique_eqs(194)_
 L  c_u_clique_eqs(195)_
 L  c_u_clique_eqs(196)_
 L  c_u_clique_eqs(197)_
 L  c_u_clique_eqs(198)_
 L  c_u_clique_eqs(199)_
 L  c_u_clique_eqs(200)_
 L  c_u_clique_eqs(201)_
 L  c_u_clique_eqs(202)_
 L  c_u_clique_eqs(203)_
 L  c_u_clique_eqs(204)_
 L  c_u_clique_eqs(205)_
 L  c_u_clique_eqs(206)_
 L  c_u_clique_eqs(207)_
 L  c_u_clique_eqs(208)_
 L  c_u_clique_eqs(209)_
 L  c_u_clique_eqs(210)_
 L  c_u_clique_eqs(211)_
 L  c_u_clique_eqs(212)_
 L  c_u_clique_eqs(213)_
 L  c_u_clique_eqs(214)_
 L  c_u_clique_eqs(215)_
 L  c_u_clique_eqs(216)_
 L  c_u_clique_eqs(217)_
 L  c_u_clique_eqs(218)_
 L  c_u_clique_eqs(219)_
 L  c_u_clique_eqs(220)_
 L  c_u_clique_eqs(221)_
 L  c_u_clique_eqs(222)_
 L  c_u_clique_eqs(223)_
 L  c_u_clique_eqs(224)_
 L  c_u_clique_eqs(225)_
 L  c_u_clique_eqs(226)_
 L  c_u_clique_eqs(227)_
 L  c_u_clique_eqs(228)_
 L  c_u_clique_eqs(229)_
 L  c_u_clique_eqs(230)_
 L  c_u_clique_eqs(231)_
 L  c_u_clique_eqs(232)_
 L  c_u_clique_eqs(233)_
 L  c_u_clique_eqs(234)_
 L  c_u_clique_eqs(235)_
 L  c_u_clique_eqs(236)_
 L  c_u_clique_eqs(237)_
 L  c_u_clique_eqs(238)_
 L  c_u_clique_eqs(239)_
 L  c_u_clique_eqs(240)_
 L  c_u_clique_eqs(241)_
 L  c_u_clique_eqs(242)_
 L  c_u_clique_eqs(243)_
 L  c_u_clique_eqs(244)_
 L  c_u_clique_eqs(245)_
 L  c_u_clique_eqs(246)_
 L  c_u_clique_eqs(247)_
 L  c_u_clique_eqs(248)_
 L  c_u_clique_eqs(249)_
 L  c_u_clique_eqs(250)_
 L  c_u_clique_eqs(251)_
 L  c_u_clique_eqs(252)_
 L  c_u_clique_eqs(253)_
 L  c_u_clique_eqs(254)_
 L  c_u_clique_eqs(255)_
 L  c_u_clique_eqs(256)_
 L  c_u_clique_eqs(257)_
 L  c_u_clique_eqs(258)_
 L  c_u_clique_eqs(259)_
 L  c_u_clique_eqs(260)_
 L  c_u_clique_eqs(261)_
 L  c_u_clique_eqs(262)_
 L  c_u_clique_eqs(263)_
 L  c_u_clique_eqs(264)_
 L  c_u_clique_eqs(265)_
 L  c_u_clique_eqs(266)_
 L  c_u_clique_eqs(267)_
 L  c_u_clique_eqs(268)_
 L  c_u_clique_eqs(269)_
 L  c_u_clique_eqs(270)_
 L  c_u_clique_eqs(271)_
 L  c_u_clique_eqs(272)_
 L  c_u_clique_eqs(273)_
 L  c_u_clique_eqs(274)_
 L  c_u_clique_eqs(275)_
 L  c_u_clique_eqs(276)_
 L  c_u_clique_eqs(277)_
 L  c_u_clique_eqs(278)_
 L  c_u_clique_eqs(279)_
 L  c_u_clique_eqs(280)_
 L  c_u_clique_eqs(281)_
 L  c_u_clique_eqs(282)_
 L  c_u_clique_eqs(283)_
 L  c_u_clique_eqs(284)_
 L  c_u_clique_eqs(285)_
 L  c_u_clique_eqs(286)_
 L  c_u_clique_eqs(287)_
 L  c_u_clique_eqs(288)_
 L  c_u_clique_eqs(289)_
 L  c_u_clique_eqs(290)_
 L  c_u_clique_eqs(291)_
 L  c_u_clique_eqs(292)_
 L  c_u_clique_eqs(293)_
 L  c_u_clique_eqs(294)_
 L  c_u_clique_eqs(295)_
 L  c_u_clique_eqs(296)_
 L  c_u_clique_eqs(297)_
 L  c_u_clique_eqs(298)_
 L  c_u_clique_eqs(299)_
 L  c_u_clique_eqs(300)_
 L  c_u_clique_eqs(301)_
 L  c_u_clique_eqs(302)_
 L  c_u_clique_eqs(303)_
 L  c_u_clique_eqs(304)_
 L  c_u_clique_eqs(305)_
 L  c_u_clique_eqs(306)_
 L  c_u_clique_eqs(307)_
 L  c_u_clique_eqs(308)_
 L  c_u_clique_eqs(309)_
 L  c_u_clique_eqs(310)_
 L  c_u_clique_eqs(311)_
 L  c_u_clique_eqs(312)_
 L  c_u_clique_eqs(313)_
 L  c_u_clique_eqs(314)_
 L  c_u_clique_eqs(315)_
 L  c_u_clique_eqs(316)_
 L  c_u_clique_eqs(317)_
 L  c_u_clique_eqs(318)_
 L  c_u_clique_eqs(319)_
 L  c_u_clique_eqs(320)_
 L  c_u_clique_eqs(321)_
 L  c_u_clique_eqs(322)_
 L  c_u_clique_eqs(323)_
 L  c_u_clique_eqs(324)_
 L  c_u_clique_eqs(325)_
 L  c_u_clique_eqs(326)_
 L  c_u_clique_eqs(327)_
 L  c_u_clique_eqs(328)_
 L  c_u_clique_eqs(329)_
COLUMNS
     x(0) obj -9.4000000000000004
     x(0) c_u_edge_eqs(1)_ 1
     x(0) c_u_edge_eqs(2)_ 1
     x(0) c_u_edge_eqs(3)_ 1
     x(0) c_u_edge_eqs(4)_ 1
     x(0) c_u_edge_eqs(5)_ 1
     x(0) c_u_edge_eqs(6)_ 1
     x(0) c_u_edge_eqs(7)_ 1
     x(0) c_u_edge_eqs(8)_ 1
     x(0) c_u_edge_eqs(9)_ 1
     x(0) c_u_edge_eqs(10)_ 1
     x(0) c_u_edge_eqs(11)_ 1
     x(0) c_u_edge_eqs(12)_ 1
     x(0) c_u_edge_eqs(13)_ 1
     x(0) c_u_edge_eqs(14)_ 1
     x(0) c_u_edge_eqs(15)_ 1
     x(0) c_u_edge_eqs(16)_ 1
     x(0) c_u_edge_eqs(17)_ 1
     x(0) c_u_edge_eqs(18)_ 1
     x(0) c_u_edge_eqs(19)_ 1
     x(0) c_u_edge_eqs(20)_ 1
     x(0) c_u_edge_eqs(21)_ 1
     x(0) c_u_edge_eqs(22)_ 1
     x(0) c_u_edge_eqs(23)_ 1
     x(0) c_u_edge_eqs(24)_ 1
     x(0) c_u_edge_eqs(25)_ 1
     x(0) c_u_clique_eqs(14)_ 1
     x(0) c_u_clique_eqs(15)_ 1
     x(0) c_u_clique_eqs(29)_ 1
     x(0) c_u_clique_eqs(43)_ 1
     x(0) c_u_clique_eqs(80)_ 1
     x(0) c_u_clique_eqs(81)_ 1
     x(0) c_u_clique_eqs(93)_ 1
     x(0) c_u_clique_eqs(117)_ 1
     x(0) c_u_clique_eqs(138)_ 1
     x(0) c_u_clique_eqs(144)_ 1
     x(0) c_u_clique_eqs(151)_ 1
     x(0) c_u_clique_eqs(166)_ 1
     x(0) c_u_clique_eqs(185)_ 1
     x(0) c_u_clique_eqs(186)_ 1
     x(0) c_u_clique_eqs(189)_ 1
     x(0) c_u_clique_eqs(197)_ 1
     x(0) c_u_clique_eqs(198)_ 1
     x(0) c_u_clique_eqs(216)_ 1
     x(0) c_u_clique_eqs(217)_ 1
     x(0) c_u_clique_eqs(218)_ 1
     x(0) c_u_clique_eqs(219)_ 1
     x(0) c_u_clique_eqs(225)_ 1
     x(0) c_u_clique_eqs(226)_ 1
     x(0) c_u_clique_eqs(229)_ 1
     x(0) c_u_clique_eqs(243)_ 1
     x(0) c_u_clique_eqs(244)_ 1
     x(0) c_u_clique_eqs(245)_ 1
     x(0) c_u_clique_eqs(257)_ 1
     x(0) c_u_clique_eqs(263)_ 1
     x(0) c_u_clique_eqs(277)_ 1
     x(0) c_u_clique_eqs(289)_ 1
     x(0) c_u_clique_eqs(290)_ 1
     x(0) c_u_clique_eqs(300)_ 1
     x(1) obj -11.25
     x(1) c_u_edge_eqs(26)_ 1
     x(1) c_u_edge_eqs(27)_ 1
     x(1) c_u_edge_eqs(28)_ 1
     x(1) c_u_edge_eqs(29)_ 1
     x(1) c_u_edge_eqs(30)_ 1
     x(1) c_u_edge_eqs(31)_ 1
     x(1) c_u_edge_eqs(32)_ 1
     x(1) c_u_edge_eqs(33)_ 1
     x(1) c_u_edge_eqs(34)_ 1
     x(1) c_u_edge_eqs(35)_ 1
     x(1) c_u_edge_eqs(36)_ 1
     x(1) c_u_edge_eqs(37)_ 1
     x(1) c_u_edge_eqs(38)_ 1
     x(1) c_u_edge_eqs(39)_ 1
     x(1) c_u_edge_eqs(40)_ 1
     x(1) c_u_edge_eqs(41)_ 1
     x(1) c_u_edge_eqs(42)_ 1
     x(1) c_u_edge_eqs(43)_ 1
     x(1) c_u_edge_eqs(44)_ 1
     x(1) c_u_edge_eqs(45)_ 1
     x(1) c_u_edge_eqs(46)_ 1
     x(1) c_u_edge_eqs(47)_ 1
     x(1) c_u_edge_eqs(48)_ 1
     x(1) c_u_edge_eqs(49)_ 1
     x(1) c_u_edge_eqs(50)_ 1
     x(1) c_u_clique_eqs(30)_ 1
     x(1) c_u_clique_eqs(31)_ 1
     x(1) c_u_clique_eqs(47)_ 1
     x(1) c_u_clique_eqs(49)_ 1
     x(1) c_u_clique_eqs(51)_ 1
     x(1) c_u_clique_eqs(60)_ 1
     x(1) c_u_clique_eqs(107)_ 1
     x(1) c_u_clique_eqs(108)_ 1
     x(1) c_u_clique_eqs(109)_ 1
     x(1) c_u_clique_eqs(110)_ 1
     x(1) c_u_clique_eqs(113)_ 1
     x(1) c_u_clique_eqs(114)_ 1
     x(1) c_u_clique_eqs(115)_ 1
     x(1) c_u_clique_eqs(116)_ 1
     x(1) c_u_clique_eqs(199)_ 1
     x(1) c_u_clique_eqs(202)_ 1
     x(1) c_u_clique_eqs(224)_ 1
     x(1) c_u_clique_eqs(233)_ 1
     x(1) c_u_clique_eqs(237)_ 1
     x(1) c_u_clique_eqs(238)_ 1
     x(1) c_u_clique_eqs(239)_ 1
     x(1) c_u_clique_eqs(240)_ 1
     x(1) c_u_clique_eqs(241)_ 1
     x(1) c_u_clique_eqs(247)_ 1
     x(1) c_u_clique_eqs(274)_ 1
     x(1) c_u_clique_eqs(275)_ 1
     x(1) c_u_clique_eqs(276)_ 1
     x(1) c_u_clique_eqs(311)_ 1
     x(1) c_u_clique_eqs(312)_ 1
     x(1) c_u_clique_eqs(313)_ 1
     x(1) c_u_clique_eqs(314)_ 1
     x(1) c_u_clique_eqs(315)_ 1
     x(1) c_u_clique_eqs(316)_ 1
     x(1) c_u_clique_eqs(326)_ 1
     x(1) c_u_clique_eqs(327)_ 1
     x(1) c_u_clique_eqs(328)_ 1
     x(2) obj -10.33
     x(2) c_u_edge_eqs(1)_ 1
     x(2) c_u_edge_eqs(51)_ 1
     x(2) c_u_edge_eqs(52)_ 1
     x(2) c_u_edge_eqs(53)_ 1
     x(2) c_u_edge_eqs(54)_ 1
     x(2) c_u_edge_eqs(55)_ 1
     x(2) c_u_edge_eqs(56)_ 1
     x(2) c_u_edge_eqs(57)_ 1
     x(2) c_u_edge_eqs(58)_ 1
     x(2) c_u_edge_eqs(59)_ 1
     x(2) c_u_edge_eqs(60)_ 1
     x(2) c_u_edge_eqs(61)_ 1
     x(2) c_u_edge_eqs(62)_ 1
     x(2) c_u_edge_eqs(63)_ 1
     x(2) c_u_edge_eqs(64)_ 1
     x(2) c_u_edge_eqs(65)_ 1
     x(2) c_u_edge_eqs(66)_ 1
     x(2) c_u_edge_eqs(67)_ 1
     x(2) c_u_edge_eqs(68)_ 1
     x(2) c_u_edge_eqs(69)_ 1
     x(2) c_u_clique_eqs(137)_ 1
     x(2) c_u_clique_eqs(166)_ 1
     x(2) c_u_clique_eqs(184)_ 1
     x(2) c_u_clique_eqs(193)_ 1
     x(2) c_u_clique_eqs(218)_ 1
     x(2) c_u_clique_eqs(257)_ 1
     x(2) c_u_clique_eqs(258)_ 1
     x(2) c_u_clique_eqs(259)_ 1
     x(2) c_u_clique_eqs(260)_ 1
     x(2) c_u_clique_eqs(261)_ 1
     x(2) c_u_clique_eqs(277)_ 1
     x(2) c_u_clique_eqs(305)_ 1
     x(2) c_u_clique_eqs(310)_ 1
     x(2) c_u_clique_eqs(318)_ 1
     x(2) c_u_clique_eqs(319)_ 1
     x(3) obj -10.619999999999999
     x(3) c_u_edge_eqs(26)_ 1
     x(3) c_u_edge_eqs(70)_ 1
     x(3) c_u_edge_eqs(71)_ 1
     x(3) c_u_edge_eqs(72)_ 1
     x(3) c_u_edge_eqs(73)_ 1
     x(3) c_u_edge_eqs(74)_ 1
     x(3) c_u_edge_eqs(75)_ 1
     x(3) c_u_edge_eqs(76)_ 1
     x(3) c_u_edge_eqs(77)_ 1
     x(3) c_u_edge_eqs(78)_ 1
     x(3) c_u_edge_eqs(79)_ 1
     x(3) c_u_edge_eqs(80)_ 1
     x(3) c_u_edge_eqs(81)_ 1
     x(3) c_u_edge_eqs(82)_ 1
     x(3) c_u_edge_eqs(83)_ 1
     x(3) c_u_edge_eqs(84)_ 1
     x(3) c_u_edge_eqs(85)_ 1
     x(3) c_u_edge_eqs(86)_ 1
     x(3) c_u_edge_eqs(87)_ 1
     x(3) c_u_edge_eqs(88)_ 1
     x(3) c_u_edge_eqs(89)_ 1
     x(3) c_u_edge_eqs(90)_ 1
     x(3) c_u_edge_eqs(91)_ 1
     x(3) c_u_edge_eqs(92)_ 1
     x(3) c_u_edge_eqs(93)_ 1
     x(3) c_u_clique_eqs(16)_ 1
     x(3) c_u_clique_eqs(17)_ 1
     x(3) c_u_clique_eqs(31)_ 1
     x(3) c_u_clique_eqs(32)_ 1
     x(3) c_u_clique_eqs(44)_ 1
     x(3) c_u_clique_eqs(45)_ 1
     x(3) c_u_clique_eqs(72)_ 1
     x(3) c_u_clique_eqs(78)_ 1
     x(3) c_u_clique_eqs(79)_ 1
     x(3) c_u_clique_eqs(99)_ 1
     x(3) c_u_clique_eqs(111)_ 1
     x(3) c_u_clique_eqs(115)_ 1
     x(3) c_u_clique_eqs(129)_ 1
     x(3) c_u_clique_eqs(145)_ 1
     x(3) c_u_clique_eqs(146)_ 1
     x(3) c_u_clique_eqs(147)_ 1
     x(3) c_u_clique_eqs(156)_ 1
     x(3) c_u_clique_eqs(164)_ 1
     x(3) c_u_clique_eqs(165)_ 1
     x(3) c_u_clique_eqs(177)_ 1
     x(3) c_u_clique_eqs(180)_ 1
     x(3) c_u_clique_eqs(232)_ 1
     x(3) c_u_clique_eqs(239)_ 1
     x(3) c_u_clique_eqs(242)_ 1
     x(3) c_u_clique_eqs(264)_ 1
     x(3) c_u_clique_eqs(266)_ 1
     x(3) c_u_clique_eqs(267)_ 1
     x(3) c_u_clique_eqs(268)_ 1
     x(3) c_u_clique_eqs(274)_ 1
     x(3) c_u_clique_eqs(287)_ 1
     x(3) c_u_clique_eqs(297)_ 1
     x(3) c_u_clique_eqs(299)_ 1
     x(4) obj -10.99
     x(4) c_u_edge_eqs(27)_ 1
     x(4) c_u_edge_eqs(51)_ 1
     x(4) c_u_edge_eqs(94)_ 1
     x(4) c_u_edge_eqs(95)_ 1
     x(4) c_u_edge_eqs(96)_ 1
     x(4) c_u_edge_eqs(97)_ 1
     x(4) c_u_edge_eqs(98)_ 1
     x(4) c_u_edge_eqs(99)_ 1
     x(4) c_u_edge_eqs(100)_ 1
     x(4) c_u_edge_eqs(101)_ 1
     x(4) c_u_edge_eqs(102)_ 1
     x(4) c_u_edge_eqs(103)_ 1
     x(4) c_u_edge_eqs(104)_ 1
     x(4) c_u_edge_eqs(105)_ 1
     x(4) c_u_edge_eqs(106)_ 1
     x(4) c_u_edge_eqs(107)_ 1
     x(4) c_u_edge_eqs(108)_ 1
     x(4) c_u_edge_eqs(109)_ 1
     x(4) c_u_edge_eqs(110)_ 1
     x(4) c_u_edge_eqs(111)_ 1
     x(4) c_u_edge_eqs(112)_ 1
     x(4) c_u_edge_eqs(113)_ 1
     x(4) c_u_edge_eqs(114)_ 1
     x(4) c_u_clique_eqs(33)_ 1
     x(4) c_u_clique_eqs(34)_ 1
     x(4) c_u_clique_eqs(57)_ 1
     x(4) c_u_clique_eqs(83)_ 1
     x(4) c_u_clique_eqs(97)_ 1
     x(4) c_u_clique_eqs(116)_ 1
     x(4) c_u_clique_eqs(130)_ 1
     x(4) c_u_clique_eqs(140)_ 1
     x(4) c_u_clique_eqs(157)_ 1
     x(4) c_u_clique_eqs(181)_ 1
     x(4) c_u_clique_eqs(240)_ 1
     x(4) c_u_clique_eqs(241)_ 1
     x(4) c_u_clique_eqs(247)_ 1
     x(4) c_u_clique_eqs(269)_ 1
     x(4) c_u_clique_eqs(280)_ 1
     x(4) c_u_clique_eqs(281)_ 1
     x(4) c_u_clique_eqs(288)_ 1
     x(4) c_u_clique_eqs(310)_ 1
     x(5) obj -9.6500000000000004
     x(5) c_u_edge_eqs(115)_ 1
     x(5) c_u_edge_eqs(116)_ 1
     x(5) c_u_edge_eqs(117)_ 1
     x(5) c_u_edge_eqs(118)_ 1
     x(5) c_u_edge_eqs(119)_ 1
     x(5) c_u_edge_eqs(120)_ 1
     x(5) c_u_edge_eqs(121)_ 1
     x(5) c_u_edge_eqs(122)_ 1
     x(5) c_u_edge_eqs(123)_ 1
     x(5) c_u_edge_eqs(124)_ 1
     x(5) c_u_edge_eqs(125)_ 1
     x(5) c_u_edge_eqs(126)_ 1
     x(5) c_u_edge_eqs(127)_ 1
     x(5) c_u_edge_eqs(128)_ 1
     x(5) c_u_edge_eqs(129)_ 1
     x(5) c_u_edge_eqs(130)_ 1
     x(5) c_u_edge_eqs(131)_ 1
     x(5) c_u_edge_eqs(132)_ 1
     x(5) c_u_edge_eqs(133)_ 1
     x(5) c_u_edge_eqs(134)_ 1
     x(5) c_u_edge_eqs(135)_ 1
     x(5) c_u_edge_eqs(136)_ 1
     x(5) c_u_edge_eqs(137)_ 1
     x(5) c_u_edge_eqs(138)_ 1
     x(5) c_u_edge_eqs(139)_ 1
     x(5) c_u_edge_eqs(140)_ 1
     x(5) c_u_edge_eqs(141)_ 1
     x(5) c_u_edge_eqs(142)_ 1
     x(5) c_u_clique_eqs(1)_ 1
     x(5) c_u_clique_eqs(2)_ 1
     x(5) c_u_clique_eqs(3)_ 1
     x(5) c_u_clique_eqs(4)_ 1
     x(5) c_u_clique_eqs(5)_ 1
     x(5) c_u_clique_eqs(6)_ 1
     x(5) c_u_clique_eqs(7)_ 1
     x(5) c_u_clique_eqs(8)_ 1
     x(5) c_u_clique_eqs(9)_ 1
     x(5) c_u_clique_eqs(10)_ 1
     x(5) c_u_clique_eqs(11)_ 1
     x(5) c_u_clique_eqs(12)_ 1
     x(5) c_u_clique_eqs(120)_ 1
     x(5) c_u_clique_eqs(121)_ 1
     x(5) c_u_clique_eqs(122)_ 1
     x(5) c_u_clique_eqs(123)_ 1
     x(5) c_u_clique_eqs(124)_ 1
     x(5) c_u_clique_eqs(125)_ 1
     x(5) c_u_clique_eqs(154)_ 1
     x(5) c_u_clique_eqs(160)_ 1
     x(5) c_u_clique_eqs(161)_ 1
     x(5) c_u_clique_eqs(162)_ 1
     x(5) c_u_clique_eqs(191)_ 1
     x(5) c_u_clique_eqs(192)_ 1
     x(5) c_u_clique_eqs(205)_ 1
     x(5) c_u_clique_eqs(206)_ 1
     x(5) c_u_clique_eqs(207)_ 1
     x(5) c_u_clique_eqs(208)_ 1
     x(5) c_u_clique_eqs(209)_ 1
     x(5) c_u_clique_eqs(210)_ 1
     x(5) c_u_clique_eqs(211)_ 1
     x(5) c_u_clique_eqs(212)_ 1
     x(5) c_u_clique_eqs(213)_ 1
     x(5) c_u_clique_eqs(214)_ 1
     x(5) c_u_clique_eqs(215)_ 1
     x(5) c_u_clique_eqs(248)_ 1
     x(5) c_u_clique_eqs(249)_ 1
     x(5) c_u_clique_eqs(250)_ 1
     x(5) c_u_clique_eqs(251)_ 1
     x(5) c_u_clique_eqs(252)_ 1
     x(5) c_u_clique_eqs(253)_ 1
     x(5) c_u_clique_eqs(254)_ 1
     x(5) c_u_clique_eqs(255)_ 1
     x(5) c_u_clique_eqs(278)_ 1
     x(6) obj -9.8800000000000008
     x(6) c_u_edge_eqs(2)_ 1
     x(6) c_u_edge_eqs(28)_ 1
     x(6) c_u_edge_eqs(52)_ 1
     x(6) c_u_edge_eqs(143)_ 1
     x(6) c_u_edge_eqs(144)_ 1
     x(6) c_u_edge_eqs(145)_ 1
     x(6) c_u_edge_eqs(146)_ 1
     x(6) c_u_edge_eqs(147)_ 1
     x(6) c_u_edge_eqs(148)_ 1
     x(6) c_u_edge_eqs(149)_ 1
     x(6) c_u_edge_eqs(150)_ 1
     x(6) c_u_edge_eqs(151)_ 1
     x(6) c_u_edge_eqs(152)_ 1
     x(6) c_u_edge_eqs(153)_ 1
     x(6) c_u_edge_eqs(154)_ 1
     x(6) c_u_edge_eqs(155)_ 1
     x(6) c_u_edge_eqs(156)_ 1
     x(6) c_u_edge_eqs(157)_ 1
     x(6) c_u_edge_eqs(158)_ 1
     x(6) c_u_edge_eqs(159)_ 1
     x(6) c_u_edge_eqs(160)_ 1
     x(6) c_u_edge_eqs(161)_ 1
     x(6) c_u_edge_eqs(162)_ 1
     x(6) c_u_edge_eqs(163)_ 1
     x(6) c_u_clique_eqs(43)_ 1
     x(6) c_u_clique_eqs(46)_ 1
     x(6) c_u_clique_eqs(50)_ 1
     x(6) c_u_clique_eqs(112)_ 1
     x(6) c_u_clique_eqs(113)_ 1
     x(6) c_u_clique_eqs(114)_ 1
     x(6) c_u_clique_eqs(144)_ 1
     x(6) c_u_clique_eqs(168)_ 1
     x(6) c_u_clique_eqs(197)_ 1
     x(6) c_u_clique_eqs(201)_ 1
     x(6) c_u_clique_eqs(234)_ 1
     x(6) c_u_clique_eqs(237)_ 1
     x(6) c_u_clique_eqs(261)_ 1
     x(6) c_u_clique_eqs(262)_ 1
     x(6) c_u_clique_eqs(263)_ 1
     x(6) c_u_clique_eqs(312)_ 1
     x(6) c_u_clique_eqs(314)_ 1
     x(7) obj -11.43
     x(7) c_u_edge_eqs(3)_ 1
     x(7) c_u_edge_eqs(29)_ 1
     x(7) c_u_edge_eqs(70)_ 1
     x(7) c_u_edge_eqs(94)_ 1
     x(7) c_u_edge_eqs(115)_ 1
     x(7) c_u_edge_eqs(164)_ 1
     x(7) c_u_edge_eqs(165)_ 1
     x(7) c_u_edge_eqs(166)_ 1
     x(7) c_u_edge_eqs(167)_ 1
     x(7) c_u_edge_eqs(168)_ 1
     x(7) c_u_edge_eqs(169)_ 1
     x(7) c_u_edge_eqs(170)_ 1
     x(7) c_u_edge_eqs(171)_ 1
     x(7) c_u_edge_eqs(172)_ 1
     x(7) c_u_edge_eqs(173)_ 1
     x(7) c_u_edge_eqs(174)_ 1
     x(7) c_u_edge_eqs(175)_ 1
     x(7) c_u_edge_eqs(176)_ 1
     x(7) c_u_edge_eqs(177)_ 1
     x(7) c_u_edge_eqs(178)_ 1
     x(7) c_u_edge_eqs(179)_ 1
     x(7) c_u_edge_eqs(180)_ 1
     x(7) c_u_edge_eqs(181)_ 1
     x(7) c_u_edge_eqs(182)_ 1
     x(7) c_u_edge_eqs(183)_ 1
     x(7) c_u_edge_eqs(184)_ 1
     x(7) c_u_edge_eqs(185)_ 1
     x(7) c_u_clique_eqs(17)_ 1
     x(7) c_u_clique_eqs(45)_ 1
     x(7) c_u_clique_eqs(48)_ 1
     x(7) c_u_clique_eqs(79)_ 1
     x(7) c_u_clique_eqs(100)_ 1
     x(7) c_u_clique_eqs(101)_ 1
     x(7) c_u_clique_eqs(102)_ 1
     x(7) c_u_clique_eqs(115)_ 1
     x(7) c_u_clique_eqs(116)_ 1
     x(7) c_u_clique_eqs(117)_ 1
     x(7) c_u_clique_eqs(118)_ 1
     x(7) c_u_clique_eqs(147)_ 1
     x(7) c_u_clique_eqs(148)_ 1
     x(7) c_u_clique_eqs(149)_ 1
     x(7) c_u_clique_eqs(151)_ 1
     x(7) c_u_clique_eqs(152)_ 1
     x(7) c_u_clique_eqs(153)_ 1
     x(7) c_u_clique_eqs(175)_ 1
     x(7) c_u_clique_eqs(177)_ 1
     x(7) c_u_clique_eqs(182)_ 1
     x(7) c_u_clique_eqs(185)_ 1
     x(7) c_u_clique_eqs(186)_ 1
     x(7) c_u_clique_eqs(187)_ 1
     x(7) c_u_clique_eqs(188)_ 1
     x(7) c_u_clique_eqs(189)_ 1
     x(7) c_u_clique_eqs(190)_ 1
     x(7) c_u_clique_eqs(211)_ 1
     x(7) c_u_clique_eqs(220)_ 1
     x(7) c_u_clique_eqs(238)_ 1
     x(7) c_u_clique_eqs(239)_ 1
     x(7) c_u_clique_eqs(240)_ 1
     x(7) c_u_clique_eqs(241)_ 1
     x(7) c_u_clique_eqs(242)_ 1
     x(7) c_u_clique_eqs(243)_ 1
     x(7) c_u_clique_eqs(244)_ 1
     x(7) c_u_clique_eqs(245)_ 1
     x(7) c_u_clique_eqs(247)_ 1
     x(7) c_u_clique_eqs(287)_ 1
     x(7) c_u_clique_eqs(291)_ 1
     x(7) c_u_clique_eqs(297)_ 1
     x(8) obj -10.029999999999999
     x(8) c_u_edge_eqs(4)_ 1
     x(8) c_u_edge_eqs(30)_ 1
     x(8) c_u_edge_eqs(95)_ 1
     x(8) c_u_edge_eqs(116)_ 1
     x(8) c_u_edge_eqs(143)_ 1
     x(8) c_u_edge_eqs(164)_ 1
     x(8) c_u_edge_eqs(186)_ 1
     x(8) c_u_edge_eqs(187)_ 1
     x(8) c_u_edge_eqs(188)_ 1
     x(8) c_u_edge_eqs(189)_ 1
     x(8) c_u_edge_eqs(190)_ 1
     x(8) c_u_edge_eqs(191)_ 1
     x(8) c_u_edge_eqs(192)_ 1
     x(8) c_u_edge_eqs(193)_ 1
     x(8) c_u_edge_eqs(194)_ 1
     x(8) c_u_edge_eqs(195)_ 1
     x(8) c_u_edge_eqs(196)_ 1
     x(8) c_u_edge_eqs(197)_ 1
     x(8) c_u_clique_eqs(37)_ 1
     x(8) c_u_clique_eqs(43)_ 1
     x(8) c_u_clique_eqs(46)_ 1
     x(8) c_u_clique_eqs(50)_ 1
     x(8) c_u_clique_eqs(103)_ 1
     x(8) c_u_clique_eqs(113)_ 1
     x(8) c_u_clique_eqs(125)_ 1
     x(8) c_u_clique_eqs(131)_ 1
     x(8) c_u_clique_eqs(144)_ 1
     x(8) c_u_clique_eqs(168)_ 1
     x(8) c_u_clique_eqs(197)_ 1
     x(8) c_u_clique_eqs(200)_ 1
     x(8) c_u_clique_eqs(201)_ 1
     x(8) c_u_clique_eqs(238)_ 1
     x(8) c_u_clique_eqs(240)_ 1
     x(8) c_u_clique_eqs(315)_ 1
     x(8) c_u_clique_eqs(316)_ 1
     x(8) c_u_clique_eqs(326)_ 1
     x(9) obj -9.8000000000000007
     x(9) c_u_edge_eqs(5)_ 1
     x(9) c_u_edge_eqs(53)_ 1
     x(9) c_u_edge_eqs(71)_ 1
     x(9) c_u_edge_eqs(96)_ 1
     x(9) c_u_edge_eqs(144)_ 1
     x(9) c_u_edge_eqs(198)_ 1
     x(9) c_u_edge_eqs(199)_ 1
     x(9) c_u_edge_eqs(200)_ 1
     x(9) c_u_edge_eqs(201)_ 1
     x(9) c_u_edge_eqs(202)_ 1
     x(9) c_u_edge_eqs(203)_ 1
     x(9) c_u_edge_eqs(204)_ 1
     x(9) c_u_edge_eqs(205)_ 1
     x(9) c_u_edge_eqs(206)_ 1
     x(9) c_u_edge_eqs(207)_ 1
     x(9) c_u_edge_eqs(208)_ 1
     x(9) c_u_edge_eqs(209)_ 1
     x(9) c_u_edge_eqs(210)_ 1
     x(9) c_u_edge_eqs(211)_ 1
     x(9) c_u_edge_eqs(212)_ 1
     x(9) c_u_edge_eqs(213)_ 1
     x(9) c_u_edge_eqs(214)_ 1
     x(9) c_u_edge_eqs(215)_ 1
     x(9) c_u_edge_eqs(216)_ 1
     x(9) c_u_edge_eqs(217)_ 1
     x(9) c_u_edge_eqs(218)_ 1
     x(9) c_u_edge_eqs(219)_ 1
     x(9) c_u_clique_eqs(20)_ 1
     x(9) c_u_clique_eqs(21)_ 1
     x(9) c_u_clique_eqs(22)_ 1
     x(9) c_u_clique_eqs(23)_ 1
     x(9) c_u_clique_eqs(24)_ 1
     x(9) c_u_clique_eqs(25)_ 1
     x(9) c_u_clique_eqs(26)_ 1
     x(9) c_u_clique_eqs(78)_ 1
     x(9) c_u_clique_eqs(140)_ 1
     x(9) c_u_clique_eqs(143)_ 1
     x(9) c_u_clique_eqs(146)_ 1
     x(9) c_u_clique_eqs(156)_ 1
     x(9) c_u_clique_eqs(163)_ 1
     x(9) c_u_clique_eqs(173)_ 1
     x(9) c_u_clique_eqs(176)_ 1
     x(9) c_u_clique_eqs(179)_ 1
     x(9) c_u_clique_eqs(181)_ 1
     x(9) c_u_clique_eqs(184)_ 1
     x(9) c_u_clique_eqs(256)_ 1
     x(9) c_u_clique_eqs(257)_ 1
     x(9) c_u_clique_eqs(258)_ 1
     x(9) c_u_clique_eqs(259)_ 1
     x(9) c_u_clique_eqs(277)_ 1
     x(9) c_u_clique_eqs(295)_ 1
     x(9) c_u_clique_eqs(296)_ 1
     x(9) c_u_clique_eqs(298)_ 1
     x(9) c_u_clique_eqs(299)_ 1
     x(9) c_u_clique_eqs(302)_ 1
     x(9) c_u_clique_eqs(310)_ 1
     x(10) obj -9.5999999999999996
     x(10) c_u_edge_eqs(31)_ 1
     x(10) c_u_edge_eqs(97)_ 1
     x(10) c_u_edge_eqs(117)_ 1
     x(10) c_u_edge_eqs(145)_ 1
     x(10) c_u_edge_eqs(186)_ 1
     x(10) c_u_edge_eqs(198)_ 1
     x(10) c_u_edge_eqs(220)_ 1
     x(10) c_u_edge_eqs(221)_ 1
     x(10) c_u_edge_eqs(222)_ 1
     x(10) c_u_edge_eqs(223)_ 1
     x(10) c_u_edge_eqs(224)_ 1
     x(10) c_u_edge_eqs(225)_ 1
     x(10) c_u_edge_eqs(226)_ 1
     x(10) c_u_edge_eqs(227)_ 1
     x(10) c_u_edge_eqs(228)_ 1
     x(10) c_u_edge_eqs(229)_ 1
     x(10) c_u_edge_eqs(230)_ 1
     x(10) c_u_edge_eqs(231)_ 1
     x(10) c_u_edge_eqs(232)_ 1
     x(10) c_u_edge_eqs(233)_ 1
     x(10) c_u_edge_eqs(234)_ 1
     x(10) c_u_edge_eqs(235)_ 1
     x(10) c_u_edge_eqs(236)_ 1
     x(10) c_u_edge_eqs(237)_ 1
     x(10) c_u_edge_eqs(238)_ 1
     x(10) c_u_edge_eqs(239)_ 1
     x(10) c_u_edge_eqs(240)_ 1
     x(10) c_u_edge_eqs(241)_ 1
     x(10) c_u_edge_eqs(242)_ 1
     x(10) c_u_edge_eqs(243)_ 1
     x(10) c_u_clique_eqs(3)_ 1
     x(10) c_u_clique_eqs(10)_ 1
     x(10) c_u_clique_eqs(22)_ 1
     x(10) c_u_clique_eqs(23)_ 1
     x(10) c_u_clique_eqs(50)_ 1
     x(10) c_u_clique_eqs(51)_ 1
     x(10) c_u_clique_eqs(52)_ 1
     x(10) c_u_clique_eqs(107)_ 1
     x(10) c_u_clique_eqs(125)_ 1
     x(10) c_u_clique_eqs(131)_ 1
     x(10) c_u_clique_eqs(176)_ 1
     x(10) c_u_clique_eqs(183)_ 1
     x(10) c_u_clique_eqs(191)_ 1
     x(10) c_u_clique_eqs(192)_ 1
     x(10) c_u_clique_eqs(195)_ 1
     x(10) c_u_clique_eqs(200)_ 1
     x(10) c_u_clique_eqs(201)_ 1
     x(10) c_u_clique_eqs(202)_ 1
     x(10) c_u_clique_eqs(209)_ 1
     x(10) c_u_clique_eqs(210)_ 1
     x(10) c_u_clique_eqs(212)_ 1
     x(10) c_u_clique_eqs(213)_ 1
     x(10) c_u_clique_eqs(221)_ 1
     x(10) c_u_clique_eqs(235)_ 1
     x(10) c_u_clique_eqs(298)_ 1
     x(10) c_u_clique_eqs(302)_ 1
     x(10) c_u_clique_eqs(303)_ 1
     x(10) c_u_clique_eqs(313)_ 1
     x(10) c_u_clique_eqs(314)_ 1
     x(10) c_u_clique_eqs(315)_ 1
     x(10) c_u_clique_eqs(327)_ 1
     x(11) obj -10.23
     x(11) c_u_edge_eqs(6)_ 1
     x(11) c_u_edge_eqs(32)_ 1
     x(11) c_u_edge_eqs(54)_ 1
     x(11) c_u_edge_eqs(72)_ 1
     x(11) c_u_edge_eqs(98)_ 1
     x(11) c_u_edge_eqs(118)_ 1
     x(11) c_u_edge_eqs(187)_ 1
     x(11) c_u_edge_eqs(199)_ 1
     x(11) c_u_edge_eqs(244)_ 1
     x(11) c_u_edge_eqs(245)_ 1
     x(11) c_u_edge_eqs(246)_ 1
     x(11) c_u_edge_eqs(247)_ 1
     x(11) c_u_edge_eqs(248)_ 1
     x(11) c_u_edge_eqs(249)_ 1
     x(11) c_u_edge_eqs(250)_ 1
     x(11) c_u_edge_eqs(251)_ 1
     x(11) c_u_edge_eqs(252)_ 1
     x(11) c_u_edge_eqs(253)_ 1
     x(11) c_u_edge_eqs(254)_ 1
     x(11) c_u_edge_eqs(255)_ 1
     x(11) c_u_edge_eqs(256)_ 1
     x(11) c_u_edge_eqs(257)_ 1
     x(11) c_u_edge_eqs(258)_ 1
     x(11) c_u_edge_eqs(259)_ 1
     x(11) c_u_clique_eqs(8)_ 1
     x(11) c_u_clique_eqs(9)_ 1
     x(11) c_u_clique_eqs(19)_ 1
     x(11) c_u_clique_eqs(24)_ 1
     x(11) c_u_clique_eqs(27)_ 1
     x(11) c_u_clique_eqs(28)_ 1
     x(11) c_u_clique_eqs(29)_ 1
     x(11) c_u_clique_eqs(30)_ 1
     x(11) c_u_clique_eqs(31)_ 1
     x(11) c_u_clique_eqs(32)_ 1
     x(11) c_u_clique_eqs(33)_ 1
     x(11) c_u_clique_eqs(34)_ 1
     x(11) c_u_clique_eqs(35)_ 1
     x(11) c_u_clique_eqs(36)_ 1
     x(11) c_u_clique_eqs(37)_ 1
     x(11) c_u_clique_eqs(38)_ 1
     x(11) c_u_clique_eqs(39)_ 1
     x(11) c_u_clique_eqs(40)_ 1
     x(11) c_u_clique_eqs(41)_ 1
     x(11) c_u_clique_eqs(42)_ 1
     x(11) c_u_clique_eqs(129)_ 1
     x(11) c_u_clique_eqs(130)_ 1
     x(11) c_u_clique_eqs(154)_ 1
     x(11) c_u_clique_eqs(160)_ 1
     x(11) c_u_clique_eqs(164)_ 1
     x(11) c_u_clique_eqs(165)_ 1
     x(11) c_u_clique_eqs(196)_ 1
     x(11) c_u_clique_eqs(214)_ 1
     x(11) c_u_clique_eqs(217)_ 1
     x(11) c_u_clique_eqs(255)_ 1
     x(11) c_u_clique_eqs(256)_ 1
     x(11) c_u_clique_eqs(257)_ 1
     x(11) c_u_clique_eqs(258)_ 1
     x(11) c_u_clique_eqs(259)_ 1
     x(11) c_u_clique_eqs(260)_ 1
     x(11) c_u_clique_eqs(278)_ 1
     x(11) c_u_clique_eqs(279)_ 1
     x(11) c_u_clique_eqs(280)_ 1
     x(11) c_u_clique_eqs(281)_ 1
     x(11) c_u_clique_eqs(282)_ 1
     x(11) c_u_clique_eqs(283)_ 1
     x(11) c_u_clique_eqs(284)_ 1
     x(11) c_u_clique_eqs(308)_ 1
     x(11) c_u_clique_eqs(309)_ 1
     x(12) obj -11.76
     x(12) c_u_edge_eqs(7)_ 1
     x(12) c_u_edge_eqs(33)_ 1
     x(12) c_u_edge_eqs(55)_ 1
     x(12) c_u_edge_eqs(73)_ 1
     x(12) c_u_edge_eqs(99)_ 1
     x(12) c_u_edge_eqs(146)_ 1
     x(12) c_u_edge_eqs(165)_ 1
     x(12) c_u_edge_eqs(188)_ 1
     x(12) c_u_edge_eqs(200)_ 1
     x(12) c_u_edge_eqs(220)_ 1
     x(12) c_u_edge_eqs(260)_ 1
     x(12) c_u_edge_eqs(261)_ 1
     x(12) c_u_edge_eqs(262)_ 1
     x(12) c_u_edge_eqs(263)_ 1
     x(12) c_u_edge_eqs(264)_ 1
     x(12) c_u_edge_eqs(265)_ 1
     x(12) c_u_edge_eqs(266)_ 1
     x(12) c_u_edge_eqs(267)_ 1
     x(12) c_u_edge_eqs(268)_ 1
     x(12) c_u_edge_eqs(269)_ 1
     x(12) c_u_edge_eqs(270)_ 1
     x(12) c_u_edge_eqs(271)_ 1
     x(12) c_u_edge_eqs(272)_ 1
     x(12) c_u_edge_eqs(273)_ 1
     x(12) c_u_edge_eqs(274)_ 1
     x(12) c_u_edge_eqs(275)_ 1
     x(12) c_u_edge_eqs(276)_ 1
     x(12) c_u_edge_eqs(277)_ 1
     x(12) c_u_edge_eqs(278)_ 1
     x(12) c_u_edge_eqs(279)_ 1
     x(12) c_u_edge_eqs(280)_ 1
     x(12) c_u_edge_eqs(281)_ 1
     x(12) c_u_edge_eqs(282)_ 1
     x(12) c_u_clique_eqs(43)_ 1
     x(12) c_u_clique_eqs(44)_ 1
     x(12) c_u_clique_eqs(45)_ 1
     x(12) c_u_clique_eqs(46)_ 1
     x(12) c_u_clique_eqs(47)_ 1
     x(12) c_u_clique_eqs(48)_ 1
     x(12) c_u_clique_eqs(49)_ 1
     x(12) c_u_clique_eqs(50)_ 1
     x(12) c_u_clique_eqs(51)_ 1
     x(12) c_u_clique_eqs(52)_ 1
     x(12) c_u_clique_eqs(53)_ 1
     x(12) c_u_clique_eqs(54)_ 1
     x(12) c_u_clique_eqs(55)_ 1
     x(12) c_u_clique_eqs(56)_ 1
     x(12) c_u_clique_eqs(57)_ 1
     x(12) c_u_clique_eqs(58)_ 1
     x(12) c_u_clique_eqs(59)_ 1
     x(12) c_u_clique_eqs(60)_ 1
     x(12) c_u_clique_eqs(131)_ 1
     x(12) c_u_clique_eqs(132)_ 1
     x(12) c_u_clique_eqs(144)_ 1
     x(12) c_u_clique_eqs(166)_ 1
     x(12) c_u_clique_eqs(167)_ 1
     x(12) c_u_clique_eqs(168)_ 1
     x(12) c_u_clique_eqs(169)_ 1
     x(12) c_u_clique_eqs(170)_ 1
     x(12) c_u_clique_eqs(197)_ 1
     x(12) c_u_clique_eqs(198)_ 1
     x(12) c_u_clique_eqs(199)_ 1
     x(12) c_u_clique_eqs(200)_ 1
     x(12) c_u_clique_eqs(201)_ 1
     x(12) c_u_clique_eqs(202)_ 1
     x(12) c_u_clique_eqs(218)_ 1
     x(12) c_u_clique_eqs(219)_ 1
     x(12) c_u_clique_eqs(220)_ 1
     x(12) c_u_clique_eqs(221)_ 1
     x(12) c_u_clique_eqs(222)_ 1
     x(12) c_u_clique_eqs(223)_ 1
     x(12) c_u_clique_eqs(224)_ 1
     x(12) c_u_clique_eqs(261)_ 1
     x(12) c_u_clique_eqs(310)_ 1
     x(12) c_u_clique_eqs(311)_ 1
     x(12) c_u_clique_eqs(312)_ 1
     x(12) c_u_clique_eqs(313)_ 1
     x(12) c_u_clique_eqs(314)_ 1
     x(12) c_u_clique_eqs(315)_ 1
     x(12) c_u_clique_eqs(316)_ 1
     x(13) obj -10.84
     x(13) c_u_edge_eqs(8)_ 1
     x(13) c_u_edge_eqs(147)_ 1
     x(13) c_u_edge_eqs(283)_ 1
     x(13) c_u_edge_eqs(284)_ 1
     x(13) c_u_edge_eqs(285)_ 1
     x(13) c_u_edge_eqs(286)_ 1
     x(13) c_u_edge_eqs(287)_ 1
     x(13) c_u_edge_eqs(288)_ 1
     x(13) c_u_edge_eqs(289)_ 1
     x(13) c_u_edge_eqs(290)_ 1
     x(13) c_u_edge_eqs(291)_ 1
     x(13) c_u_edge_eqs(292)_ 1
     x(13) c_u_edge_eqs(293)_ 1
     x(13) c_u_edge_eqs(294)_ 1
     x(13) c_u_edge_eqs(295)_ 1
     x(13) c_u_edge_eqs(296)_ 1
     x(13) c_u_edge_eqs(297)_ 1
     x(13) c_u_edge_eqs(298)_ 1
     x(13) c_u_clique_eqs(13)_ 1
     x(13) c_u_clique_eqs(61)_ 1
     x(13) c_u_clique_eqs(62)_ 1
     x(13) c_u_clique_eqs(63)_ 1
     x(13) c_u_clique_eqs(64)_ 1
     x(13) c_u_clique_eqs(65)_ 1
     x(13) c_u_clique_eqs(66)_ 1
     x(13) c_u_clique_eqs(67)_ 1
     x(13) c_u_clique_eqs(68)_ 1
     x(13) c_u_clique_eqs(69)_ 1
     x(13) c_u_clique_eqs(133)_ 1
     x(13) c_u_clique_eqs(203)_ 1
     x(13) c_u_clique_eqs(216)_ 1
     x(13) c_u_clique_eqs(225)_ 1
     x(13) c_u_clique_eqs(226)_ 1
     x(13) c_u_clique_eqs(227)_ 1
     x(13) c_u_clique_eqs(228)_ 1
     x(13) c_u_clique_eqs(229)_ 1
     x(13) c_u_clique_eqs(230)_ 1
     x(13) c_u_clique_eqs(262)_ 1
     x(13) c_u_clique_eqs(263)_ 1
     x(13) c_u_clique_eqs(285)_ 1
     x(13) c_u_clique_eqs(286)_ 1
     x(13) c_u_clique_eqs(294)_ 1
     x(14) obj -10.449999999999999
     x(14) c_u_edge_eqs(34)_ 1
     x(14) c_u_edge_eqs(74)_ 1
     x(14) c_u_edge_eqs(119)_ 1
     x(14) c_u_edge_eqs(189)_ 1
     x(14) c_u_edge_eqs(260)_ 1
     x(14) c_u_edge_eqs(299)_ 1
     x(14) c_u_edge_eqs(300)_ 1
     x(14) c_u_edge_eqs(301)_ 1
     x(14) c_u_edge_eqs(302)_ 1
     x(14) c_u_edge_eqs(303)_ 1
     x(14) c_u_edge_eqs(304)_ 1
     x(14) c_u_edge_eqs(305)_ 1
     x(14) c_u_edge_eqs(306)_ 1
     x(14) c_u_edge_eqs(307)_ 1
     x(14) c_u_edge_eqs(308)_ 1
     x(14) c_u_edge_eqs(309)_ 1
     x(14) c_u_edge_eqs(310)_ 1
     x(14) c_u_edge_eqs(311)_ 1
     x(14) c_u_edge_eqs(312)_ 1
     x(14) c_u_edge_eqs(313)_ 1
     x(14) c_u_edge_eqs(314)_ 1
     x(14) c_u_edge_eqs(315)_ 1
     x(14) c_u_edge_eqs(316)_ 1
     x(14) c_u_edge_eqs(317)_ 1
     x(14) c_u_clique_eqs(2)_ 1
     x(14) c_u_clique_eqs(5)_ 1
     x(14) c_u_clique_eqs(7)_ 1
     x(14) c_u_clique_eqs(49)_ 1
     x(14) c_u_clique_eqs(55)_ 1
     x(14) c_u_clique_eqs(58)_ 1
     x(14) c_u_clique_eqs(60)_ 1
     x(14) c_u_clique_eqs(72)_ 1
     x(14) c_u_clique_eqs(73)_ 1
     x(14) c_u_clique_eqs(75)_ 1
     x(14) c_u_clique_eqs(76)_ 1
     x(14) c_u_clique_eqs(84)_ 1
     x(14) c_u_clique_eqs(85)_ 1
     x(14) c_u_clique_eqs(86)_ 1
     x(14) c_u_clique_eqs(94)_ 1
     x(14) c_u_clique_eqs(109)_ 1
     x(14) c_u_clique_eqs(110)_ 1
     x(14) c_u_clique_eqs(119)_ 1
     x(14) c_u_clique_eqs(121)_ 1
     x(14) c_u_clique_eqs(124)_ 1
     x(14) c_u_clique_eqs(132)_ 1
     x(14) c_u_clique_eqs(134)_ 1
     x(14) c_u_clique_eqs(135)_ 1
     x(14) c_u_clique_eqs(136)_ 1
     x(14) c_u_clique_eqs(141)_ 1
     x(14) c_u_clique_eqs(145)_ 1
     x(14) c_u_clique_eqs(155)_ 1
     x(14) c_u_clique_eqs(167)_ 1
     x(14) c_u_clique_eqs(172)_ 1
     x(14) c_u_clique_eqs(174)_ 1
     x(14) c_u_clique_eqs(204)_ 1
     x(14) c_u_clique_eqs(224)_ 1
     x(14) c_u_clique_eqs(233)_ 1
     x(14) c_u_clique_eqs(236)_ 1
     x(14) c_u_clique_eqs(249)_ 1
     x(14) c_u_clique_eqs(250)_ 1
     x(14) c_u_clique_eqs(251)_ 1
     x(14) c_u_clique_eqs(253)_ 1
     x(14) c_u_clique_eqs(254)_ 1
     x(14) c_u_clique_eqs(264)_ 1
     x(14) c_u_clique_eqs(265)_ 1
     x(14) c_u_clique_eqs(266)_ 1
     x(14) c_u_clique_eqs(267)_ 1
     x(14) c_u_clique_eqs(268)_ 1
     x(14) c_u_clique_eqs(270)_ 1
     x(14) c_u_clique_eqs(271)_ 1
     x(14) c_u_clique_eqs(274)_ 1
     x(14) c_u_clique_eqs(275)_ 1
     x(14) c_u_clique_eqs(276)_ 1
     x(14) c_u_clique_eqs(304)_ 1
     x(14) c_u_clique_eqs(316)_ 1
     x(14) c_u_clique_eqs(322)_ 1
     x(14) c_u_clique_eqs(326)_ 1
     x(14) c_u_clique_eqs(329)_ 1
     x(15) obj -10.94
     x(15) c_u_edge_eqs(56)_ 1
     x(15) c_u_edge_eqs(120)_ 1
     x(15) c_u_edge_eqs(148)_ 1
     x(15) c_u_edge_eqs(166)_ 1
     x(15) c_u_edge_eqs(201)_ 1
     x(15) c_u_edge_eqs(221)_ 1
     x(15) c_u_edge_eqs(244)_ 1
     x(15) c_u_edge_eqs(261)_ 1
     x(15) c_u_edge_eqs(318)_ 1
     x(15) c_u_edge_eqs(319)_ 1
     x(15) c_u_edge_eqs(320)_ 1
     x(15) c_u_edge_eqs(321)_ 1
     x(15) c_u_edge_eqs(322)_ 1
     x(15) c_u_edge_eqs(323)_ 1
     x(15) c_u_edge_eqs(324)_ 1
     x(15) c_u_edge_eqs(325)_ 1
     x(15) c_u_edge_eqs(326)_ 1
     x(15) c_u_edge_eqs(327)_ 1
     x(15) c_u_edge_eqs(328)_ 1
     x(15) c_u_edge_eqs(329)_ 1
     x(15) c_u_edge_eqs(330)_ 1
     x(15) c_u_edge_eqs(331)_ 1
     x(15) c_u_edge_eqs(332)_ 1
     x(15) c_u_clique_eqs(3)_ 1
     x(15) c_u_clique_eqs(4)_ 1
     x(15) c_u_clique_eqs(20)_ 1
     x(15) c_u_clique_eqs(21)_ 1
     x(15) c_u_clique_eqs(22)_ 1
     x(15) c_u_clique_eqs(23)_ 1
     x(15) c_u_clique_eqs(24)_ 1
     x(15) c_u_clique_eqs(25)_ 1
     x(15) c_u_clique_eqs(27)_ 1
     x(15) c_u_clique_eqs(42)_ 1
     x(15) c_u_clique_eqs(48)_ 1
     x(15) c_u_clique_eqs(118)_ 1
     x(15) c_u_clique_eqs(143)_ 1
     x(15) c_u_clique_eqs(153)_ 1
     x(15) c_u_clique_eqs(163)_ 1
     x(15) c_u_clique_eqs(175)_ 1
     x(15) c_u_clique_eqs(188)_ 1
     x(15) c_u_clique_eqs(192)_ 1
     x(15) c_u_clique_eqs(210)_ 1
     x(15) c_u_clique_eqs(211)_ 1
     x(15) c_u_clique_eqs(220)_ 1
     x(15) c_u_clique_eqs(256)_ 1
     x(15) c_u_clique_eqs(259)_ 1
     x(16) obj -10.93
     x(16) c_u_edge_eqs(9)_ 1
     x(16) c_u_edge_eqs(100)_ 1
     x(16) c_u_edge_eqs(121)_ 1
     x(16) c_u_edge_eqs(149)_ 1
     x(16) c_u_edge_eqs(222)_ 1
     x(16) c_u_edge_eqs(283)_ 1
     x(16) c_u_edge_eqs(299)_ 1
     x(16) c_u_edge_eqs(333)_ 1
     x(16) c_u_edge_eqs(334)_ 1
     x(16) c_u_edge_eqs(335)_ 1
     x(16) c_u_edge_eqs(336)_ 1
     x(16) c_u_edge_eqs(337)_ 1
     x(16) c_u_edge_eqs(338)_ 1
     x(16) c_u_edge_eqs(339)_ 1
     x(16) c_u_edge_eqs(340)_ 1
     x(16) c_u_edge_eqs(341)_ 1
     x(16) c_u_edge_eqs(342)_ 1
     x(16) c_u_edge_eqs(343)_ 1
     x(16) c_u_edge_eqs(344)_ 1
     x(16) c_u_edge_eqs(345)_ 1
     x(16) c_u_edge_eqs(346)_ 1
     x(16) c_u_edge_eqs(347)_ 1
     x(16) c_u_edge_eqs(348)_ 1
     x(16) c_u_edge_eqs(349)_ 1
     x(16) c_u_edge_eqs(350)_ 1
     x(16) c_u_edge_eqs(351)_ 1
     x(16) c_u_edge_eqs(352)_ 1
     x(16) c_u_clique_eqs(5)_ 1
     x(16) c_u_clique_eqs(6)_ 1
     x(16) c_u_clique_eqs(7)_ 1
     x(16) c_u_clique_eqs(11)_ 1
     x(16) c_u_clique_eqs(12)_ 1
     x(16) c_u_clique_eqs(61)_ 1
     x(16) c_u_clique_eqs(62)_ 1
     x(16) c_u_clique_eqs(63)_ 1
     x(16) c_u_clique_eqs(64)_ 1
     x(16) c_u_clique_eqs(65)_ 1
     x(16) c_u_clique_eqs(66)_ 1
     x(16) c_u_clique_eqs(67)_ 1
     x(16) c_u_clique_eqs(73)_ 1
     x(16) c_u_clique_eqs(74)_ 1
     x(16) c_u_clique_eqs(76)_ 1
     x(16) c_u_clique_eqs(77)_ 1
     x(16) c_u_clique_eqs(80)_ 1
     x(16) c_u_clique_eqs(81)_ 1
     x(16) c_u_clique_eqs(82)_ 1
     x(16) c_u_clique_eqs(83)_ 1
     x(16) c_u_clique_eqs(84)_ 1
     x(16) c_u_clique_eqs(85)_ 1
     x(16) c_u_clique_eqs(86)_ 1
     x(16) c_u_clique_eqs(87)_ 1
     x(16) c_u_clique_eqs(88)_ 1
     x(16) c_u_clique_eqs(89)_ 1
     x(16) c_u_clique_eqs(90)_ 1
     x(16) c_u_clique_eqs(91)_ 1
     x(16) c_u_clique_eqs(92)_ 1
     x(16) c_u_clique_eqs(93)_ 1
     x(16) c_u_clique_eqs(94)_ 1
     x(16) c_u_clique_eqs(95)_ 1
     x(16) c_u_clique_eqs(96)_ 1
     x(16) c_u_clique_eqs(97)_ 1
     x(16) c_u_clique_eqs(98)_ 1
     x(16) c_u_clique_eqs(133)_ 1
     x(16) c_u_clique_eqs(138)_ 1
     x(16) c_u_clique_eqs(139)_ 1
     x(16) c_u_clique_eqs(155)_ 1
     x(16) c_u_clique_eqs(157)_ 1
     x(16) c_u_clique_eqs(158)_ 1
     x(16) c_u_clique_eqs(159)_ 1
     x(16) c_u_clique_eqs(225)_ 1
     x(16) c_u_clique_eqs(226)_ 1
     x(16) c_u_clique_eqs(227)_ 1
     x(16) c_u_clique_eqs(228)_ 1
     x(16) c_u_clique_eqs(265)_ 1
     x(16) c_u_clique_eqs(269)_ 1
     x(16) c_u_clique_eqs(270)_ 1
     x(16) c_u_clique_eqs(271)_ 1
     x(16) c_u_clique_eqs(272)_ 1
     x(16) c_u_clique_eqs(273)_ 1
     x(16) c_u_clique_eqs(285)_ 1
     x(16) c_u_clique_eqs(286)_ 1
     x(16) c_u_clique_eqs(288)_ 1
     x(16) c_u_clique_eqs(289)_ 1
     x(16) c_u_clique_eqs(290)_ 1
     x(16) c_u_clique_eqs(300)_ 1
     x(16) c_u_clique_eqs(301)_ 1
     x(16) c_u_clique_eqs(303)_ 1
     x(16) c_u_clique_eqs(321)_ 1
     x(16) c_u_clique_eqs(322)_ 1
     x(17) obj -9.8599999999999994
     x(17) c_u_edge_eqs(75)_ 1
     x(17) c_u_edge_eqs(101)_ 1
     x(17) c_u_edge_eqs(122)_ 1
     x(17) c_u_edge_eqs(202)_ 1
     x(17) c_u_edge_eqs(245)_ 1
     x(17) c_u_edge_eqs(353)_ 1
     x(17) c_u_edge_eqs(354)_ 1
     x(17) c_u_edge_eqs(355)_ 1
     x(17) c_u_edge_eqs(356)_ 1
     x(17) c_u_edge_eqs(357)_ 1
     x(17) c_u_edge_eqs(358)_ 1
     x(17) c_u_edge_eqs(359)_ 1
     x(17) c_u_edge_eqs(360)_ 1
     x(17) c_u_edge_eqs(361)_ 1
     x(17) c_u_edge_eqs(362)_ 1
     x(17) c_u_edge_eqs(363)_ 1
     x(17) c_u_edge_eqs(364)_ 1
     x(17) c_u_edge_eqs(365)_ 1
     x(17) c_u_edge_eqs(366)_ 1
     x(17) c_u_edge_eqs(367)_ 1
     x(17) c_u_clique_eqs(8)_ 1
     x(17) c_u_clique_eqs(32)_ 1
     x(17) c_u_clique_eqs(99)_ 1
     x(17) c_u_clique_eqs(120)_ 1
     x(17) c_u_clique_eqs(129)_ 1
     x(17) c_u_clique_eqs(130)_ 1
     x(17) c_u_clique_eqs(140)_ 1
     x(17) c_u_clique_eqs(154)_ 1
     x(17) c_u_clique_eqs(160)_ 1
     x(17) c_u_clique_eqs(161)_ 1
     x(17) c_u_clique_eqs(162)_ 1
     x(17) c_u_clique_eqs(164)_ 1
     x(17) c_u_clique_eqs(165)_ 1
     x(17) c_u_clique_eqs(173)_ 1
     x(17) c_u_clique_eqs(178)_ 1
     x(17) c_u_clique_eqs(179)_ 1
     x(17) c_u_clique_eqs(180)_ 1
     x(17) c_u_clique_eqs(181)_ 1
     x(17) c_u_clique_eqs(196)_ 1
     x(17) c_u_clique_eqs(214)_ 1
     x(17) c_u_clique_eqs(215)_ 1
     x(17) c_u_clique_eqs(232)_ 1
     x(17) c_u_clique_eqs(248)_ 1
     x(17) c_u_clique_eqs(255)_ 1
     x(17) c_u_clique_eqs(296)_ 1
     x(17) c_u_clique_eqs(308)_ 1
     x(17) c_u_clique_eqs(309)_ 1
     x(17) c_u_clique_eqs(323)_ 1
     x(17) c_u_clique_eqs(324)_ 1
     x(17) c_u_clique_eqs(325)_ 1
     x(18) obj -11.25
     x(18) c_u_edge_eqs(10)_ 1
     x(18) c_u_edge_eqs(35)_ 1
     x(18) c_u_edge_eqs(76)_ 1
     x(18) c_u_edge_eqs(123)_ 1
     x(18) c_u_edge_eqs(167)_ 1
     x(18) c_u_edge_eqs(190)_ 1
     x(18) c_u_edge_eqs(203)_ 1
     x(18) c_u_edge_eqs(223)_ 1
     x(18) c_u_edge_eqs(246)_ 1
     x(18) c_u_edge_eqs(262)_ 1
     x(18) c_u_edge_eqs(300)_ 1
     x(18) c_u_edge_eqs(333)_ 1
     x(18) c_u_edge_eqs(368)_ 1
     x(18) c_u_edge_eqs(369)_ 1
     x(18) c_u_edge_eqs(370)_ 1
     x(18) c_u_edge_eqs(371)_ 1
     x(18) c_u_edge_eqs(372)_ 1
     x(18) c_u_edge_eqs(373)_ 1
     x(18) c_u_edge_eqs(374)_ 1
     x(18) c_u_edge_eqs(375)_ 1
     x(18) c_u_edge_eqs(376)_ 1
     x(18) c_u_edge_eqs(377)_ 1
     x(18) c_u_edge_eqs(378)_ 1
     x(18) c_u_edge_eqs(379)_ 1
     x(18) c_u_edge_eqs(380)_ 1
     x(18) c_u_edge_eqs(381)_ 1
     x(18) c_u_clique_eqs(29)_ 1
     x(18) c_u_clique_eqs(72)_ 1
     x(18) c_u_clique_eqs(78)_ 1
     x(18) c_u_clique_eqs(79)_ 1
     x(18) c_u_clique_eqs(80)_ 1
     x(18) c_u_clique_eqs(81)_ 1
     x(18) c_u_clique_eqs(93)_ 1
     x(18) c_u_clique_eqs(117)_ 1
     x(18) c_u_clique_eqs(125)_ 1
     x(18) c_u_clique_eqs(131)_ 1
     x(18) c_u_clique_eqs(142)_ 1
     x(18) c_u_clique_eqs(145)_ 1
     x(18) c_u_clique_eqs(146)_ 1
     x(18) c_u_clique_eqs(147)_ 1
     x(18) c_u_clique_eqs(151)_ 1
     x(18) c_u_clique_eqs(152)_ 1
     x(18) c_u_clique_eqs(155)_ 1
     x(18) c_u_clique_eqs(176)_ 1
     x(18) c_u_clique_eqs(177)_ 1
     x(18) c_u_clique_eqs(186)_ 1
     x(18) c_u_clique_eqs(187)_ 1
     x(18) c_u_clique_eqs(189)_ 1
     x(18) c_u_clique_eqs(190)_ 1
     x(18) c_u_clique_eqs(198)_ 1
     x(18) c_u_clique_eqs(199)_ 1
     x(18) c_u_clique_eqs(200)_ 1
     x(18) c_u_clique_eqs(217)_ 1
     x(18) c_u_clique_eqs(219)_ 1
     x(18) c_u_clique_eqs(244)_ 1
     x(18) c_u_clique_eqs(245)_ 1
     x(18) c_u_clique_eqs(246)_ 1
     x(18) c_u_clique_eqs(265)_ 1
     x(18) c_u_clique_eqs(266)_ 1
     x(18) c_u_clique_eqs(289)_ 1
     x(18) c_u_clique_eqs(290)_ 1
     x(18) c_u_clique_eqs(311)_ 1
     x(18) c_u_clique_eqs(313)_ 1
     x(18) c_u_clique_eqs(315)_ 1
     x(18) c_u_clique_eqs(316)_ 1
     x(18) c_u_clique_eqs(320)_ 1
     x(18) c_u_clique_eqs(321)_ 1
     x(18) c_u_clique_eqs(322)_ 1
     x(18) c_u_clique_eqs(329)_ 1
     x(19) obj -10.369999999999999
     x(19) c_u_edge_eqs(11)_ 1
     x(19) c_u_edge_eqs(57)_ 1
     x(19) c_u_edge_eqs(77)_ 1
     x(19) c_u_edge_eqs(102)_ 1
     x(19) c_u_edge_eqs(204)_ 1
     x(19) c_u_edge_eqs(224)_ 1
     x(19) c_u_edge_eqs(263)_ 1
     x(19) c_u_edge_eqs(301)_ 1
     x(19) c_u_edge_eqs(318)_ 1
     x(19) c_u_edge_eqs(334)_ 1
     x(19) c_u_edge_eqs(368)_ 1
     x(19) c_u_edge_eqs(382)_ 1
     x(19) c_u_edge_eqs(383)_ 1
     x(19) c_u_edge_eqs(384)_ 1
     x(19) c_u_edge_eqs(385)_ 1
     x(19) c_u_edge_eqs(386)_ 1
     x(19) c_u_edge_eqs(387)_ 1
     x(19) c_u_edge_eqs(388)_ 1
     x(19) c_u_edge_eqs(389)_ 1
     x(19) c_u_edge_eqs(390)_ 1
     x(19) c_u_edge_eqs(391)_ 1
     x(19) c_u_edge_eqs(392)_ 1
     x(19) c_u_edge_eqs(393)_ 1
     x(19) c_u_edge_eqs(394)_ 1
     x(19) c_u_edge_eqs(395)_ 1
     x(19) c_u_clique_eqs(23)_ 1
     x(19) c_u_clique_eqs(55)_ 1
     x(19) c_u_clique_eqs(56)_ 1
     x(19) c_u_clique_eqs(57)_ 1
     x(19) c_u_clique_eqs(58)_ 1
     x(19) c_u_clique_eqs(59)_ 1
     x(19) c_u_clique_eqs(82)_ 1
     x(19) c_u_clique_eqs(83)_ 1
     x(19) c_u_clique_eqs(84)_ 1
     x(19) c_u_clique_eqs(85)_ 1
     x(19) c_u_clique_eqs(86)_ 1
     x(19) c_u_clique_eqs(87)_ 1
     x(19) c_u_clique_eqs(88)_ 1
     x(19) c_u_clique_eqs(89)_ 1
     x(19) c_u_clique_eqs(132)_ 1
     x(19) c_u_clique_eqs(157)_ 1
     x(19) c_u_clique_eqs(158)_ 1
     x(19) c_u_clique_eqs(159)_ 1
     x(19) c_u_clique_eqs(166)_ 1
     x(19) c_u_clique_eqs(167)_ 1
     x(19) c_u_clique_eqs(169)_ 1
     x(19) c_u_clique_eqs(170)_ 1
     x(19) c_u_clique_eqs(195)_ 1
     x(19) c_u_clique_eqs(198)_ 1
     x(19) c_u_clique_eqs(218)_ 1
     x(19) c_u_clique_eqs(219)_ 1
     x(19) c_u_clique_eqs(222)_ 1
     x(19) c_u_clique_eqs(223)_ 1
     x(19) c_u_clique_eqs(236)_ 1
     x(19) c_u_clique_eqs(269)_ 1
     x(19) c_u_clique_eqs(270)_ 1
     x(19) c_u_clique_eqs(271)_ 1
     x(19) c_u_clique_eqs(272)_ 1
     x(19) c_u_clique_eqs(273)_ 1
     x(19) c_u_clique_eqs(300)_ 1
     x(19) c_u_clique_eqs(301)_ 1
     x(19) c_u_clique_eqs(302)_ 1
     x(20) obj -11.26
     x(20) c_u_edge_eqs(36)_ 1
     x(20) c_u_edge_eqs(103)_ 1
     x(20) c_u_edge_eqs(124)_ 1
     x(20) c_u_edge_eqs(168)_ 1
     x(20) c_u_edge_eqs(205)_ 1
     x(20) c_u_edge_eqs(225)_ 1
     x(20) c_u_edge_eqs(264)_ 1
     x(20) c_u_edge_eqs(284)_ 1
     x(20) c_u_edge_eqs(302)_ 1
     x(20) c_u_edge_eqs(319)_ 1
     x(20) c_u_edge_eqs(335)_ 1
     x(20) c_u_edge_eqs(382)_ 1
     x(20) c_u_edge_eqs(396)_ 1
     x(20) c_u_edge_eqs(397)_ 1
     x(20) c_u_edge_eqs(398)_ 1
     x(20) c_u_edge_eqs(399)_ 1
     x(20) c_u_edge_eqs(400)_ 1
     x(20) c_u_edge_eqs(401)_ 1
     x(20) c_u_edge_eqs(402)_ 1
     x(20) c_u_edge_eqs(403)_ 1
     x(20) c_u_edge_eqs(404)_ 1
     x(20) c_u_edge_eqs(405)_ 1
     x(20) c_u_edge_eqs(406)_ 1
     x(20) c_u_edge_eqs(407)_ 1
     x(20) c_u_clique_eqs(1)_ 1
     x(20) c_u_clique_eqs(2)_ 1
     x(20) c_u_clique_eqs(3)_ 1
     x(20) c_u_clique_eqs(4)_ 1
     x(20) c_u_clique_eqs(7)_ 1
     x(20) c_u_clique_eqs(10)_ 1
     x(20) c_u_clique_eqs(11)_ 1
     x(20) c_u_clique_eqs(12)_ 1
     x(20) c_u_clique_eqs(22)_ 1
     x(20) c_u_clique_eqs(23)_ 1
     x(20) c_u_clique_eqs(25)_ 1
     x(20) c_u_clique_eqs(26)_ 1
     x(20) c_u_clique_eqs(49)_ 1
     x(20) c_u_clique_eqs(51)_ 1
     x(20) c_u_clique_eqs(52)_ 1
     x(20) c_u_clique_eqs(53)_ 1
     x(20) c_u_clique_eqs(54)_ 1
     x(20) c_u_clique_eqs(55)_ 1
     x(20) c_u_clique_eqs(56)_ 1
     x(20) c_u_clique_eqs(57)_ 1
     x(20) c_u_clique_eqs(60)_ 1
     x(20) c_u_clique_eqs(63)_ 1
     x(20) c_u_clique_eqs(67)_ 1
     x(20) c_u_clique_eqs(82)_ 1
     x(20) c_u_clique_eqs(83)_ 1
     x(20) c_u_clique_eqs(86)_ 1
     x(20) c_u_clique_eqs(88)_ 1
     x(20) c_u_clique_eqs(92)_ 1
     x(20) c_u_clique_eqs(105)_ 1
     x(20) c_u_clique_eqs(107)_ 1
     x(20) c_u_clique_eqs(109)_ 1
     x(20) c_u_clique_eqs(110)_ 1
     x(20) c_u_clique_eqs(122)_ 1
     x(20) c_u_clique_eqs(123)_ 1
     x(20) c_u_clique_eqs(124)_ 1
     x(20) c_u_clique_eqs(132)_ 1
     x(20) c_u_clique_eqs(157)_ 1
     x(20) c_u_clique_eqs(158)_ 1
     x(20) c_u_clique_eqs(169)_ 1
     x(20) c_u_clique_eqs(191)_ 1
     x(20) c_u_clique_eqs(192)_ 1
     x(20) c_u_clique_eqs(195)_ 1
     x(20) c_u_clique_eqs(202)_ 1
     x(20) c_u_clique_eqs(206)_ 1
     x(20) c_u_clique_eqs(207)_ 1
     x(20) c_u_clique_eqs(208)_ 1
     x(20) c_u_clique_eqs(209)_ 1
     x(20) c_u_clique_eqs(210)_ 1
     x(20) c_u_clique_eqs(211)_ 1
     x(20) c_u_clique_eqs(212)_ 1
     x(20) c_u_clique_eqs(221)_ 1
     x(20) c_u_clique_eqs(222)_ 1
     x(20) c_u_clique_eqs(224)_ 1
     x(20) c_u_clique_eqs(228)_ 1
     x(20) c_u_clique_eqs(233)_ 1
     x(20) c_u_clique_eqs(251)_ 1
     x(20) c_u_clique_eqs(252)_ 1
     x(20) c_u_clique_eqs(253)_ 1
     x(20) c_u_clique_eqs(269)_ 1
     x(20) c_u_clique_eqs(271)_ 1
     x(20) c_u_clique_eqs(272)_ 1
     x(20) c_u_clique_eqs(276)_ 1
     x(20) c_u_clique_eqs(291)_ 1
     x(20) c_u_clique_eqs(294)_ 1
     x(21) obj -10.94
     x(21) c_u_edge_eqs(12)_ 1
     x(21) c_u_edge_eqs(37)_ 1
     x(21) c_u_edge_eqs(58)_ 1
     x(21) c_u_edge_eqs(226)_ 1
     x(21) c_u_edge_eqs(265)_ 1
     x(21) c_u_edge_eqs(285)_ 1
     x(21) c_u_edge_eqs(320)_ 1
     x(21) c_u_edge_eqs(336)_ 1
     x(21) c_u_edge_eqs(369)_ 1
     x(21) c_u_edge_eqs(383)_ 1
     x(21) c_u_edge_eqs(408)_ 1
     x(21) c_u_edge_eqs(409)_ 1
     x(21) c_u_edge_eqs(410)_ 1
     x(21) c_u_edge_eqs(411)_ 1
     x(21) c_u_edge_eqs(412)_ 1
     x(21) c_u_edge_eqs(413)_ 1
     x(21) c_u_edge_eqs(414)_ 1
     x(21) c_u_edge_eqs(415)_ 1
     x(21) c_u_edge_eqs(416)_ 1
     x(21) c_u_edge_eqs(417)_ 1
     x(21) c_u_edge_eqs(418)_ 1
     x(21) c_u_clique_eqs(47)_ 1
     x(21) c_u_clique_eqs(64)_ 1
     x(21) c_u_clique_eqs(66)_ 1
     x(21) c_u_clique_eqs(68)_ 1
     x(21) c_u_clique_eqs(69)_ 1
     x(21) c_u_clique_eqs(70)_ 1
     x(21) c_u_clique_eqs(71)_ 1
     x(21) c_u_clique_eqs(108)_ 1
     x(21) c_u_clique_eqs(133)_ 1
     x(21) c_u_clique_eqs(137)_ 1
     x(21) c_u_clique_eqs(166)_ 1
     x(21) c_u_clique_eqs(171)_ 1
     x(21) c_u_clique_eqs(198)_ 1
     x(21) c_u_clique_eqs(199)_ 1
     x(21) c_u_clique_eqs(203)_ 1
     x(21) c_u_clique_eqs(218)_ 1
     x(21) c_u_clique_eqs(219)_ 1
     x(21) c_u_clique_eqs(226)_ 1
     x(21) c_u_clique_eqs(227)_ 1
     x(21) c_u_clique_eqs(229)_ 1
     x(21) c_u_clique_eqs(230)_ 1
     x(21) c_u_clique_eqs(300)_ 1
     x(21) c_u_clique_eqs(301)_ 1
     x(21) c_u_clique_eqs(311)_ 1
     x(21) c_u_clique_eqs(313)_ 1
     x(21) c_u_clique_eqs(317)_ 1
     x(21) c_u_clique_eqs(318)_ 1
     x(21) c_u_clique_eqs(319)_ 1
     x(21) c_u_clique_eqs(320)_ 1
     x(21) c_u_clique_eqs(321)_ 1
     x(21) c_u_clique_eqs(327)_ 1
     x(21) c_u_clique_eqs(328)_ 1
     x(22) obj -9.9199999999999999
     x(22) c_u_edge_eqs(59)_ 1
     x(22) c_u_edge_eqs(125)_ 1
     x(22) c_u_edge_eqs(150)_ 1
     x(22) c_u_edge_eqs(206)_ 1
     x(22) c_u_edge_eqs(227)_ 1
     x(22) c_u_edge_eqs(247)_ 1
     x(22) c_u_edge_eqs(286)_ 1
     x(22) c_u_edge_eqs(303)_ 1
     x(22) c_u_edge_eqs(384)_ 1
     x(22) c_u_edge_eqs(408)_ 1
     x(22) c_u_edge_eqs(419)_ 1
     x(22) c_u_edge_eqs(420)_ 1
     x(22) c_u_edge_eqs(421)_ 1
     x(22) c_u_edge_eqs(422)_ 1
     x(22) c_u_edge_eqs(423)_ 1
     x(22) c_u_edge_eqs(424)_ 1
     x(22) c_u_edge_eqs(425)_ 1
     x(22) c_u_edge_eqs(426)_ 1
     x(22) c_u_edge_eqs(427)_ 1
     x(22) c_u_edge_eqs(428)_ 1
     x(22) c_u_edge_eqs(429)_ 1
     x(22) c_u_edge_eqs(430)_ 1
     x(22) c_u_edge_eqs(431)_ 1
     x(22) c_u_edge_eqs(432)_ 1
     x(22) c_u_clique_eqs(112)_ 1
     x(22) c_u_clique_eqs(213)_ 1
     x(22) c_u_clique_eqs(234)_ 1
     x(22) c_u_clique_eqs(235)_ 1
     x(22) c_u_clique_eqs(236)_ 1
     x(22) c_u_clique_eqs(258)_ 1
     x(22) c_u_clique_eqs(298)_ 1
     x(22) c_u_clique_eqs(302)_ 1
     x(22) c_u_clique_eqs(304)_ 1
     x(23) obj -9.5600000000000005
     x(23) c_u_edge_eqs(13)_ 1
     x(23) c_u_edge_eqs(126)_ 1
     x(23) c_u_edge_eqs(151)_ 1
     x(23) c_u_edge_eqs(207)_ 1
     x(23) c_u_edge_eqs(248)_ 1
     x(23) c_u_edge_eqs(266)_ 1
     x(23) c_u_edge_eqs(287)_ 1
     x(23) c_u_edge_eqs(304)_ 1
     x(23) c_u_edge_eqs(321)_ 1
     x(23) c_u_edge_eqs(353)_ 1
     x(23) c_u_edge_eqs(396)_ 1
     x(23) c_u_edge_eqs(433)_ 1
     x(23) c_u_edge_eqs(434)_ 1
     x(23) c_u_edge_eqs(435)_ 1
     x(23) c_u_edge_eqs(436)_ 1
     x(23) c_u_edge_eqs(437)_ 1
     x(23) c_u_edge_eqs(438)_ 1
     x(23) c_u_edge_eqs(439)_ 1
     x(23) c_u_edge_eqs(440)_ 1
     x(23) c_u_edge_eqs(441)_ 1
     x(23) c_u_edge_eqs(442)_ 1
     x(23) c_u_edge_eqs(443)_ 1
     x(23) c_u_edge_eqs(444)_ 1
     x(23) c_u_edge_eqs(445)_ 1
     x(23) c_u_edge_eqs(446)_ 1
     x(23) c_u_clique_eqs(4)_ 1
     x(23) c_u_clique_eqs(13)_ 1
     x(23) c_u_clique_eqs(25)_ 1
     x(23) c_u_clique_eqs(120)_ 1
     x(23) c_u_clique_eqs(121)_ 1
     x(23) c_u_clique_eqs(122)_ 1
     x(23) c_u_clique_eqs(123)_ 1
     x(23) c_u_clique_eqs(124)_ 1
     x(23) c_u_clique_eqs(126)_ 1
     x(23) c_u_clique_eqs(127)_ 1
     x(23) c_u_clique_eqs(136)_ 1
     x(23) c_u_clique_eqs(154)_ 1
     x(23) c_u_clique_eqs(194)_ 1
     x(23) c_u_clique_eqs(207)_ 1
     x(23) c_u_clique_eqs(216)_ 1
     x(23) c_u_clique_eqs(248)_ 1
     x(23) c_u_clique_eqs(250)_ 1
     x(23) c_u_clique_eqs(252)_ 1
     x(23) c_u_clique_eqs(253)_ 1
     x(23) c_u_clique_eqs(254)_ 1
     x(23) c_u_clique_eqs(255)_ 1
     x(23) c_u_clique_eqs(262)_ 1
     x(23) c_u_clique_eqs(263)_ 1
     x(23) c_u_clique_eqs(278)_ 1
     x(23) c_u_clique_eqs(307)_ 1
     x(23) c_u_clique_eqs(308)_ 1
     x(23) c_u_clique_eqs(309)_ 1
     x(23) c_u_clique_eqs(323)_ 1
     x(23) c_u_clique_eqs(324)_ 1
     x(23) c_u_clique_eqs(325)_ 1
     x(24) obj -9.8900000000000006
     x(24) c_u_edge_eqs(38)_ 1
     x(24) c_u_edge_eqs(78)_ 1
     x(24) c_u_edge_eqs(104)_ 1
     x(24) c_u_edge_eqs(127)_ 1
     x(24) c_u_edge_eqs(152)_ 1
     x(24) c_u_edge_eqs(169)_ 1
     x(24) c_u_edge_eqs(191)_ 1
     x(24) c_u_edge_eqs(228)_ 1
     x(24) c_u_edge_eqs(249)_ 1
     x(24) c_u_edge_eqs(354)_ 1
     x(24) c_u_edge_eqs(385)_ 1
     x(24) c_u_edge_eqs(419)_ 1
     x(24) c_u_edge_eqs(433)_ 1
     x(24) c_u_edge_eqs(447)_ 1
     x(24) c_u_edge_eqs(448)_ 1
     x(24) c_u_edge_eqs(449)_ 1
     x(24) c_u_edge_eqs(450)_ 1
     x(24) c_u_edge_eqs(451)_ 1
     x(24) c_u_edge_eqs(452)_ 1
     x(24) c_u_edge_eqs(453)_ 1
     x(24) c_u_clique_eqs(17)_ 1
     x(24) c_u_clique_eqs(99)_ 1
     x(24) c_u_clique_eqs(112)_ 1
     x(24) c_u_clique_eqs(113)_ 1
     x(24) c_u_clique_eqs(114)_ 1
     x(24) c_u_clique_eqs(115)_ 1
     x(24) c_u_clique_eqs(116)_ 1
     x(24) c_u_clique_eqs(232)_ 1
     x(24) c_u_clique_eqs(234)_ 1
     x(24) c_u_clique_eqs(235)_ 1
     x(24) c_u_clique_eqs(237)_ 1
     x(24) c_u_clique_eqs(238)_ 1
     x(24) c_u_clique_eqs(239)_ 1
     x(24) c_u_clique_eqs(240)_ 1
     x(24) c_u_clique_eqs(241)_ 1
     x(24) c_u_clique_eqs(242)_ 1
     x(25) obj -10.630000000000001
     x(25) c_u_edge_eqs(14)_ 1
     x(25) c_u_edge_eqs(39)_ 1
     x(25) c_u_edge_eqs(79)_ 1
     x(25) c_u_edge_eqs(128)_ 1
     x(25) c_u_edge_eqs(170)_ 1
     x(25) c_u_edge_eqs(229)_ 1
     x(25) c_u_edge_eqs(250)_ 1
     x(25) c_u_edge_eqs(267)_ 1
     x(25) c_u_edge_eqs(288)_ 1
     x(25) c_u_edge_eqs(322)_ 1
     x(25) c_u_edge_eqs(337)_ 1
     x(25) c_u_edge_eqs(355)_ 1
     x(25) c_u_edge_eqs(370)_ 1
     x(25) c_u_edge_eqs(397)_ 1
     x(25) c_u_edge_eqs(420)_ 1
     x(25) c_u_edge_eqs(454)_ 1
     x(25) c_u_edge_eqs(455)_ 1
     x(25) c_u_edge_eqs(456)_ 1
     x(25) c_u_edge_eqs(457)_ 1
     x(25) c_u_edge_eqs(458)_ 1
     x(25) c_u_edge_eqs(459)_ 1
     x(25) c_u_edge_eqs(460)_ 1
     x(25) c_u_edge_eqs(461)_ 1
     x(25) c_u_edge_eqs(462)_ 1
     x(25) c_u_edge_eqs(463)_ 1
     x(25) c_u_edge_eqs(464)_ 1
     x(25) c_u_edge_eqs(465)_ 1
     x(25) c_u_clique_eqs(8)_ 1
     x(25) c_u_clique_eqs(9)_ 1
     x(25) c_u_clique_eqs(10)_ 1
     x(25) c_u_clique_eqs(11)_ 1
     x(25) c_u_clique_eqs(12)_ 1
     x(25) c_u_clique_eqs(14)_ 1
     x(25) c_u_clique_eqs(16)_ 1
     x(25) c_u_clique_eqs(30)_ 1
     x(25) c_u_clique_eqs(31)_ 1
     x(25) c_u_clique_eqs(32)_ 1
     x(25) c_u_clique_eqs(35)_ 1
     x(25) c_u_clique_eqs(38)_ 1
     x(25) c_u_clique_eqs(41)_ 1
     x(25) c_u_clique_eqs(51)_ 1
     x(25) c_u_clique_eqs(52)_ 1
     x(25) c_u_clique_eqs(53)_ 1
     x(25) c_u_clique_eqs(54)_ 1
     x(25) c_u_clique_eqs(63)_ 1
     x(25) c_u_clique_eqs(67)_ 1
     x(25) c_u_clique_eqs(80)_ 1
     x(25) c_u_clique_eqs(90)_ 1
     x(25) c_u_clique_eqs(91)_ 1
     x(25) c_u_clique_eqs(92)_ 1
     x(25) c_u_clique_eqs(100)_ 1
     x(25) c_u_clique_eqs(107)_ 1
     x(25) c_u_clique_eqs(129)_ 1
     x(25) c_u_clique_eqs(138)_ 1
     x(25) c_u_clique_eqs(139)_ 1
     x(25) c_u_clique_eqs(148)_ 1
     x(25) c_u_clique_eqs(160)_ 1
     x(25) c_u_clique_eqs(161)_ 1
     x(25) c_u_clique_eqs(162)_ 1
     x(25) c_u_clique_eqs(164)_ 1
     x(25) c_u_clique_eqs(165)_ 1
     x(25) c_u_clique_eqs(178)_ 1
     x(25) c_u_clique_eqs(180)_ 1
     x(25) c_u_clique_eqs(182)_ 1
     x(25) c_u_clique_eqs(185)_ 1
     x(25) c_u_clique_eqs(186)_ 1
     x(25) c_u_clique_eqs(187)_ 1
     x(25) c_u_clique_eqs(188)_ 1
     x(25) c_u_clique_eqs(196)_ 1
     x(25) c_u_clique_eqs(202)_ 1
     x(25) c_u_clique_eqs(211)_ 1
     x(25) c_u_clique_eqs(212)_ 1
     x(25) c_u_clique_eqs(213)_ 1
     x(25) c_u_clique_eqs(214)_ 1
     x(25) c_u_clique_eqs(215)_ 1
     x(25) c_u_clique_eqs(225)_ 1
     x(25) c_u_clique_eqs(228)_ 1
     x(25) c_u_clique_eqs(243)_ 1
     x(25) c_u_clique_eqs(244)_ 1
     x(25) c_u_clique_eqs(282)_ 1
     x(25) c_u_clique_eqs(289)_ 1
     x(26) obj -10.85
     x(26) c_u_edge_eqs(15)_ 1
     x(26) c_u_edge_eqs(60)_ 1
     x(26) c_u_edge_eqs(171)_ 1
     x(26) c_u_edge_eqs(208)_ 1
     x(26) c_u_edge_eqs(251)_ 1
     x(26) c_u_edge_eqs(305)_ 1
     x(26) c_u_edge_eqs(323)_ 1
     x(26) c_u_edge_eqs(338)_ 1
     x(26) c_u_edge_eqs(371)_ 1
     x(26) c_u_edge_eqs(421)_ 1
     x(26) c_u_edge_eqs(447)_ 1
     x(26) c_u_edge_eqs(454)_ 1
     x(26) c_u_edge_eqs(466)_ 1
     x(26) c_u_edge_eqs(467)_ 1
     x(26) c_u_edge_eqs(468)_ 1
     x(26) c_u_edge_eqs(469)_ 1
     x(26) c_u_edge_eqs(470)_ 1
     x(26) c_u_edge_eqs(471)_ 1
     x(26) c_u_edge_eqs(472)_ 1
     x(26) c_u_edge_eqs(473)_ 1
     x(26) c_u_edge_eqs(474)_ 1
     x(26) c_u_edge_eqs(475)_ 1
     x(26) c_u_clique_eqs(21)_ 1
     x(26) c_u_clique_eqs(24)_ 1
     x(26) c_u_clique_eqs(27)_ 1
     x(26) c_u_clique_eqs(28)_ 1
     x(26) c_u_clique_eqs(29)_ 1
     x(26) c_u_clique_eqs(35)_ 1
     x(26) c_u_clique_eqs(36)_ 1
     x(26) c_u_clique_eqs(42)_ 1
     x(26) c_u_clique_eqs(93)_ 1
     x(26) c_u_clique_eqs(94)_ 1
     x(26) c_u_clique_eqs(95)_ 1
     x(26) c_u_clique_eqs(100)_ 1
     x(26) c_u_clique_eqs(101)_ 1
     x(26) c_u_clique_eqs(102)_ 1
     x(26) c_u_clique_eqs(104)_ 1
     x(26) c_u_clique_eqs(117)_ 1
     x(26) c_u_clique_eqs(118)_ 1
     x(26) c_u_clique_eqs(119)_ 1
     x(26) c_u_clique_eqs(138)_ 1
     x(26) c_u_clique_eqs(139)_ 1
     x(26) c_u_clique_eqs(141)_ 1
     x(26) c_u_clique_eqs(142)_ 1
     x(26) c_u_clique_eqs(143)_ 1
     x(26) c_u_clique_eqs(148)_ 1
     x(26) c_u_clique_eqs(149)_ 1
     x(26) c_u_clique_eqs(150)_ 1
     x(26) c_u_clique_eqs(151)_ 1
     x(26) c_u_clique_eqs(152)_ 1
     x(26) c_u_clique_eqs(153)_ 1
     x(26) c_u_clique_eqs(163)_ 1
     x(26) c_u_clique_eqs(182)_ 1
     x(26) c_u_clique_eqs(184)_ 1
     x(26) c_u_clique_eqs(185)_ 1
     x(26) c_u_clique_eqs(186)_ 1
     x(26) c_u_clique_eqs(187)_ 1
     x(26) c_u_clique_eqs(188)_ 1
     x(26) c_u_clique_eqs(189)_ 1
     x(26) c_u_clique_eqs(190)_ 1
     x(26) c_u_clique_eqs(217)_ 1
     x(26) c_u_clique_eqs(243)_ 1
     x(26) c_u_clique_eqs(244)_ 1
     x(26) c_u_clique_eqs(245)_ 1
     x(26) c_u_clique_eqs(246)_ 1
     x(26) c_u_clique_eqs(256)_ 1
     x(26) c_u_clique_eqs(257)_ 1
     x(26) c_u_clique_eqs(258)_ 1
     x(26) c_u_clique_eqs(259)_ 1
     x(26) c_u_clique_eqs(260)_ 1
     x(26) c_u_clique_eqs(277)_ 1
     x(26) c_u_clique_eqs(322)_ 1
     x(26) c_u_clique_eqs(329)_ 1
     x(27) obj -11.27
     x(27) c_u_edge_eqs(16)_ 1
     x(27) c_u_edge_eqs(40)_ 1
     x(27) c_u_edge_eqs(105)_ 1
     x(27) c_u_edge_eqs(172)_ 1
     x(27) c_u_edge_eqs(252)_ 1
     x(27) c_u_edge_eqs(289)_ 1
     x(27) c_u_edge_eqs(324)_ 1
     x(27) c_u_edge_eqs(339)_ 1
     x(27) c_u_edge_eqs(356)_ 1
     x(27) c_u_edge_eqs(372)_ 1
     x(27) c_u_edge_eqs(466)_ 1
     x(27) c_u_edge_eqs(476)_ 1
     x(27) c_u_edge_eqs(477)_ 1
     x(27) c_u_edge_eqs(478)_ 1
     x(27) c_u_edge_eqs(479)_ 1
     x(27) c_u_edge_eqs(480)_ 1
     x(27) c_u_edge_eqs(481)_ 1
     x(27) c_u_edge_eqs(482)_ 1
     x(27) c_u_edge_eqs(483)_ 1
     x(27) c_u_edge_eqs(484)_ 1
     x(27) c_u_edge_eqs(485)_ 1
     x(27) c_u_edge_eqs(486)_ 1
     x(27) c_u_edge_eqs(487)_ 1
     x(27) c_u_clique_eqs(15)_ 1
     x(27) c_u_clique_eqs(18)_ 1
     x(27) c_u_clique_eqs(19)_ 1
     x(27) c_u_clique_eqs(27)_ 1
     x(27) c_u_clique_eqs(29)_ 1
     x(27) c_u_clique_eqs(33)_ 1
     x(27) c_u_clique_eqs(34)_ 1
     x(27) c_u_clique_eqs(36)_ 1
     x(27) c_u_clique_eqs(39)_ 1
     x(27) c_u_clique_eqs(40)_ 1
     x(27) c_u_clique_eqs(42)_ 1
     x(27) c_u_clique_eqs(61)_ 1
     x(27) c_u_clique_eqs(81)_ 1
     x(27) c_u_clique_eqs(93)_ 1
     x(27) c_u_clique_eqs(96)_ 1
     x(27) c_u_clique_eqs(97)_ 1
     x(27) c_u_clique_eqs(98)_ 1
     x(27) c_u_clique_eqs(101)_ 1
     x(27) c_u_clique_eqs(117)_ 1
     x(27) c_u_clique_eqs(128)_ 1
     x(27) c_u_clique_eqs(130)_ 1
     x(27) c_u_clique_eqs(142)_ 1
     x(27) c_u_clique_eqs(151)_ 1
     x(27) c_u_clique_eqs(152)_ 1
     x(27) c_u_clique_eqs(189)_ 1
     x(27) c_u_clique_eqs(190)_ 1
     x(27) c_u_clique_eqs(217)_ 1
     x(27) c_u_clique_eqs(245)_ 1
     x(27) c_u_clique_eqs(246)_ 1
     x(27) c_u_clique_eqs(247)_ 1
     x(27) c_u_clique_eqs(279)_ 1
     x(27) c_u_clique_eqs(280)_ 1
     x(27) c_u_clique_eqs(281)_ 1
     x(27) c_u_clique_eqs(283)_ 1
     x(27) c_u_clique_eqs(284)_ 1
     x(27) c_u_clique_eqs(285)_ 1
     x(27) c_u_clique_eqs(288)_ 1
     x(27) c_u_clique_eqs(290)_ 1
     x(27) c_u_clique_eqs(293)_ 1
     x(28) obj -9.5500000000000007
     x(28) c_u_edge_eqs(41)_ 1
     x(28) c_u_edge_eqs(80)_ 1
     x(28) c_u_edge_eqs(129)_ 1
     x(28) c_u_edge_eqs(153)_ 1
     x(28) c_u_edge_eqs(209)_ 1
     x(28) c_u_edge_eqs(230)_ 1
     x(28) c_u_edge_eqs(253)_ 1
     x(28) c_u_edge_eqs(268)_ 1
     x(28) c_u_edge_eqs(306)_ 1
     x(28) c_u_edge_eqs(357)_ 1
     x(28) c_u_edge_eqs(398)_ 1
     x(28) c_u_edge_eqs(409)_ 1
     x(28) c_u_edge_eqs(422)_ 1
     x(28) c_u_edge_eqs(434)_ 1
     x(28) c_u_edge_eqs(455)_ 1
     x(28) c_u_edge_eqs(488)_ 1
     x(28) c_u_edge_eqs(489)_ 1
     x(28) c_u_edge_eqs(490)_ 1
     x(28) c_u_edge_eqs(491)_ 1
     x(28) c_u_edge_eqs(492)_ 1
     x(28) c_u_edge_eqs(493)_ 1
     x(28) c_u_edge_eqs(494)_ 1
     x(28) c_u_edge_eqs(495)_ 1
     x(28) c_u_edge_eqs(496)_ 1
     x(28) c_u_edge_eqs(497)_ 1
     x(28) c_u_clique_eqs(2)_ 1
     x(28) c_u_clique_eqs(8)_ 1
     x(28) c_u_clique_eqs(10)_ 1
     x(28) c_u_clique_eqs(16)_ 1
     x(28) c_u_clique_eqs(30)_ 1
     x(28) c_u_clique_eqs(31)_ 1
     x(28) c_u_clique_eqs(32)_ 1
     x(28) c_u_clique_eqs(47)_ 1
     x(28) c_u_clique_eqs(49)_ 1
     x(28) c_u_clique_eqs(51)_ 1
     x(28) c_u_clique_eqs(52)_ 1
     x(28) c_u_clique_eqs(60)_ 1
     x(28) c_u_clique_eqs(70)_ 1
     x(28) c_u_clique_eqs(71)_ 1
     x(28) c_u_clique_eqs(107)_ 1
     x(28) c_u_clique_eqs(108)_ 1
     x(28) c_u_clique_eqs(109)_ 1
     x(28) c_u_clique_eqs(110)_ 1
     x(28) c_u_clique_eqs(120)_ 1
     x(28) c_u_clique_eqs(121)_ 1
     x(28) c_u_clique_eqs(124)_ 1
     x(28) c_u_clique_eqs(134)_ 1
     x(28) c_u_clique_eqs(136)_ 1
     x(28) c_u_clique_eqs(154)_ 1
     x(28) c_u_clique_eqs(160)_ 1
     x(28) c_u_clique_eqs(162)_ 1
     x(28) c_u_clique_eqs(164)_ 1
     x(28) c_u_clique_eqs(171)_ 1
     x(28) c_u_clique_eqs(178)_ 1
     x(28) c_u_clique_eqs(179)_ 1
     x(28) c_u_clique_eqs(180)_ 1
     x(28) c_u_clique_eqs(205)_ 1
     x(28) c_u_clique_eqs(208)_ 1
     x(28) c_u_clique_eqs(212)_ 1
     x(28) c_u_clique_eqs(213)_ 1
     x(28) c_u_clique_eqs(214)_ 1
     x(28) c_u_clique_eqs(215)_ 1
     x(28) c_u_clique_eqs(221)_ 1
     x(28) c_u_clique_eqs(224)_ 1
     x(28) c_u_clique_eqs(231)_ 1
     x(28) c_u_clique_eqs(233)_ 1
     x(28) c_u_clique_eqs(248)_ 1
     x(28) c_u_clique_eqs(249)_ 1
     x(28) c_u_clique_eqs(250)_ 1
     x(28) c_u_clique_eqs(251)_ 1
     x(28) c_u_clique_eqs(253)_ 1
     x(28) c_u_clique_eqs(254)_ 1
     x(28) c_u_clique_eqs(255)_ 1
     x(28) c_u_clique_eqs(264)_ 1
     x(28) c_u_clique_eqs(267)_ 1
     x(28) c_u_clique_eqs(274)_ 1
     x(28) c_u_clique_eqs(275)_ 1
     x(28) c_u_clique_eqs(276)_ 1
     x(28) c_u_clique_eqs(317)_ 1
     x(28) c_u_clique_eqs(327)_ 1
     x(28) c_u_clique_eqs(328)_ 1
     x(29) obj -10.07
     x(29) c_u_edge_eqs(17)_ 1
     x(29) c_u_edge_eqs(81)_ 1
     x(29) c_u_edge_eqs(106)_ 1
     x(29) c_u_edge_eqs(130)_ 1
     x(29) c_u_edge_eqs(173)_ 1
     x(29) c_u_edge_eqs(231)_ 1
     x(29) c_u_edge_eqs(254)_ 1
     x(29) c_u_edge_eqs(269)_ 1
     x(29) c_u_edge_eqs(290)_ 1
     x(29) c_u_edge_eqs(325)_ 1
     x(29) c_u_edge_eqs(373)_ 1
     x(29) c_u_edge_eqs(399)_ 1
     x(29) c_u_edge_eqs(410)_ 1
     x(29) c_u_edge_eqs(467)_ 1
     x(29) c_u_edge_eqs(476)_ 1
     x(29) c_u_edge_eqs(488)_ 1
     x(29) c_u_edge_eqs(498)_ 1
     x(29) c_u_edge_eqs(499)_ 1
     x(29) c_u_edge_eqs(500)_ 1
     x(29) c_u_edge_eqs(501)_ 1
     x(29) c_u_edge_eqs(502)_ 1
     x(29) c_u_edge_eqs(503)_ 1
     x(29) c_u_edge_eqs(504)_ 1
     x(29) c_u_edge_eqs(505)_ 1
     x(29) c_u_edge_eqs(506)_ 1
     x(29) c_u_clique_eqs(29)_ 1
     x(29) c_u_clique_eqs(34)_ 1
     x(29) c_u_clique_eqs(36)_ 1
     x(29) c_u_clique_eqs(40)_ 1
     x(29) c_u_clique_eqs(42)_ 1
     x(29) c_u_clique_eqs(68)_ 1
     x(29) c_u_clique_eqs(69)_ 1
     x(29) c_u_clique_eqs(101)_ 1
     x(29) c_u_clique_eqs(102)_ 1
     x(29) c_u_clique_eqs(104)_ 1
     x(29) c_u_clique_eqs(105)_ 1
     x(29) c_u_clique_eqs(106)_ 1
     x(29) c_u_clique_eqs(117)_ 1
     x(29) c_u_clique_eqs(118)_ 1
     x(29) c_u_clique_eqs(142)_ 1
     x(29) c_u_clique_eqs(149)_ 1
     x(29) c_u_clique_eqs(150)_ 1
     x(29) c_u_clique_eqs(151)_ 1
     x(29) c_u_clique_eqs(152)_ 1
     x(29) c_u_clique_eqs(153)_ 1
     x(29) c_u_clique_eqs(189)_ 1
     x(29) c_u_clique_eqs(190)_ 1
     x(29) c_u_clique_eqs(203)_ 1
     x(29) c_u_clique_eqs(205)_ 1
     x(29) c_u_clique_eqs(208)_ 1
     x(29) c_u_clique_eqs(217)_ 1
     x(29) c_u_clique_eqs(221)_ 1
     x(29) c_u_clique_eqs(229)_ 1
     x(29) c_u_clique_eqs(230)_ 1
     x(29) c_u_clique_eqs(231)_ 1
     x(29) c_u_clique_eqs(245)_ 1
     x(29) c_u_clique_eqs(246)_ 1
     x(29) c_u_clique_eqs(281)_ 1
     x(29) c_u_clique_eqs(284)_ 1
     x(29) c_u_clique_eqs(291)_ 1
     x(29) c_u_clique_eqs(292)_ 1
     x(29) c_u_clique_eqs(293)_ 1
     x(29) c_u_clique_eqs(294)_ 1
     x(29) c_u_clique_eqs(320)_ 1
     x(30) obj -10.43
     x(30) c_u_edge_eqs(61)_ 1
     x(30) c_u_edge_eqs(82)_ 1
     x(30) c_u_edge_eqs(107)_ 1
     x(30) c_u_edge_eqs(174)_ 1
     x(30) c_u_edge_eqs(210)_ 1
     x(30) c_u_edge_eqs(232)_ 1
     x(30) c_u_edge_eqs(270)_ 1
     x(30) c_u_edge_eqs(326)_ 1
     x(30) c_u_edge_eqs(374)_ 1
     x(30) c_u_edge_eqs(423)_ 1
     x(30) c_u_edge_eqs(448)_ 1
     x(30) c_u_edge_eqs(507)_ 1
     x(30) c_u_edge_eqs(508)_ 1
     x(30) c_u_edge_eqs(509)_ 1
     x(30) c_u_edge_eqs(510)_ 1
     x(30) c_u_edge_eqs(511)_ 1
     x(30) c_u_edge_eqs(512)_ 1
     x(30) c_u_clique_eqs(44)_ 1
     x(30) c_u_clique_eqs(45)_ 1
     x(30) c_u_clique_eqs(48)_ 1
     x(30) c_u_clique_eqs(78)_ 1
     x(30) c_u_clique_eqs(79)_ 1
     x(30) c_u_clique_eqs(111)_ 1
     x(30) c_u_clique_eqs(146)_ 1
     x(30) c_u_clique_eqs(147)_ 1
     x(30) c_u_clique_eqs(156)_ 1
     x(30) c_u_clique_eqs(175)_ 1
     x(30) c_u_clique_eqs(176)_ 1
     x(30) c_u_clique_eqs(177)_ 1
     x(30) c_u_clique_eqs(183)_ 1
     x(30) c_u_clique_eqs(220)_ 1
     x(30) c_u_clique_eqs(235)_ 1
     x(30) c_u_clique_eqs(242)_ 1
     x(30) c_u_clique_eqs(299)_ 1
     x(30) c_u_clique_eqs(310)_ 1
     x(31) obj -9.5999999999999996
     x(31) c_u_edge_eqs(83)_ 1
     x(31) c_u_edge_eqs(131)_ 1
     x(31) c_u_edge_eqs(154)_ 1
     x(31) c_u_edge_eqs(233)_ 1
     x(31) c_u_edge_eqs(255)_ 1
     x(31) c_u_edge_eqs(271)_ 1
     x(31) c_u_edge_eqs(340)_ 1
     x(31) c_u_edge_eqs(358)_ 1
     x(31) c_u_edge_eqs(386)_ 1
     x(31) c_u_edge_eqs(400)_ 1
     x(31) c_u_edge_eqs(411)_ 1
     x(31) c_u_edge_eqs(435)_ 1
     x(31) c_u_edge_eqs(449)_ 1
     x(31) c_u_edge_eqs(456)_ 1
     x(31) c_u_edge_eqs(468)_ 1
     x(31) c_u_edge_eqs(489)_ 1
     x(31) c_u_edge_eqs(498)_ 1
     x(31) c_u_edge_eqs(507)_ 1
     x(31) c_u_edge_eqs(513)_ 1
     x(31) c_u_edge_eqs(514)_ 1
     x(31) c_u_edge_eqs(515)_ 1
     x(31) c_u_edge_eqs(516)_ 1
     x(31) c_u_edge_eqs(517)_ 1
     x(31) c_u_edge_eqs(518)_ 1
     x(31) c_u_edge_eqs(519)_ 1
     x(31) c_u_edge_eqs(520)_ 1
     x(31) c_u_edge_eqs(521)_ 1
     x(31) c_u_edge_eqs(522)_ 1
     x(31) c_u_edge_eqs(523)_ 1
     x(31) c_u_edge_eqs(524)_ 1
     x(31) c_u_clique_eqs(1)_ 1
     x(31) c_u_clique_eqs(6)_ 1
     x(31) c_u_clique_eqs(10)_ 1
     x(31) c_u_clique_eqs(12)_ 1
     x(31) c_u_clique_eqs(28)_ 1
     x(31) c_u_clique_eqs(32)_ 1
     x(31) c_u_clique_eqs(35)_ 1
     x(31) c_u_clique_eqs(41)_ 1
     x(31) c_u_clique_eqs(44)_ 1
     x(31) c_u_clique_eqs(52)_ 1
     x(31) c_u_clique_eqs(54)_ 1
     x(31) c_u_clique_eqs(56)_ 1
     x(31) c_u_clique_eqs(59)_ 1
     x(31) c_u_clique_eqs(70)_ 1
     x(31) c_u_clique_eqs(77)_ 1
     x(31) c_u_clique_eqs(88)_ 1
     x(31) c_u_clique_eqs(89)_ 1
     x(31) c_u_clique_eqs(92)_ 1
     x(31) c_u_clique_eqs(95)_ 1
     x(31) c_u_clique_eqs(104)_ 1
     x(31) c_u_clique_eqs(105)_ 1
     x(31) c_u_clique_eqs(106)_ 1
     x(31) c_u_clique_eqs(111)_ 1
     x(31) c_u_clique_eqs(123)_ 1
     x(31) c_u_clique_eqs(127)_ 1
     x(31) c_u_clique_eqs(129)_ 1
     x(31) c_u_clique_eqs(150)_ 1
     x(31) c_u_clique_eqs(158)_ 1
     x(31) c_u_clique_eqs(159)_ 1
     x(31) c_u_clique_eqs(160)_ 1
     x(31) c_u_clique_eqs(162)_ 1
     x(31) c_u_clique_eqs(164)_ 1
     x(31) c_u_clique_eqs(165)_ 1
     x(31) c_u_clique_eqs(169)_ 1
     x(31) c_u_clique_eqs(170)_ 1
     x(31) c_u_clique_eqs(171)_ 1
     x(31) c_u_clique_eqs(180)_ 1
     x(31) c_u_clique_eqs(183)_ 1
     x(31) c_u_clique_eqs(191)_ 1
     x(31) c_u_clique_eqs(205)_ 1
     x(31) c_u_clique_eqs(206)_ 1
     x(31) c_u_clique_eqs(207)_ 1
     x(31) c_u_clique_eqs(208)_ 1
     x(31) c_u_clique_eqs(209)_ 1
     x(31) c_u_clique_eqs(212)_ 1
     x(31) c_u_clique_eqs(214)_ 1
     x(31) c_u_clique_eqs(215)_ 1
     x(31) c_u_clique_eqs(221)_ 1
     x(31) c_u_clique_eqs(222)_ 1
     x(31) c_u_clique_eqs(223)_ 1
     x(31) c_u_clique_eqs(231)_ 1
     x(31) c_u_clique_eqs(272)_ 1
     x(31) c_u_clique_eqs(273)_ 1
     x(31) c_u_clique_eqs(292)_ 1
     x(31) c_u_clique_eqs(303)_ 1
     x(31) c_u_clique_eqs(309)_ 1
     x(31) c_u_clique_eqs(317)_ 1
     x(31) c_u_clique_eqs(325)_ 1
     x(32) obj -9.3000000000000007
     x(32) c_u_edge_eqs(42)_ 1
     x(32) c_u_edge_eqs(62)_ 1
     x(32) c_u_edge_eqs(84)_ 1
     x(32) c_u_edge_eqs(108)_ 1
     x(32) c_u_edge_eqs(155)_ 1
     x(32) c_u_edge_eqs(175)_ 1
     x(32) c_u_edge_eqs(234)_ 1
     x(32) c_u_edge_eqs(272)_ 1
     x(32) c_u_edge_eqs(291)_ 1
     x(32) c_u_edge_eqs(341)_ 1
     x(32) c_u_edge_eqs(436)_ 1
     x(32) c_u_edge_eqs(477)_ 1
     x(32) c_u_edge_eqs(513)_ 1
     x(32) c_u_edge_eqs(525)_ 1
     x(32) c_u_edge_eqs(526)_ 1
     x(32) c_u_edge_eqs(527)_ 1
     x(32) c_u_edge_eqs(528)_ 1
     x(32) c_u_edge_eqs(529)_ 1
     x(32) c_u_edge_eqs(530)_ 1
     x(32) c_u_edge_eqs(531)_ 1
     x(32) c_u_clique_eqs(13)_ 1
     x(32) c_u_clique_eqs(61)_ 1
     x(32) c_u_clique_eqs(62)_ 1
     x(32) c_u_clique_eqs(247)_ 1
     x(32) c_u_clique_eqs(261)_ 1
     x(32) c_u_clique_eqs(262)_ 1
     x(32) c_u_clique_eqs(285)_ 1
     x(32) c_u_clique_eqs(286)_ 1
     x(32) c_u_clique_eqs(287)_ 1
     x(32) c_u_clique_eqs(288)_ 1
     x(32) c_u_clique_eqs(297)_ 1
     x(32) c_u_clique_eqs(303)_ 1
     x(32) c_u_clique_eqs(312)_ 1
     x(32) c_u_clique_eqs(314)_ 1
     x(33) obj -10.59
     x(33) c_u_edge_eqs(18)_ 1
     x(33) c_u_edge_eqs(43)_ 1
     x(33) c_u_edge_eqs(132)_ 1
     x(33) c_u_edge_eqs(192)_ 1
     x(33) c_u_edge_eqs(235)_ 1
     x(33) c_u_edge_eqs(273)_ 1
     x(33) c_u_edge_eqs(292)_ 1
     x(33) c_u_edge_eqs(342)_ 1
     x(33) c_u_edge_eqs(375)_ 1
     x(33) c_u_edge_eqs(387)_ 1
     x(33) c_u_edge_eqs(401)_ 1
     x(33) c_u_edge_eqs(412)_ 1
     x(33) c_u_edge_eqs(424)_ 1
     x(33) c_u_edge_eqs(437)_ 1
     x(33) c_u_edge_eqs(457)_ 1
     x(33) c_u_edge_eqs(478)_ 1
     x(33) c_u_edge_eqs(525)_ 1
     x(33) c_u_edge_eqs(532)_ 1
     x(33) c_u_edge_eqs(533)_ 1
     x(33) c_u_edge_eqs(534)_ 1
     x(33) c_u_edge_eqs(535)_ 1
     x(33) c_u_edge_eqs(536)_ 1
     x(33) c_u_edge_eqs(537)_ 1
     x(33) c_u_edge_eqs(538)_ 1
     x(33) c_u_edge_eqs(539)_ 1
     x(33) c_u_clique_eqs(11)_ 1
     x(33) c_u_clique_eqs(13)_ 1
     x(33) c_u_clique_eqs(53)_ 1
     x(33) c_u_clique_eqs(61)_ 1
     x(33) c_u_clique_eqs(63)_ 1
     x(33) c_u_clique_eqs(80)_ 1
     x(33) c_u_clique_eqs(81)_ 1
     x(33) c_u_clique_eqs(82)_ 1
     x(33) c_u_clique_eqs(96)_ 1
     x(33) c_u_clique_eqs(122)_ 1
     x(33) c_u_clique_eqs(125)_ 1
     x(33) c_u_clique_eqs(126)_ 1
     x(33) c_u_clique_eqs(131)_ 1
     x(33) c_u_clique_eqs(194)_ 1
     x(33) c_u_clique_eqs(195)_ 1
     x(33) c_u_clique_eqs(198)_ 1
     x(33) c_u_clique_eqs(199)_ 1
     x(33) c_u_clique_eqs(200)_ 1
     x(33) c_u_clique_eqs(202)_ 1
     x(33) c_u_clique_eqs(216)_ 1
     x(33) c_u_clique_eqs(219)_ 1
     x(33) c_u_clique_eqs(252)_ 1
     x(33) c_u_clique_eqs(285)_ 1
     x(33) c_u_clique_eqs(289)_ 1
     x(33) c_u_clique_eqs(290)_ 1
     x(33) c_u_clique_eqs(306)_ 1
     x(33) c_u_clique_eqs(307)_ 1
     x(33) c_u_clique_eqs(311)_ 1
     x(33) c_u_clique_eqs(313)_ 1
     x(33) c_u_clique_eqs(315)_ 1
     x(34) obj -11.94
     x(34) c_u_edge_eqs(19)_ 1
     x(34) c_u_edge_eqs(44)_ 1
     x(34) c_u_edge_eqs(63)_ 1
     x(34) c_u_edge_eqs(156)_ 1
     x(34) c_u_edge_eqs(176)_ 1
     x(34) c_u_edge_eqs(193)_ 1
     x(34) c_u_edge_eqs(211)_ 1
     x(34) c_u_edge_eqs(274)_ 1
     x(34) c_u_edge_eqs(293)_ 1
     x(34) c_u_edge_eqs(307)_ 1
     x(34) c_u_edge_eqs(327)_ 1
     x(34) c_u_edge_eqs(343)_ 1
     x(34) c_u_edge_eqs(359)_ 1
     x(34) c_u_edge_eqs(388)_ 1
     x(34) c_u_edge_eqs(413)_ 1
     x(34) c_u_edge_eqs(438)_ 1
     x(34) c_u_edge_eqs(450)_ 1
     x(34) c_u_edge_eqs(458)_ 1
     x(34) c_u_edge_eqs(469)_ 1
     x(34) c_u_edge_eqs(490)_ 1
     x(34) c_u_edge_eqs(540)_ 1
     x(34) c_u_edge_eqs(541)_ 1
     x(34) c_u_edge_eqs(542)_ 1
     x(34) c_u_edge_eqs(543)_ 1
     x(34) c_u_edge_eqs(544)_ 1
     x(34) c_u_edge_eqs(545)_ 1
     x(34) c_u_clique_eqs(20)_ 1
     x(34) c_u_clique_eqs(21)_ 1
     x(34) c_u_clique_eqs(46)_ 1
     x(34) c_u_clique_eqs(64)_ 1
     x(34) c_u_clique_eqs(65)_ 1
     x(34) c_u_clique_eqs(66)_ 1
     x(34) c_u_clique_eqs(71)_ 1
     x(34) c_u_clique_eqs(73)_ 1
     x(34) c_u_clique_eqs(74)_ 1
     x(34) c_u_clique_eqs(75)_ 1
     x(34) c_u_clique_eqs(90)_ 1
     x(34) c_u_clique_eqs(100)_ 1
     x(34) c_u_clique_eqs(103)_ 1
     x(34) c_u_clique_eqs(113)_ 1
     x(34) c_u_clique_eqs(133)_ 1
     x(34) c_u_clique_eqs(134)_ 1
     x(34) c_u_clique_eqs(135)_ 1
     x(34) c_u_clique_eqs(136)_ 1
     x(34) c_u_clique_eqs(137)_ 1
     x(34) c_u_clique_eqs(138)_ 1
     x(34) c_u_clique_eqs(139)_ 1
     x(34) c_u_clique_eqs(143)_ 1
     x(34) c_u_clique_eqs(148)_ 1
     x(34) c_u_clique_eqs(163)_ 1
     x(34) c_u_clique_eqs(166)_ 1
     x(34) c_u_clique_eqs(167)_ 1
     x(34) c_u_clique_eqs(168)_ 1
     x(34) c_u_clique_eqs(172)_ 1
     x(34) c_u_clique_eqs(173)_ 1
     x(34) c_u_clique_eqs(174)_ 1
     x(34) c_u_clique_eqs(178)_ 1
     x(34) c_u_clique_eqs(179)_ 1
     x(34) c_u_clique_eqs(182)_ 1
     x(34) c_u_clique_eqs(184)_ 1
     x(34) c_u_clique_eqs(185)_ 1
     x(34) c_u_clique_eqs(188)_ 1
     x(34) c_u_clique_eqs(204)_ 1
     x(34) c_u_clique_eqs(218)_ 1
     x(34) c_u_clique_eqs(225)_ 1
     x(34) c_u_clique_eqs(226)_ 1
     x(34) c_u_clique_eqs(227)_ 1
     x(34) c_u_clique_eqs(238)_ 1
     x(34) c_u_clique_eqs(243)_ 1
     x(34) c_u_clique_eqs(263)_ 1
     x(34) c_u_clique_eqs(277)_ 1
     x(34) c_u_clique_eqs(295)_ 1
     x(34) c_u_clique_eqs(296)_ 1
     x(34) c_u_clique_eqs(300)_ 1
     x(34) c_u_clique_eqs(301)_ 1
     x(34) c_u_clique_eqs(318)_ 1
     x(34) c_u_clique_eqs(323)_ 1
     x(35) obj -10.43
     x(35) c_u_edge_eqs(20)_ 1
     x(35) c_u_edge_eqs(45)_ 1
     x(35) c_u_edge_eqs(109)_ 1
     x(35) c_u_edge_eqs(133)_ 1
     x(35) c_u_edge_eqs(256)_ 1
     x(35) c_u_edge_eqs(275)_ 1
     x(35) c_u_edge_eqs(308)_ 1
     x(35) c_u_edge_eqs(344)_ 1
     x(35) c_u_edge_eqs(360)_ 1
     x(35) c_u_edge_eqs(376)_ 1
     x(35) c_u_edge_eqs(389)_ 1
     x(35) c_u_edge_eqs(414)_ 1
     x(35) c_u_edge_eqs(439)_ 1
     x(35) c_u_edge_eqs(459)_ 1
     x(35) c_u_edge_eqs(479)_ 1
     x(35) c_u_edge_eqs(491)_ 1
     x(35) c_u_edge_eqs(526)_ 1
     x(35) c_u_edge_eqs(532)_ 1
     x(35) c_u_edge_eqs(546)_ 1
     x(35) c_u_edge_eqs(547)_ 1
     x(35) c_u_edge_eqs(548)_ 1
     x(35) c_u_edge_eqs(549)_ 1
     x(35) c_u_edge_eqs(550)_ 1
     x(35) c_u_edge_eqs(551)_ 1
     x(35) c_u_clique_eqs(8)_ 1
     x(35) c_u_clique_eqs(9)_ 1
     x(35) c_u_clique_eqs(19)_ 1
     x(35) c_u_clique_eqs(30)_ 1
     x(35) c_u_clique_eqs(33)_ 1
     x(35) c_u_clique_eqs(38)_ 1
     x(35) c_u_clique_eqs(39)_ 1
     x(35) c_u_clique_eqs(47)_ 1
     x(35) c_u_clique_eqs(84)_ 1
     x(35) c_u_clique_eqs(87)_ 1
     x(35) c_u_clique_eqs(91)_ 1
     x(35) c_u_clique_eqs(96)_ 1
     x(35) c_u_clique_eqs(97)_ 1
     x(35) c_u_clique_eqs(98)_ 1
     x(35) c_u_clique_eqs(108)_ 1
     x(35) c_u_clique_eqs(120)_ 1
     x(35) c_u_clique_eqs(130)_ 1
     x(35) c_u_clique_eqs(154)_ 1
     x(35) c_u_clique_eqs(196)_ 1
     x(35) c_u_clique_eqs(198)_ 1
     x(35) c_u_clique_eqs(199)_ 1
     x(35) c_u_clique_eqs(219)_ 1
     x(35) c_u_clique_eqs(248)_ 1
     x(35) c_u_clique_eqs(255)_ 1
     x(35) c_u_clique_eqs(275)_ 1
     x(35) c_u_clique_eqs(278)_ 1
     x(35) c_u_clique_eqs(279)_ 1
     x(35) c_u_clique_eqs(280)_ 1
     x(35) c_u_clique_eqs(282)_ 1
     x(35) c_u_clique_eqs(283)_ 1
     x(35) c_u_clique_eqs(288)_ 1
     x(35) c_u_clique_eqs(308)_ 1
     x(35) c_u_clique_eqs(311)_ 1
     x(35) c_u_clique_eqs(324)_ 1
     x(35) c_u_clique_eqs(328)_ 1
     x(36) obj -10.34
     x(36) c_u_edge_eqs(21)_ 1
     x(36) c_u_edge_eqs(134)_ 1
     x(36) c_u_edge_eqs(157)_ 1
     x(36) c_u_edge_eqs(194)_ 1
     x(36) c_u_edge_eqs(236)_ 1
     x(36) c_u_edge_eqs(276)_ 1
     x(36) c_u_edge_eqs(345)_ 1
     x(36) c_u_edge_eqs(361)_ 1
     x(36) c_u_edge_eqs(377)_ 1
     x(36) c_u_edge_eqs(440)_ 1
     x(36) c_u_edge_eqs(460)_ 1
     x(36) c_u_edge_eqs(480)_ 1
     x(36) c_u_edge_eqs(508)_ 1
     x(36) c_u_edge_eqs(533)_ 1
     x(36) c_u_edge_eqs(552)_ 1
     x(36) c_u_edge_eqs(553)_ 1
     x(36) c_u_edge_eqs(554)_ 1
     x(36) c_u_clique_eqs(14)_ 1
     x(36) c_u_clique_eqs(15)_ 1
     x(36) c_u_clique_eqs(18)_ 1
     x(36) c_u_clique_eqs(43)_ 1
     x(36) c_u_clique_eqs(50)_ 1
     x(36) c_u_clique_eqs(80)_ 1
     x(36) c_u_clique_eqs(81)_ 1
     x(36) c_u_clique_eqs(125)_ 1
     x(36) c_u_clique_eqs(128)_ 1
     x(36) c_u_clique_eqs(131)_ 1
     x(36) c_u_clique_eqs(144)_ 1
     x(36) c_u_clique_eqs(161)_ 1
     x(36) c_u_clique_eqs(197)_ 1
     x(36) c_u_clique_eqs(200)_ 1
     x(36) c_u_clique_eqs(201)_ 1
     x(36) c_u_clique_eqs(289)_ 1
     x(36) c_u_clique_eqs(290)_ 1
     x(37) obj -10.51
     x(37) c_u_edge_eqs(22)_ 1
     x(37) c_u_edge_eqs(64)_ 1
     x(37) c_u_edge_eqs(110)_ 1
     x(37) c_u_edge_eqs(177)_ 1
     x(37) c_u_edge_eqs(294)_ 1
     x(37) c_u_edge_eqs(441)_ 1
     x(37) c_u_edge_eqs(451)_ 1
     x(37) c_u_edge_eqs(514)_ 1
     x(37) c_u_edge_eqs(527)_ 1
     x(37) c_u_edge_eqs(534)_ 1
     x(37) c_u_edge_eqs(552)_ 1
     x(37) c_u_edge_eqs(555)_ 1
     x(37) c_u_edge_eqs(556)_ 1
     x(37) c_u_edge_eqs(557)_ 1
     x(37) c_u_edge_eqs(558)_ 1
     x(37) c_u_edge_eqs(559)_ 1
     x(37) c_u_clique_eqs(13)_ 1
     x(37) c_u_clique_eqs(126)_ 1
     x(37) c_u_clique_eqs(127)_ 1
     x(37) c_u_clique_eqs(193)_ 1
     x(37) c_u_clique_eqs(194)_ 1
     x(37) c_u_clique_eqs(216)_ 1
     x(37) c_u_clique_eqs(305)_ 1
     x(37) c_u_clique_eqs(306)_ 1
     x(37) c_u_clique_eqs(307)_ 1
     x(38) obj -10.390000000000001
     x(38) c_u_edge_eqs(46)_ 1
     x(38) c_u_edge_eqs(65)_ 1
     x(38) c_u_edge_eqs(85)_ 1
     x(38) c_u_edge_eqs(111)_ 1
     x(38) c_u_edge_eqs(135)_ 1
     x(38) c_u_edge_eqs(158)_ 1
     x(38) c_u_edge_eqs(178)_ 1
     x(38) c_u_edge_eqs(212)_ 1
     x(38) c_u_edge_eqs(237)_ 1
     x(38) c_u_edge_eqs(277)_ 1
     x(38) c_u_edge_eqs(309)_ 1
     x(38) c_u_edge_eqs(346)_ 1
     x(38) c_u_edge_eqs(362)_ 1
     x(38) c_u_edge_eqs(378)_ 1
     x(38) c_u_edge_eqs(390)_ 1
     x(38) c_u_edge_eqs(415)_ 1
     x(38) c_u_edge_eqs(425)_ 1
     x(38) c_u_edge_eqs(442)_ 1
     x(38) c_u_edge_eqs(461)_ 1
     x(38) c_u_edge_eqs(470)_ 1
     x(38) c_u_edge_eqs(481)_ 1
     x(38) c_u_edge_eqs(492)_ 1
     x(38) c_u_edge_eqs(499)_ 1
     x(38) c_u_edge_eqs(515)_ 1
     x(38) c_u_edge_eqs(528)_ 1
     x(38) c_u_edge_eqs(535)_ 1
     x(38) c_u_edge_eqs(555)_ 1
     x(38) c_u_edge_eqs(560)_ 1
     x(38) c_u_edge_eqs(561)_ 1
     x(38) c_u_edge_eqs(562)_ 1
     x(38) c_u_edge_eqs(563)_ 1
     x(38) c_u_clique_eqs(72)_ 1
     x(38) c_u_clique_eqs(76)_ 1
     x(38) c_u_clique_eqs(142)_ 1
     x(38) c_u_clique_eqs(145)_ 1
     x(38) c_u_clique_eqs(152)_ 1
     x(38) c_u_clique_eqs(155)_ 1
     x(38) c_u_clique_eqs(162)_ 1
     x(38) c_u_clique_eqs(180)_ 1
     x(38) c_u_clique_eqs(187)_ 1
     x(38) c_u_clique_eqs(190)_ 1
     x(38) c_u_clique_eqs(193)_ 1
     x(38) c_u_clique_eqs(213)_ 1
     x(38) c_u_clique_eqs(215)_ 1
     x(38) c_u_clique_eqs(231)_ 1
     x(38) c_u_clique_eqs(236)_ 1
     x(38) c_u_clique_eqs(246)_ 1
     x(38) c_u_clique_eqs(247)_ 1
     x(38) c_u_clique_eqs(254)_ 1
     x(38) c_u_clique_eqs(261)_ 1
     x(38) c_u_clique_eqs(265)_ 1
     x(38) c_u_clique_eqs(266)_ 1
     x(38) c_u_clique_eqs(267)_ 1
     x(38) c_u_clique_eqs(293)_ 1
     x(38) c_u_clique_eqs(297)_ 1
     x(38) c_u_clique_eqs(298)_ 1
     x(38) c_u_clique_eqs(302)_ 1
     x(38) c_u_clique_eqs(303)_ 1
     x(38) c_u_clique_eqs(305)_ 1
     x(38) c_u_clique_eqs(306)_ 1
     x(38) c_u_clique_eqs(313)_ 1
     x(38) c_u_clique_eqs(314)_ 1
     x(38) c_u_clique_eqs(319)_ 1
     x(38) c_u_clique_eqs(320)_ 1
     x(38) c_u_clique_eqs(321)_ 1
     x(38) c_u_clique_eqs(322)_ 1
     x(38) c_u_clique_eqs(329)_ 1
     x(39) obj -11.43
     x(39) c_u_edge_eqs(23)_ 1
     x(39) c_u_edge_eqs(47)_ 1
     x(39) c_u_edge_eqs(86)_ 1
     x(39) c_u_edge_eqs(136)_ 1
     x(39) c_u_edge_eqs(159)_ 1
     x(39) c_u_edge_eqs(179)_ 1
     x(39) c_u_edge_eqs(213)_ 1
     x(39) c_u_edge_eqs(278)_ 1
     x(39) c_u_edge_eqs(310)_ 1
     x(39) c_u_edge_eqs(363)_ 1
     x(39) c_u_edge_eqs(402)_ 1
     x(39) c_u_edge_eqs(443)_ 1
     x(39) c_u_edge_eqs(471)_ 1
     x(39) c_u_edge_eqs(493)_ 1
     x(39) c_u_edge_eqs(500)_ 1
     x(39) c_u_edge_eqs(509)_ 1
     x(39) c_u_edge_eqs(516)_ 1
     x(39) c_u_edge_eqs(529)_ 1
     x(39) c_u_edge_eqs(536)_ 1
     x(39) c_u_edge_eqs(546)_ 1
     x(39) c_u_edge_eqs(556)_ 1
     x(39) c_u_edge_eqs(564)_ 1
     x(39) c_u_edge_eqs(565)_ 1
     x(39) c_u_edge_eqs(566)_ 1
     x(39) c_u_edge_eqs(567)_ 1
     x(39) c_u_edge_eqs(568)_ 1
     x(39) c_u_clique_eqs(1)_ 1
     x(39) c_u_clique_eqs(2)_ 1
     x(39) c_u_clique_eqs(26)_ 1
     x(39) c_u_clique_eqs(49)_ 1
     x(39) c_u_clique_eqs(110)_ 1
     x(39) c_u_clique_eqs(120)_ 1
     x(39) c_u_clique_eqs(121)_ 1
     x(39) c_u_clique_eqs(122)_ 1
     x(39) c_u_clique_eqs(123)_ 1
     x(39) c_u_clique_eqs(124)_ 1
     x(39) c_u_clique_eqs(126)_ 1
     x(39) c_u_clique_eqs(127)_ 1
     x(39) c_u_clique_eqs(156)_ 1
     x(39) c_u_clique_eqs(194)_ 1
     x(39) c_u_clique_eqs(205)_ 1
     x(39) c_u_clique_eqs(206)_ 1
     x(39) c_u_clique_eqs(207)_ 1
     x(39) c_u_clique_eqs(208)_ 1
     x(39) c_u_clique_eqs(248)_ 1
     x(39) c_u_clique_eqs(249)_ 1
     x(39) c_u_clique_eqs(250)_ 1
     x(39) c_u_clique_eqs(251)_ 1
     x(39) c_u_clique_eqs(252)_ 1
     x(39) c_u_clique_eqs(253)_ 1
     x(39) c_u_clique_eqs(264)_ 1
     x(39) c_u_clique_eqs(268)_ 1
     x(39) c_u_clique_eqs(274)_ 1
     x(39) c_u_clique_eqs(275)_ 1
     x(39) c_u_clique_eqs(276)_ 1
     x(39) c_u_clique_eqs(287)_ 1
     x(39) c_u_clique_eqs(291)_ 1
     x(39) c_u_clique_eqs(299)_ 1
     x(39) c_u_clique_eqs(307)_ 1
     x(39) c_u_clique_eqs(312)_ 1
     x(39) c_u_clique_eqs(324)_ 1
     x(39) c_u_clique_eqs(325)_ 1
     x(40) obj -11.06
     x(40) c_u_edge_eqs(24)_ 1
     x(40) c_u_edge_eqs(87)_ 1
     x(40) c_u_edge_eqs(137)_ 1
     x(40) c_u_edge_eqs(180)_ 1
     x(40) c_u_edge_eqs(295)_ 1
     x(40) c_u_edge_eqs(328)_ 1
     x(40) c_u_edge_eqs(426)_ 1
     x(40) c_u_edge_eqs(452)_ 1
     x(40) c_u_edge_eqs(462)_ 1
     x(40) c_u_edge_eqs(482)_ 1
     x(40) c_u_edge_eqs(494)_ 1
     x(40) c_u_edge_eqs(501)_ 1
     x(40) c_u_edge_eqs(547)_ 1
     x(40) c_u_edge_eqs(553)_ 1
     x(40) c_u_edge_eqs(569)_ 1
     x(40) c_u_edge_eqs(570)_ 1
     x(40) c_u_edge_eqs(571)_ 1
     x(40) c_u_clique_eqs(14)_ 1
     x(40) c_u_clique_eqs(15)_ 1
     x(40) c_u_clique_eqs(16)_ 1
     x(40) c_u_clique_eqs(17)_ 1
     x(40) c_u_clique_eqs(18)_ 1
     x(40) c_u_clique_eqs(128)_ 1
     x(41) obj -9.9800000000000004
     x(41) c_u_edge_eqs(138)_ 1
     x(41) c_u_edge_eqs(160)_ 1
     x(41) c_u_edge_eqs(214)_ 1
     x(41) c_u_edge_eqs(238)_ 1
     x(41) c_u_edge_eqs(257)_ 1
     x(41) c_u_edge_eqs(329)_ 1
     x(41) c_u_edge_eqs(391)_ 1
     x(41) c_u_edge_eqs(403)_ 1
     x(41) c_u_edge_eqs(427)_ 1
     x(41) c_u_edge_eqs(444)_ 1
     x(41) c_u_edge_eqs(472)_ 1
     x(41) c_u_edge_eqs(483)_ 1
     x(41) c_u_edge_eqs(517)_ 1
     x(41) c_u_edge_eqs(537)_ 1
     x(41) c_u_edge_eqs(540)_ 1
     x(41) c_u_edge_eqs(548)_ 1
     x(41) c_u_edge_eqs(557)_ 1
     x(41) c_u_edge_eqs(564)_ 1
     x(41) c_u_edge_eqs(572)_ 1
     x(41) c_u_edge_eqs(573)_ 1
     x(41) c_u_clique_eqs(1)_ 1
     x(41) c_u_clique_eqs(3)_ 1
     x(41) c_u_clique_eqs(4)_ 1
     x(41) c_u_clique_eqs(19)_ 1
     x(41) c_u_clique_eqs(20)_ 1
     x(41) c_u_clique_eqs(21)_ 1
     x(41) c_u_clique_eqs(22)_ 1
     x(41) c_u_clique_eqs(23)_ 1
     x(41) c_u_clique_eqs(24)_ 1
     x(41) c_u_clique_eqs(25)_ 1
     x(41) c_u_clique_eqs(26)_ 1
     x(41) c_u_clique_eqs(27)_ 1
     x(41) c_u_clique_eqs(28)_ 1
     x(41) c_u_clique_eqs(122)_ 1
     x(41) c_u_clique_eqs(123)_ 1
     x(41) c_u_clique_eqs(126)_ 1
     x(41) c_u_clique_eqs(143)_ 1
     x(41) c_u_clique_eqs(163)_ 1
     x(41) c_u_clique_eqs(191)_ 1
     x(41) c_u_clique_eqs(192)_ 1
     x(41) c_u_clique_eqs(194)_ 1
     x(41) c_u_clique_eqs(195)_ 1
     x(41) c_u_clique_eqs(206)_ 1
     x(41) c_u_clique_eqs(207)_ 1
     x(41) c_u_clique_eqs(209)_ 1
     x(41) c_u_clique_eqs(210)_ 1
     x(41) c_u_clique_eqs(252)_ 1
     x(41) c_u_clique_eqs(256)_ 1
     x(41) c_u_clique_eqs(278)_ 1
     x(41) c_u_clique_eqs(279)_ 1
     x(41) c_u_clique_eqs(307)_ 1
     x(42) obj -10.02
     x(42) c_u_edge_eqs(48)_ 1
     x(42) c_u_edge_eqs(66)_ 1
     x(42) c_u_edge_eqs(161)_ 1
     x(42) c_u_edge_eqs(215)_ 1
     x(42) c_u_edge_eqs(239)_ 1
     x(42) c_u_edge_eqs(279)_ 1
     x(42) c_u_edge_eqs(311)_ 1
     x(42) c_u_edge_eqs(364)_ 1
     x(42) c_u_edge_eqs(379)_ 1
     x(42) c_u_edge_eqs(392)_ 1
     x(42) c_u_edge_eqs(404)_ 1
     x(42) c_u_edge_eqs(428)_ 1
     x(42) c_u_edge_eqs(473)_ 1
     x(42) c_u_edge_eqs(484)_ 1
     x(42) c_u_edge_eqs(495)_ 1
     x(42) c_u_edge_eqs(502)_ 1
     x(42) c_u_edge_eqs(518)_ 1
     x(42) c_u_edge_eqs(538)_ 1
     x(42) c_u_edge_eqs(541)_ 1
     x(42) c_u_edge_eqs(554)_ 1
     x(42) c_u_edge_eqs(560)_ 1
     x(42) c_u_edge_eqs(569)_ 1
     x(42) c_u_edge_eqs(574)_ 1
     x(42) c_u_edge_eqs(575)_ 1
     x(42) c_u_edge_eqs(576)_ 1
     x(42) c_u_edge_eqs(577)_ 1
     x(42) c_u_edge_eqs(578)_ 1
     x(42) c_u_clique_eqs(18)_ 1
     x(42) c_u_clique_eqs(55)_ 1
     x(42) c_u_clique_eqs(56)_ 1
     x(42) c_u_clique_eqs(58)_ 1
     x(42) c_u_clique_eqs(59)_ 1
     x(42) c_u_clique_eqs(60)_ 1
     x(42) c_u_clique_eqs(75)_ 1
     x(42) c_u_clique_eqs(109)_ 1
     x(42) c_u_clique_eqs(119)_ 1
     x(42) c_u_clique_eqs(128)_ 1
     x(42) c_u_clique_eqs(132)_ 1
     x(42) c_u_clique_eqs(134)_ 1
     x(42) c_u_clique_eqs(135)_ 1
     x(42) c_u_clique_eqs(141)_ 1
     x(42) c_u_clique_eqs(142)_ 1
     x(42) c_u_clique_eqs(167)_ 1
     x(42) c_u_clique_eqs(169)_ 1
     x(42) c_u_clique_eqs(170)_ 1
     x(42) c_u_clique_eqs(172)_ 1
     x(42) c_u_clique_eqs(173)_ 1
     x(42) c_u_clique_eqs(174)_ 1
     x(42) c_u_clique_eqs(179)_ 1
     x(42) c_u_clique_eqs(184)_ 1
     x(42) c_u_clique_eqs(204)_ 1
     x(42) c_u_clique_eqs(221)_ 1
     x(42) c_u_clique_eqs(222)_ 1
     x(42) c_u_clique_eqs(223)_ 1
     x(42) c_u_clique_eqs(224)_ 1
     x(42) c_u_clique_eqs(231)_ 1
     x(42) c_u_clique_eqs(233)_ 1
     x(42) c_u_clique_eqs(236)_ 1
     x(42) c_u_clique_eqs(246)_ 1
     x(42) c_u_clique_eqs(293)_ 1
     x(42) c_u_clique_eqs(295)_ 1
     x(42) c_u_clique_eqs(296)_ 1
     x(42) c_u_clique_eqs(298)_ 1
     x(42) c_u_clique_eqs(302)_ 1
     x(42) c_u_clique_eqs(329)_ 1
     x(43) obj -10.48
     x(43) c_u_edge_eqs(112)_ 1
     x(43) c_u_edge_eqs(139)_ 1
     x(43) c_u_edge_eqs(162)_ 1
     x(43) c_u_edge_eqs(195)_ 1
     x(43) c_u_edge_eqs(258)_ 1
     x(43) c_u_edge_eqs(280)_ 1
     x(43) c_u_edge_eqs(312)_ 1
     x(43) c_u_edge_eqs(347)_ 1
     x(43) c_u_edge_eqs(393)_ 1
     x(43) c_u_edge_eqs(405)_ 1
     x(43) c_u_edge_eqs(429)_ 1
     x(43) c_u_edge_eqs(463)_ 1
     x(43) c_u_edge_eqs(485)_ 1
     x(43) c_u_edge_eqs(503)_ 1
     x(43) c_u_edge_eqs(519)_ 1
     x(43) c_u_edge_eqs(539)_ 1
     x(43) c_u_edge_eqs(542)_ 1
     x(43) c_u_edge_eqs(549)_ 1
     x(43) c_u_edge_eqs(558)_ 1
     x(43) c_u_edge_eqs(561)_ 1
     x(43) c_u_edge_eqs(574)_ 1
     x(43) c_u_edge_eqs(579)_ 1
     x(43) c_u_edge_eqs(580)_ 1
     x(43) c_u_edge_eqs(581)_ 1
     x(43) c_u_clique_eqs(5)_ 1
     x(43) c_u_clique_eqs(6)_ 1
     x(43) c_u_clique_eqs(7)_ 1
     x(43) c_u_clique_eqs(9)_ 1
     x(43) c_u_clique_eqs(11)_ 1
     x(43) c_u_clique_eqs(12)_ 1
     x(43) c_u_clique_eqs(33)_ 1
     x(43) c_u_clique_eqs(34)_ 1
     x(43) c_u_clique_eqs(37)_ 1
     x(43) c_u_clique_eqs(38)_ 1
     x(43) c_u_clique_eqs(39)_ 1
     x(43) c_u_clique_eqs(40)_ 1
     x(43) c_u_clique_eqs(41)_ 1
     x(43) c_u_clique_eqs(46)_ 1
     x(43) c_u_clique_eqs(53)_ 1
     x(43) c_u_clique_eqs(54)_ 1
     x(43) c_u_clique_eqs(55)_ 1
     x(43) c_u_clique_eqs(56)_ 1
     x(43) c_u_clique_eqs(57)_ 1
     x(43) c_u_clique_eqs(58)_ 1
     x(43) c_u_clique_eqs(59)_ 1
     x(43) c_u_clique_eqs(73)_ 1
     x(43) c_u_clique_eqs(74)_ 1
     x(43) c_u_clique_eqs(75)_ 1
     x(43) c_u_clique_eqs(76)_ 1
     x(43) c_u_clique_eqs(77)_ 1
     x(43) c_u_clique_eqs(82)_ 1
     x(43) c_u_clique_eqs(83)_ 1
     x(43) c_u_clique_eqs(84)_ 1
     x(43) c_u_clique_eqs(85)_ 1
     x(43) c_u_clique_eqs(86)_ 1
     x(43) c_u_clique_eqs(87)_ 1
     x(43) c_u_clique_eqs(88)_ 1
     x(43) c_u_clique_eqs(89)_ 1
     x(43) c_u_clique_eqs(90)_ 1
     x(43) c_u_clique_eqs(91)_ 1
     x(43) c_u_clique_eqs(92)_ 1
     x(43) c_u_clique_eqs(96)_ 1
     x(43) c_u_clique_eqs(97)_ 1
     x(43) c_u_clique_eqs(98)_ 1
     x(43) c_u_clique_eqs(103)_ 1
     x(43) c_u_clique_eqs(105)_ 1
     x(43) c_u_clique_eqs(106)_ 1
     x(43) c_u_clique_eqs(132)_ 1
     x(43) c_u_clique_eqs(157)_ 1
     x(43) c_u_clique_eqs(158)_ 1
     x(43) c_u_clique_eqs(159)_ 1
     x(43) c_u_clique_eqs(167)_ 1
     x(43) c_u_clique_eqs(168)_ 1
     x(43) c_u_clique_eqs(169)_ 1
     x(43) c_u_clique_eqs(170)_ 1
     x(43) c_u_clique_eqs(174)_ 1
     x(43) c_u_clique_eqs(222)_ 1
     x(43) c_u_clique_eqs(223)_ 1
     x(43) c_u_clique_eqs(236)_ 1
     x(43) c_u_clique_eqs(269)_ 1
     x(43) c_u_clique_eqs(270)_ 1
     x(43) c_u_clique_eqs(271)_ 1
     x(43) c_u_clique_eqs(272)_ 1
     x(43) c_u_clique_eqs(273)_ 1
     x(43) c_u_clique_eqs(280)_ 1
     x(43) c_u_clique_eqs(281)_ 1
     x(43) c_u_clique_eqs(282)_ 1
     x(43) c_u_clique_eqs(283)_ 1
     x(43) c_u_clique_eqs(284)_ 1
     x(43) c_u_clique_eqs(292)_ 1
     x(43) c_u_clique_eqs(293)_ 1
     x(43) c_u_clique_eqs(306)_ 1
     x(44) obj -9.8200000000000003
     x(44) c_u_edge_eqs(67)_ 1
     x(44) c_u_edge_eqs(88)_ 1
     x(44) c_u_edge_eqs(140)_ 1
     x(44) c_u_edge_eqs(181)_ 1
     x(44) c_u_edge_eqs(216)_ 1
     x(44) c_u_edge_eqs(296)_ 1
     x(44) c_u_edge_eqs(313)_ 1
     x(44) c_u_edge_eqs(348)_ 1
     x(44) c_u_edge_eqs(380)_ 1
     x(44) c_u_edge_eqs(416)_ 1
     x(44) c_u_edge_eqs(445)_ 1
     x(44) c_u_edge_eqs(496)_ 1
     x(44) c_u_edge_eqs(504)_ 1
     x(44) c_u_edge_eqs(520)_ 1
     x(44) c_u_edge_eqs(543)_ 1
     x(44) c_u_edge_eqs(559)_ 1
     x(44) c_u_edge_eqs(562)_ 1
     x(44) c_u_edge_eqs(565)_ 1
     x(44) c_u_edge_eqs(575)_ 1
     x(44) c_u_edge_eqs(582)_ 1
     x(44) c_u_edge_eqs(583)_ 1
     x(44) c_u_clique_eqs(64)_ 1
     x(44) c_u_clique_eqs(68)_ 1
     x(44) c_u_clique_eqs(70)_ 1
     x(44) c_u_clique_eqs(71)_ 1
     x(44) c_u_clique_eqs(72)_ 1
     x(44) c_u_clique_eqs(121)_ 1
     x(44) c_u_clique_eqs(127)_ 1
     x(44) c_u_clique_eqs(133)_ 1
     x(44) c_u_clique_eqs(134)_ 1
     x(44) c_u_clique_eqs(135)_ 1
     x(44) c_u_clique_eqs(136)_ 1
     x(44) c_u_clique_eqs(137)_ 1
     x(44) c_u_clique_eqs(145)_ 1
     x(44) c_u_clique_eqs(155)_ 1
     x(44) c_u_clique_eqs(171)_ 1
     x(44) c_u_clique_eqs(172)_ 1
     x(44) c_u_clique_eqs(193)_ 1
     x(44) c_u_clique_eqs(203)_ 1
     x(44) c_u_clique_eqs(204)_ 1
     x(44) c_u_clique_eqs(205)_ 1
     x(44) c_u_clique_eqs(231)_ 1
     x(44) c_u_clique_eqs(249)_ 1
     x(44) c_u_clique_eqs(250)_ 1
     x(44) c_u_clique_eqs(254)_ 1
     x(44) c_u_clique_eqs(264)_ 1
     x(44) c_u_clique_eqs(265)_ 1
     x(44) c_u_clique_eqs(266)_ 1
     x(44) c_u_clique_eqs(267)_ 1
     x(44) c_u_clique_eqs(268)_ 1
     x(44) c_u_clique_eqs(295)_ 1
     x(44) c_u_clique_eqs(305)_ 1
     x(44) c_u_clique_eqs(317)_ 1
     x(44) c_u_clique_eqs(318)_ 1
     x(44) c_u_clique_eqs(319)_ 1
     x(44) c_u_clique_eqs(320)_ 1
     x(44) c_u_clique_eqs(321)_ 1
     x(45) obj -9.6699999999999999
     x(45) c_u_edge_eqs(89)_ 1
     x(45) c_u_edge_eqs(141)_ 1
     x(45) c_u_edge_eqs(182)_ 1
     x(45) c_u_edge_eqs(240)_ 1
     x(45) c_u_edge_eqs(281)_ 1
     x(45) c_u_edge_eqs(314)_ 1
     x(45) c_u_edge_eqs(330)_ 1
     x(45) c_u_edge_eqs(349)_ 1
     x(45) c_u_edge_eqs(394)_ 1
     x(45) c_u_edge_eqs(474)_ 1
     x(45) c_u_edge_eqs(505)_ 1
     x(45) c_u_edge_eqs(510)_ 1
     x(45) c_u_edge_eqs(521)_ 1
     x(45) c_u_edge_eqs(570)_ 1
     x(45) c_u_edge_eqs(576)_ 1
     x(45) c_u_edge_eqs(579)_ 1
     x(45) c_u_edge_eqs(584)_ 1
     x(45) c_u_edge_eqs(585)_ 1
     x(45) c_u_clique_eqs(5)_ 1
     x(45) c_u_clique_eqs(6)_ 1
     x(45) c_u_clique_eqs(44)_ 1
     x(45) c_u_clique_eqs(45)_ 1
     x(45) c_u_clique_eqs(48)_ 1
     x(45) c_u_clique_eqs(58)_ 1
     x(45) c_u_clique_eqs(59)_ 1
     x(45) c_u_clique_eqs(85)_ 1
     x(45) c_u_clique_eqs(89)_ 1
     x(45) c_u_clique_eqs(94)_ 1
     x(45) c_u_clique_eqs(95)_ 1
     x(45) c_u_clique_eqs(102)_ 1
     x(45) c_u_clique_eqs(104)_ 1
     x(45) c_u_clique_eqs(106)_ 1
     x(45) c_u_clique_eqs(111)_ 1
     x(45) c_u_clique_eqs(118)_ 1
     x(45) c_u_clique_eqs(119)_ 1
     x(45) c_u_clique_eqs(141)_ 1
     x(45) c_u_clique_eqs(149)_ 1
     x(45) c_u_clique_eqs(150)_ 1
     x(45) c_u_clique_eqs(153)_ 1
     x(45) c_u_clique_eqs(159)_ 1
     x(45) c_u_clique_eqs(170)_ 1
     x(45) c_u_clique_eqs(183)_ 1
     x(45) c_u_clique_eqs(220)_ 1
     x(45) c_u_clique_eqs(223)_ 1
     x(45) c_u_clique_eqs(270)_ 1
     x(45) c_u_clique_eqs(273)_ 1
     x(45) c_u_clique_eqs(292)_ 1
     x(46) obj -10.539999999999999
     x(46) c_u_edge_eqs(90)_ 1
     x(46) c_u_edge_eqs(183)_ 1
     x(46) c_u_edge_eqs(217)_ 1
     x(46) c_u_edge_eqs(241)_ 1
     x(46) c_u_edge_eqs(297)_ 1
     x(46) c_u_edge_eqs(315)_ 1
     x(46) c_u_edge_eqs(331)_ 1
     x(46) c_u_edge_eqs(350)_ 1
     x(46) c_u_edge_eqs(365)_ 1
     x(46) c_u_edge_eqs(381)_ 1
     x(46) c_u_edge_eqs(430)_ 1
     x(46) c_u_edge_eqs(511)_ 1
     x(46) c_u_edge_eqs(522)_ 1
     x(46) c_u_edge_eqs(530)_ 1
     x(46) c_u_edge_eqs(544)_ 1
     x(46) c_u_edge_eqs(563)_ 1
     x(46) c_u_edge_eqs(566)_ 1
     x(46) c_u_edge_eqs(572)_ 1
     x(46) c_u_edge_eqs(577)_ 1
     x(46) c_u_edge_eqs(580)_ 1
     x(46) c_u_edge_eqs(582)_ 1
     x(46) c_u_edge_eqs(586)_ 1
     x(46) c_u_clique_eqs(20)_ 1
     x(46) c_u_clique_eqs(62)_ 1
     x(46) c_u_clique_eqs(65)_ 1
     x(46) c_u_clique_eqs(72)_ 1
     x(46) c_u_clique_eqs(73)_ 1
     x(46) c_u_clique_eqs(74)_ 1
     x(46) c_u_clique_eqs(75)_ 1
     x(46) c_u_clique_eqs(76)_ 1
     x(46) c_u_clique_eqs(77)_ 1
     x(46) c_u_clique_eqs(78)_ 1
     x(46) c_u_clique_eqs(79)_ 1
     x(46) c_u_clique_eqs(135)_ 1
     x(46) c_u_clique_eqs(145)_ 1
     x(46) c_u_clique_eqs(146)_ 1
     x(46) c_u_clique_eqs(147)_ 1
     x(46) c_u_clique_eqs(155)_ 1
     x(46) c_u_clique_eqs(156)_ 1
     x(46) c_u_clique_eqs(172)_ 1
     x(46) c_u_clique_eqs(173)_ 1
     x(46) c_u_clique_eqs(174)_ 1
     x(46) c_u_clique_eqs(175)_ 1
     x(46) c_u_clique_eqs(176)_ 1
     x(46) c_u_clique_eqs(177)_ 1
     x(46) c_u_clique_eqs(204)_ 1
     x(46) c_u_clique_eqs(265)_ 1
     x(46) c_u_clique_eqs(266)_ 1
     x(46) c_u_clique_eqs(268)_ 1
     x(46) c_u_clique_eqs(286)_ 1
     x(46) c_u_clique_eqs(287)_ 1
     x(46) c_u_clique_eqs(295)_ 1
     x(46) c_u_clique_eqs(296)_ 1
     x(46) c_u_clique_eqs(297)_ 1
     x(46) c_u_clique_eqs(298)_ 1
     x(46) c_u_clique_eqs(299)_ 1
     x(46) c_u_clique_eqs(303)_ 1
     x(47) obj -10.529999999999999
     x(47) c_u_edge_eqs(68)_ 1
     x(47) c_u_edge_eqs(91)_ 1
     x(47) c_u_edge_eqs(184)_ 1
     x(47) c_u_edge_eqs(196)_ 1
     x(47) c_u_edge_eqs(242)_ 1
     x(47) c_u_edge_eqs(259)_ 1
     x(47) c_u_edge_eqs(298)_ 1
     x(47) c_u_edge_eqs(351)_ 1
     x(47) c_u_edge_eqs(366)_ 1
     x(47) c_u_edge_eqs(395)_ 1
     x(47) c_u_edge_eqs(406)_ 1
     x(47) c_u_edge_eqs(417)_ 1
     x(47) c_u_edge_eqs(446)_ 1
     x(47) c_u_edge_eqs(464)_ 1
     x(47) c_u_edge_eqs(475)_ 1
     x(47) c_u_edge_eqs(486)_ 1
     x(47) c_u_edge_eqs(506)_ 1
     x(47) c_u_edge_eqs(523)_ 1
     x(47) c_u_edge_eqs(545)_ 1
     x(47) c_u_edge_eqs(550)_ 1
     x(47) c_u_edge_eqs(567)_ 1
     x(47) c_u_edge_eqs(581)_ 1
     x(47) c_u_edge_eqs(584)_ 1
     x(47) c_u_edge_eqs(586)_ 1
     x(47) c_u_clique_eqs(35)_ 1
     x(47) c_u_clique_eqs(36)_ 1
     x(47) c_u_clique_eqs(37)_ 1
     x(47) c_u_clique_eqs(38)_ 1
     x(47) c_u_clique_eqs(39)_ 1
     x(47) c_u_clique_eqs(40)_ 1
     x(47) c_u_clique_eqs(41)_ 1
     x(47) c_u_clique_eqs(65)_ 1
     x(47) c_u_clique_eqs(66)_ 1
     x(47) c_u_clique_eqs(67)_ 1
     x(47) c_u_clique_eqs(69)_ 1
     x(47) c_u_clique_eqs(74)_ 1
     x(47) c_u_clique_eqs(77)_ 1
     x(47) c_u_clique_eqs(87)_ 1
     x(47) c_u_clique_eqs(88)_ 1
     x(47) c_u_clique_eqs(89)_ 1
     x(47) c_u_clique_eqs(90)_ 1
     x(47) c_u_clique_eqs(91)_ 1
     x(47) c_u_clique_eqs(92)_ 1
     x(47) c_u_clique_eqs(95)_ 1
     x(47) c_u_clique_eqs(98)_ 1
     x(47) c_u_clique_eqs(100)_ 1
     x(47) c_u_clique_eqs(101)_ 1
     x(47) c_u_clique_eqs(102)_ 1
     x(47) c_u_clique_eqs(103)_ 1
     x(47) c_u_clique_eqs(104)_ 1
     x(47) c_u_clique_eqs(105)_ 1
     x(47) c_u_clique_eqs(106)_ 1
     x(47) c_u_clique_eqs(129)_ 1
     x(47) c_u_clique_eqs(139)_ 1
     x(47) c_u_clique_eqs(148)_ 1
     x(47) c_u_clique_eqs(149)_ 1
     x(47) c_u_clique_eqs(150)_ 1
     x(47) c_u_clique_eqs(158)_ 1
     x(47) c_u_clique_eqs(159)_ 1
     x(47) c_u_clique_eqs(165)_ 1
     x(47) c_u_clique_eqs(182)_ 1
     x(47) c_u_clique_eqs(196)_ 1
     x(47) c_u_clique_eqs(227)_ 1
     x(47) c_u_clique_eqs(228)_ 1
     x(47) c_u_clique_eqs(230)_ 1
     x(47) c_u_clique_eqs(260)_ 1
     x(47) c_u_clique_eqs(272)_ 1
     x(47) c_u_clique_eqs(273)_ 1
     x(47) c_u_clique_eqs(282)_ 1
     x(47) c_u_clique_eqs(283)_ 1
     x(47) c_u_clique_eqs(284)_ 1
     x(47) c_u_clique_eqs(291)_ 1
     x(47) c_u_clique_eqs(292)_ 1
     x(47) c_u_clique_eqs(294)_ 1
     x(47) c_u_clique_eqs(301)_ 1
     x(47) c_u_clique_eqs(308)_ 1
     x(47) c_u_clique_eqs(309)_ 1
     x(47) c_u_clique_eqs(323)_ 1
     x(47) c_u_clique_eqs(324)_ 1
     x(47) c_u_clique_eqs(325)_ 1
     x(48) obj -9.5999999999999996
     x(48) c_u_edge_eqs(25)_ 1
     x(48) c_u_edge_eqs(49)_ 1
     x(48) c_u_edge_eqs(92)_ 1
     x(48) c_u_edge_eqs(113)_ 1
     x(48) c_u_edge_eqs(142)_ 1
     x(48) c_u_edge_eqs(197)_ 1
     x(48) c_u_edge_eqs(218)_ 1
     x(48) c_u_edge_eqs(243)_ 1
     x(48) c_u_edge_eqs(316)_ 1
     x(48) c_u_edge_eqs(332)_ 1
     x(48) c_u_edge_eqs(407)_ 1
     x(48) c_u_edge_eqs(418)_ 1
     x(48) c_u_edge_eqs(431)_ 1
     x(48) c_u_edge_eqs(465)_ 1
     x(48) c_u_edge_eqs(487)_ 1
     x(48) c_u_edge_eqs(497)_ 1
     x(48) c_u_edge_eqs(512)_ 1
     x(48) c_u_edge_eqs(524)_ 1
     x(48) c_u_edge_eqs(531)_ 1
     x(48) c_u_edge_eqs(551)_ 1
     x(48) c_u_edge_eqs(568)_ 1
     x(48) c_u_edge_eqs(573)_ 1
     x(48) c_u_edge_eqs(578)_ 1
     x(48) c_u_edge_eqs(583)_ 1
     x(48) c_u_edge_eqs(585)_ 1
     x(48) c_u_edge_eqs(587)_ 1
     x(48) c_u_clique_eqs(1)_ 1
     x(48) c_u_clique_eqs(2)_ 1
     x(48) c_u_clique_eqs(3)_ 1
     x(48) c_u_clique_eqs(10)_ 1
     x(48) c_u_clique_eqs(22)_ 1
     x(48) c_u_clique_eqs(26)_ 1
     x(48) c_u_clique_eqs(70)_ 1
     x(48) c_u_clique_eqs(107)_ 1
     x(48) c_u_clique_eqs(108)_ 1
     x(48) c_u_clique_eqs(109)_ 1
     x(48) c_u_clique_eqs(110)_ 1
     x(48) c_u_clique_eqs(111)_ 1
     x(48) c_u_clique_eqs(171)_ 1
     x(48) c_u_clique_eqs(183)_ 1
     x(48) c_u_clique_eqs(191)_ 1
     x(48) c_u_clique_eqs(192)_ 1
     x(48) c_u_clique_eqs(206)_ 1
     x(48) c_u_clique_eqs(209)_ 1
     x(48) c_u_clique_eqs(210)_ 1
     x(48) c_u_clique_eqs(212)_ 1
     x(48) c_u_clique_eqs(233)_ 1
     x(48) c_u_clique_eqs(249)_ 1
     x(48) c_u_clique_eqs(251)_ 1
     x(48) c_u_clique_eqs(264)_ 1
     x(48) c_u_clique_eqs(274)_ 1
     x(48) c_u_clique_eqs(275)_ 1
     x(48) c_u_clique_eqs(276)_ 1
     x(48) c_u_clique_eqs(304)_ 1
     x(48) c_u_clique_eqs(317)_ 1
     x(48) c_u_clique_eqs(326)_ 1
     x(48) c_u_clique_eqs(327)_ 1
     x(48) c_u_clique_eqs(328)_ 1
     x(49) obj -9.7300000000000004
     x(49) c_u_edge_eqs(50)_ 1
     x(49) c_u_edge_eqs(69)_ 1
     x(49) c_u_edge_eqs(93)_ 1
     x(49) c_u_edge_eqs(114)_ 1
     x(49) c_u_edge_eqs(163)_ 1
     x(49) c_u_edge_eqs(185)_ 1
     x(49) c_u_edge_eqs(219)_ 1
     x(49) c_u_edge_eqs(282)_ 1
     x(49) c_u_edge_eqs(317)_ 1
     x(49) c_u_edge_eqs(352)_ 1
     x(49) c_u_edge_eqs(367)_ 1
     x(49) c_u_edge_eqs(432)_ 1
     x(49) c_u_edge_eqs(453)_ 1
     x(49) c_u_edge_eqs(571)_ 1
     x(49) c_u_edge_eqs(587)_ 1
     x(49) c_u_clique_eqs(17)_ 1
     x(49) c_u_clique_eqs(99)_ 1
     x(49) c_u_clique_eqs(112)_ 1
     x(49) c_u_clique_eqs(114)_ 1
     x(49) c_u_clique_eqs(115)_ 1
     x(49) c_u_clique_eqs(116)_ 1
     x(49) c_u_clique_eqs(140)_ 1
     x(49) c_u_clique_eqs(181)_ 1
     x(49) c_u_clique_eqs(232)_ 1
     x(49) c_u_clique_eqs(234)_ 1
     x(49) c_u_clique_eqs(237)_ 1
     x(49) c_u_clique_eqs(239)_ 1
     x(49) c_u_clique_eqs(241)_ 1
     x(49) c_u_clique_eqs(304)_ 1
RHS
     RHS c_u_edge_eqs(1)_ 1
     RHS c_u_edge_eqs(2)_ 1
     RHS c_u_edge_eqs(3)_ 1
     RHS c_u_edge_eqs(4)_ 1
     RHS c_u_edge_eqs(5)_ 1
     RHS c_u_edge_eqs(6)_ 1
     RHS c_u_edge_eqs(7)_ 1
     RHS c_u_edge_eqs(8)_ 1
     RHS c_u_edge_eqs(9)_ 1
     RHS c_u_edge_eqs(10)_ 1
     RHS c_u_edge_eqs(11)_ 1
     RHS c_u_edge_eqs(12)_ 1
     RHS c_u_edge_eqs(13)_ 1
     RHS c_u_edge_eqs(14)_ 1
     RHS c_u_edge_eqs(15)_ 1
     RHS c_u_edge_eqs(16)_ 1
     RHS c_u_edge_eqs(17)_ 1
     RHS c_u_edge_eqs(18)_ 1
     RHS c_u_edge_eqs(19)_ 1
     RHS c_u_edge_eqs(20)_ 1
     RHS c_u_edge_eqs(21)_ 1
     RHS c_u_edge_eqs(22)_ 1
     RHS c_u_edge_eqs(23)_ 1
     RHS c_u_edge_eqs(24)_ 1
     RHS c_u_edge_eqs(25)_ 1
     RHS c_u_edge_eqs(26)_ 1
     RHS c_u_edge_eqs(27)_ 1
     RHS c_u_edge_eqs(28)_ 1
     RHS c_u_edge_eqs(29)_ 1
     RHS c_u_edge_eqs(30)_ 1
     RHS c_u_edge_eqs(31)_ 1
     RHS c_u_edge_eqs(32)_ 1
     RHS c_u_edge_eqs(33)_ 1
     RHS c_u_edge_eqs(34)_ 1
     RHS c_u_edge_eqs(35)_ 1
     RHS c_u_edge_eqs(36)_ 1
     RHS c_u_edge_eqs(37)_ 1
     RHS c_u_edge_eqs(38)_ 1
     RHS c_u_edge_eqs(39)_ 1
     RHS c_u_edge_eqs(40)_ 1
     RHS c_u_edge_eqs(41)_ 1
     RHS c_u_edge_eqs(42)_ 1
     RHS c_u_edge_eqs(43)_ 1
     RHS c_u_edge_eqs(44)_ 1
     RHS c_u_edge_eqs(45)_ 1
     RHS c_u_edge_eqs(46)_ 1
     RHS c_u_edge_eqs(47)_ 1
     RHS c_u_edge_eqs(48)_ 1
     RHS c_u_edge_eqs(49)_ 1
     RHS c_u_edge_eqs(50)_ 1
     RHS c_u_edge_eqs(51)_ 1
     RHS c_u_edge_eqs(52)_ 1
     RHS c_u_edge_eqs(53)_ 1
     RHS c_u_edge_eqs(54)_ 1
     RHS c_u_edge_eqs(55)_ 1
     RHS c_u_edge_eqs(56)_ 1
     RHS c_u_edge_eqs(57)_ 1
     RHS c_u_edge_eqs(58)_ 1
     RHS c_u_edge_eqs(59)_ 1
     RHS c_u_edge_eqs(60)_ 1
     RHS c_u_edge_eqs(61)_ 1
     RHS c_u_edge_eqs(62)_ 1
     RHS c_u_edge_eqs(63)_ 1
     RHS c_u_edge_eqs(64)_ 1
     RHS c_u_edge_eqs(65)_ 1
     RHS c_u_edge_eqs(66)_ 1
     RHS c_u_edge_eqs(67)_ 1
     RHS c_u_edge_eqs(68)_ 1
     RHS c_u_edge_eqs(69)_ 1
     RHS c_u_edge_eqs(70)_ 1
     RHS c_u_edge_eqs(71)_ 1
     RHS c_u_edge_eqs(72)_ 1
     RHS c_u_edge_eqs(73)_ 1
     RHS c_u_edge_eqs(74)_ 1
     RHS c_u_edge_eqs(75)_ 1
     RHS c_u_edge_eqs(76)_ 1
     RHS c_u_edge_eqs(77)_ 1
     RHS c_u_edge_eqs(78)_ 1
     RHS c_u_edge_eqs(79)_ 1
     RHS c_u_edge_eqs(80)_ 1
     RHS c_u_edge_eqs(81)_ 1
     RHS c_u_edge_eqs(82)_ 1
     RHS c_u_edge_eqs(83)_ 1
     RHS c_u_edge_eqs(84)_ 1
     RHS c_u_edge_eqs(85)_ 1
     RHS c_u_edge_eqs(86)_ 1
     RHS c_u_edge_eqs(87)_ 1
     RHS c_u_edge_eqs(88)_ 1
     RHS c_u_edge_eqs(89)_ 1
     RHS c_u_edge_eqs(90)_ 1
     RHS c_u_edge_eqs(91)_ 1
     RHS c_u_edge_eqs(92)_ 1
     RHS c_u_edge_eqs(93)_ 1
     RHS c_u_edge_eqs(94)_ 1
     RHS c_u_edge_eqs(95)_ 1
     RHS c_u_edge_eqs(96)_ 1
     RHS c_u_edge_eqs(97)_ 1
     RHS c_u_edge_eqs(98)_ 1
     RHS c_u_edge_eqs(99)_ 1
     RHS c_u_edge_eqs(100)_ 1
     RHS c_u_edge_eqs(101)_ 1
     RHS c_u_edge_eqs(102)_ 1
     RHS c_u_edge_eqs(103)_ 1
     RHS c_u_edge_eqs(104)_ 1
     RHS c_u_edge_eqs(105)_ 1
     RHS c_u_edge_eqs(106)_ 1
     RHS c_u_edge_eqs(107)_ 1
     RHS c_u_edge_eqs(108)_ 1
     RHS c_u_edge_eqs(109)_ 1
     RHS c_u_edge_eqs(110)_ 1
     RHS c_u_edge_eqs(111)_ 1
     RHS c_u_edge_eqs(112)_ 1
     RHS c_u_edge_eqs(113)_ 1
     RHS c_u_edge_eqs(114)_ 1
     RHS c_u_edge_eqs(115)_ 1
     RHS c_u_edge_eqs(116)_ 1
     RHS c_u_edge_eqs(117)_ 1
     RHS c_u_edge_eqs(118)_ 1
     RHS c_u_edge_eqs(119)_ 1
     RHS c_u_edge_eqs(120)_ 1
     RHS c_u_edge_eqs(121)_ 1
     RHS c_u_edge_eqs(122)_ 1
     RHS c_u_edge_eqs(123)_ 1
     RHS c_u_edge_eqs(124)_ 1
     RHS c_u_edge_eqs(125)_ 1
     RHS c_u_edge_eqs(126)_ 1
     RHS c_u_edge_eqs(127)_ 1
     RHS c_u_edge_eqs(128)_ 1
     RHS c_u_edge_eqs(129)_ 1
     RHS c_u_edge_eqs(130)_ 1
     RHS c_u_edge_eqs(131)_ 1
     RHS c_u_edge_eqs(132)_ 1
     RHS c_u_edge_eqs(133)_ 1
     RHS c_u_edge_eqs(134)_ 1
     RHS c_u_edge_eqs(135)_ 1
     RHS c_u_edge_eqs(136)_ 1
     RHS c_u_edge_eqs(137)_ 1
     RHS c_u_edge_eqs(138)_ 1
     RHS c_u_edge_eqs(139)_ 1
     RHS c_u_edge_eqs(140)_ 1
     RHS c_u_edge_eqs(141)_ 1
     RHS c_u_edge_eqs(142)_ 1
     RHS c_u_edge_eqs(143)_ 1
     RHS c_u_edge_eqs(144)_ 1
     RHS c_u_edge_eqs(145)_ 1
     RHS c_u_edge_eqs(146)_ 1
     RHS c_u_edge_eqs(147)_ 1
     RHS c_u_edge_eqs(148)_ 1
     RHS c_u_edge_eqs(149)_ 1
     RHS c_u_edge_eqs(150)_ 1
     RHS c_u_edge_eqs(151)_ 1
     RHS c_u_edge_eqs(152)_ 1
     RHS c_u_edge_eqs(153)_ 1
     RHS c_u_edge_eqs(154)_ 1
     RHS c_u_edge_eqs(155)_ 1
     RHS c_u_edge_eqs(156)_ 1
     RHS c_u_edge_eqs(157)_ 1
     RHS c_u_edge_eqs(158)_ 1
     RHS c_u_edge_eqs(159)_ 1
     RHS c_u_edge_eqs(160)_ 1
     RHS c_u_edge_eqs(161)_ 1
     RHS c_u_edge_eqs(162)_ 1
     RHS c_u_edge_eqs(163)_ 1
     RHS c_u_edge_eqs(164)_ 1
     RHS c_u_edge_eqs(165)_ 1
     RHS c_u_edge_eqs(166)_ 1
     RHS c_u_edge_eqs(167)_ 1
     RHS c_u_edge_eqs(168)_ 1
     RHS c_u_edge_eqs(169)_ 1
     RHS c_u_edge_eqs(170)_ 1
     RHS c_u_edge_eqs(171)_ 1
     RHS c_u_edge_eqs(172)_ 1
     RHS c_u_edge_eqs(173)_ 1
     RHS c_u_edge_eqs(174)_ 1
     RHS c_u_edge_eqs(175)_ 1
     RHS c_u_edge_eqs(176)_ 1
     RHS c_u_edge_eqs(177)_ 1
     RHS c_u_edge_eqs(178)_ 1
     RHS c_u_edge_eqs(179)_ 1
     RHS c_u_edge_eqs(180)_ 1
     RHS c_u_edge_eqs(181)_ 1
     RHS c_u_edge_eqs(182)_ 1
     RHS c_u_edge_eqs(183)_ 1
     RHS c_u_edge_eqs(184)_ 1
     RHS c_u_edge_eqs(185)_ 1
     RHS c_u_edge_eqs(186)_ 1
     RHS c_u_edge_eqs(187)_ 1
     RHS c_u_edge_eqs(188)_ 1
     RHS c_u_edge_eqs(189)_ 1
     RHS c_u_edge_eqs(190)_ 1
     RHS c_u_edge_eqs(191)_ 1
     RHS c_u_edge_eqs(192)_ 1
     RHS c_u_edge_eqs(193)_ 1
     RHS c_u_edge_eqs(194)_ 1
     RHS c_u_edge_eqs(195)_ 1
     RHS c_u_edge_eqs(196)_ 1
     RHS c_u_edge_eqs(197)_ 1
     RHS c_u_edge_eqs(198)_ 1
     RHS c_u_edge_eqs(199)_ 1
     RHS c_u_edge_eqs(200)_ 1
     RHS c_u_edge_eqs(201)_ 1
     RHS c_u_edge_eqs(202)_ 1
     RHS c_u_edge_eqs(203)_ 1
     RHS c_u_edge_eqs(204)_ 1
     RHS c_u_edge_eqs(205)_ 1
     RHS c_u_edge_eqs(206)_ 1
     RHS c_u_edge_eqs(207)_ 1
     RHS c_u_edge_eqs(208)_ 1
     RHS c_u_edge_eqs(209)_ 1
     RHS c_u_edge_eqs(210)_ 1
     RHS c_u_edge_eqs(211)_ 1
     RHS c_u_edge_eqs(212)_ 1
     RHS c_u_edge_eqs(213)_ 1
     RHS c_u_edge_eqs(214)_ 1
     RHS c_u_edge_eqs(215)_ 1
     RHS c_u_edge_eqs(216)_ 1
     RHS c_u_edge_eqs(217)_ 1
     RHS c_u_edge_eqs(218)_ 1
     RHS c_u_edge_eqs(219)_ 1
     RHS c_u_edge_eqs(220)_ 1
     RHS c_u_edge_eqs(221)_ 1
     RHS c_u_edge_eqs(222)_ 1
     RHS c_u_edge_eqs(223)_ 1
     RHS c_u_edge_eqs(224)_ 1
     RHS c_u_edge_eqs(225)_ 1
     RHS c_u_edge_eqs(226)_ 1
     RHS c_u_edge_eqs(227)_ 1
     RHS c_u_edge_eqs(228)_ 1
     RHS c_u_edge_eqs(229)_ 1
     RHS c_u_edge_eqs(230)_ 1
     RHS c_u_edge_eqs(231)_ 1
     RHS c_u_edge_eqs(232)_ 1
     RHS c_u_edge_eqs(233)_ 1
     RHS c_u_edge_eqs(234)_ 1
     RHS c_u_edge_eqs(235)_ 1
     RHS c_u_edge_eqs(236)_ 1
     RHS c_u_edge_eqs(237)_ 1
     RHS c_u_edge_eqs(238)_ 1
     RHS c_u_edge_eqs(239)_ 1
     RHS c_u_edge_eqs(240)_ 1
     RHS c_u_edge_eqs(241)_ 1
     RHS c_u_edge_eqs(242)_ 1
     RHS c_u_edge_eqs(243)_ 1
     RHS c_u_edge_eqs(244)_ 1
     RHS c_u_edge_eqs(245)_ 1
     RHS c_u_edge_eqs(246)_ 1
     RHS c_u_edge_eqs(247)_ 1
     RHS c_u_edge_eqs(248)_ 1
     RHS c_u_edge_eqs(249)_ 1
     RHS c_u_edge_eqs(250)_ 1
     RHS c_u_edge_eqs(251)_ 1
     RHS c_u_edge_eqs(252)_ 1
     RHS c_u_edge_eqs(253)_ 1
     RHS c_u_edge_eqs(254)_ 1
     RHS c_u_edge_eqs(255)_ 1
     RHS c_u_edge_eqs(256)_ 1
     RHS c_u_edge_eqs(257)_ 1
     RHS c_u_edge_eqs(258)_ 1
     RHS c_u_edge_eqs(259)_ 1
     RHS c_u_edge_eqs(260)_ 1
     RHS c_u_edge_eqs(261)_ 1
     RHS c_u_edge_eqs(262)_ 1
     RHS c_u_edge_eqs(263)_ 1
     RHS c_u_edge_eqs(264)_ 1
     RHS c_u_edge_eqs(265)_ 1
     RHS c_u_edge_eqs(266)_ 1
     RHS c_u_edge_eqs(267)_ 1
     RHS c_u_edge_eqs(268)_ 1
     RHS c_u_edge_eqs(269)_ 1
     RHS c_u_edge_eqs(270)_ 1
     RHS c_u_edge_eqs(271)_ 1
     RHS c_u_edge_eqs(272)_ 1
     RHS c_u_edge_eqs(273)_ 1
     RHS c_u_edge_eqs(274)_ 1
     RHS c_u_edge_eqs(275)_ 1
     RHS c_u_edge_eqs(276)_ 1
     RHS c_u_edge_eqs(277)_ 1
     RHS c_u_edge_eqs(278)_ 1
     RHS c_u_edge_eqs(279)_ 1
     RHS c_u_edge_eqs(280)_ 1
     RHS c_u_edge_eqs(281)_ 1
     RHS c_u_edge_eqs(282)_ 1
     RHS c_u_edge_eqs(283)_ 1
     RHS c_u_edge_eqs(284)_ 1
     RHS c_u_edge_eqs(285)_ 1
     RHS c_u_edge_eqs(286)_ 1
     RHS c_u_edge_eqs(287)_ 1
     RHS c_u_edge_eqs(288)_ 1
     RHS c_u_edge_eqs(289)_ 1
     RHS c_u_edge_eqs(290)_ 1
     RHS c_u_edge_eqs(291)_ 1
     RHS c_u_edge_eqs(292)_ 1
     RHS c_u_edge_eqs(293)_ 1
     RHS c_u_edge_eqs(294)_ 1
     RHS c_u_edge_eqs(295)_ 1
     RHS c_u_edge_eqs(296)_ 1
     RHS c_u_edge_eqs(297)_ 1
     RHS c_u_edge_eqs(298)_ 1
     RHS c_u_edge_eqs(299)_ 1
     RHS c_u_edge_eqs(300)_ 1
     RHS c_u_edge_eqs(301)_ 1
     RHS c_u_edge_eqs(302)_ 1
     RHS c_u_edge_eqs(303)_ 1
     RHS c_u_edge_eqs(304)_ 1
     RHS c_u_edge_eqs(305)_ 1
     RHS c_u_edge_eqs(306)_ 1
     RHS c_u_edge_eqs(307)_ 1
     RHS c_u_edge_eqs(308)_ 1
     RHS c_u_edge_eqs(309)_ 1
     RHS c_u_edge_eqs(310)_ 1
     RHS c_u_edge_eqs(311)_ 1
     RHS c_u_edge_eqs(312)_ 1
     RHS c_u_edge_eqs(313)_ 1
     RHS c_u_edge_eqs(314)_ 1
     RHS c_u_edge_eqs(315)_ 1
     RHS c_u_edge_eqs(316)_ 1
     RHS c_u_edge_eqs(317)_ 1
     RHS c_u_edge_eqs(318)_ 1
     RHS c_u_edge_eqs(319)_ 1
     RHS c_u_edge_eqs(320)_ 1
     RHS c_u_edge_eqs(321)_ 1
     RHS c_u_edge_eqs(322)_ 1
     RHS c_u_edge_eqs(323)_ 1
     RHS c_u_edge_eqs(324)_ 1
     RHS c_u_edge_eqs(325)_ 1
     RHS c_u_edge_eqs(326)_ 1
     RHS c_u_edge_eqs(327)_ 1
     RHS c_u_edge_eqs(328)_ 1
     RHS c_u_edge_eqs(329)_ 1
     RHS c_u_edge_eqs(330)_ 1
     RHS c_u_edge_eqs(331)_ 1
     RHS c_u_edge_eqs(332)_ 1
     RHS c_u_edge_eqs(333)_ 1
     RHS c_u_edge_eqs(334)_ 1
     RHS c_u_edge_eqs(335)_ 1
     RHS c_u_edge_eqs(336)_ 1
     RHS c_u_edge_eqs(337)_ 1
     RHS c_u_edge_eqs(338)_ 1
     RHS c_u_edge_eqs(339)_ 1
     RHS c_u_edge_eqs(340)_ 1
     RHS c_u_edge_eqs(341)_ 1
     RHS c_u_edge_eqs(342)_ 1
     RHS c_u_edge_eqs(343)_ 1
     RHS c_u_edge_eqs(344)_ 1
     RHS c_u_edge_eqs(345)_ 1
     RHS c_u_edge_eqs(346)_ 1
     RHS c_u_edge_eqs(347)_ 1
     RHS c_u_edge_eqs(348)_ 1
     RHS c_u_edge_eqs(349)_ 1
     RHS c_u_edge_eqs(350)_ 1
     RHS c_u_edge_eqs(351)_ 1
     RHS c_u_edge_eqs(352)_ 1
     RHS c_u_edge_eqs(353)_ 1
     RHS c_u_edge_eqs(354)_ 1
     RHS c_u_edge_eqs(355)_ 1
     RHS c_u_edge_eqs(356)_ 1
     RHS c_u_edge_eqs(357)_ 1
     RHS c_u_edge_eqs(358)_ 1
     RHS c_u_edge_eqs(359)_ 1
     RHS c_u_edge_eqs(360)_ 1
     RHS c_u_edge_eqs(361)_ 1
     RHS c_u_edge_eqs(362)_ 1
     RHS c_u_edge_eqs(363)_ 1
     RHS c_u_edge_eqs(364)_ 1
     RHS c_u_edge_eqs(365)_ 1
     RHS c_u_edge_eqs(366)_ 1
     RHS c_u_edge_eqs(367)_ 1
     RHS c_u_edge_eqs(368)_ 1
     RHS c_u_edge_eqs(369)_ 1
     RHS c_u_edge_eqs(370)_ 1
     RHS c_u_edge_eqs(371)_ 1
     RHS c_u_edge_eqs(372)_ 1
     RHS c_u_edge_eqs(373)_ 1
     RHS c_u_edge_eqs(374)_ 1
     RHS c_u_edge_eqs(375)_ 1
     RHS c_u_edge_eqs(376)_ 1
     RHS c_u_edge_eqs(377)_ 1
     RHS c_u_edge_eqs(378)_ 1
     RHS c_u_edge_eqs(379)_ 1
     RHS c_u_edge_eqs(380)_ 1
     RHS c_u_edge_eqs(381)_ 1
     RHS c_u_edge_eqs(382)_ 1
     RHS c_u_edge_eqs(383)_ 1
     RHS c_u_edge_eqs(384)_ 1
     RHS c_u_edge_eqs(385)_ 1
     RHS c_u_edge_eqs(386)_ 1
     RHS c_u_edge_eqs(387)_ 1
     RHS c_u_edge_eqs(388)_ 1
     RHS c_u_edge_eqs(389)_ 1
     RHS c_u_edge_eqs(390)_ 1
     RHS c_u_edge_eqs(391)_ 1
     RHS c_u_edge_eqs(392)_ 1
     RHS c_u_edge_eqs(393)_ 1
     RHS c_u_edge_eqs(394)_ 1
     RHS c_u_edge_eqs(395)_ 1
     RHS c_u_edge_eqs(396)_ 1
     RHS c_u_edge_eqs(397)_ 1
     RHS c_u_edge_eqs(398)_ 1
     RHS c_u_edge_eqs(399)_ 1
     RHS c_u_edge_eqs(400)_ 1
     RHS c_u_edge_eqs(401)_ 1
     RHS c_u_edge_eqs(402)_ 1
     RHS c_u_edge_eqs(403)_ 1
     RHS c_u_edge_eqs(404)_ 1
     RHS c_u_edge_eqs(405)_ 1
     RHS c_u_edge_eqs(406)_ 1
     RHS c_u_edge_eqs(407)_ 1
     RHS c_u_edge_eqs(408)_ 1
     RHS c_u_edge_eqs(409)_ 1
     RHS c_u_edge_eqs(410)_ 1
     RHS c_u_edge_eqs(411)_ 1
     RHS c_u_edge_eqs(412)_ 1
     RHS c_u_edge_eqs(413)_ 1
     RHS c_u_edge_eqs(414)_ 1
     RHS c_u_edge_eqs(415)_ 1
     RHS c_u_edge_eqs(416)_ 1
     RHS c_u_edge_eqs(417)_ 1
     RHS c_u_edge_eqs(418)_ 1
     RHS c_u_edge_eqs(419)_ 1
     RHS c_u_edge_eqs(420)_ 1
     RHS c_u_edge_eqs(421)_ 1
     RHS c_u_edge_eqs(422)_ 1
     RHS c_u_edge_eqs(423)_ 1
     RHS c_u_edge_eqs(424)_ 1
     RHS c_u_edge_eqs(425)_ 1
     RHS c_u_edge_eqs(426)_ 1
     RHS c_u_edge_eqs(427)_ 1
     RHS c_u_edge_eqs(428)_ 1
     RHS c_u_edge_eqs(429)_ 1
     RHS c_u_edge_eqs(430)_ 1
     RHS c_u_edge_eqs(431)_ 1
     RHS c_u_edge_eqs(432)_ 1
     RHS c_u_edge_eqs(433)_ 1
     RHS c_u_edge_eqs(434)_ 1
     RHS c_u_edge_eqs(435)_ 1
     RHS c_u_edge_eqs(436)_ 1
     RHS c_u_edge_eqs(437)_ 1
     RHS c_u_edge_eqs(438)_ 1
     RHS c_u_edge_eqs(439)_ 1
     RHS c_u_edge_eqs(440)_ 1
     RHS c_u_edge_eqs(441)_ 1
     RHS c_u_edge_eqs(442)_ 1
     RHS c_u_edge_eqs(443)_ 1
     RHS c_u_edge_eqs(444)_ 1
     RHS c_u_edge_eqs(445)_ 1
     RHS c_u_edge_eqs(446)_ 1
     RHS c_u_edge_eqs(447)_ 1
     RHS c_u_edge_eqs(448)_ 1
     RHS c_u_edge_eqs(449)_ 1
     RHS c_u_edge_eqs(450)_ 1
     RHS c_u_edge_eqs(451)_ 1
     RHS c_u_edge_eqs(452)_ 1
     RHS c_u_edge_eqs(453)_ 1
     RHS c_u_edge_eqs(454)_ 1
     RHS c_u_edge_eqs(455)_ 1
     RHS c_u_edge_eqs(456)_ 1
     RHS c_u_edge_eqs(457)_ 1
     RHS c_u_edge_eqs(458)_ 1
     RHS c_u_edge_eqs(459)_ 1
     RHS c_u_edge_eqs(460)_ 1
     RHS c_u_edge_eqs(461)_ 1
     RHS c_u_edge_eqs(462)_ 1
     RHS c_u_edge_eqs(463)_ 1
     RHS c_u_edge_eqs(464)_ 1
     RHS c_u_edge_eqs(465)_ 1
     RHS c_u_edge_eqs(466)_ 1
     RHS c_u_edge_eqs(467)_ 1
     RHS c_u_edge_eqs(468)_ 1
     RHS c_u_edge_eqs(469)_ 1
     RHS c_u_edge_eqs(470)_ 1
     RHS c_u_edge_eqs(471)_ 1
     RHS c_u_edge_eqs(472)_ 1
     RHS c_u_edge_eqs(473)_ 1
     RHS c_u_edge_eqs(474)_ 1
     RHS c_u_edge_eqs(475)_ 1
     RHS c_u_edge_eqs(476)_ 1
     RHS c_u_edge_eqs(477)_ 1
     RHS c_u_edge_eqs(478)_ 1
     RHS c_u_edge_eqs(479)_ 1
     RHS c_u_edge_eqs(480)_ 1
     RHS c_u_edge_eqs(481)_ 1
     RHS c_u_edge_eqs(482)_ 1
     RHS c_u_edge_eqs(483)_ 1
     RHS c_u_edge_eqs(484)_ 1
     RHS c_u_edge_eqs(485)_ 1
     RHS c_u_edge_eqs(486)_ 1
     RHS c_u_edge_eqs(487)_ 1
     RHS c_u_edge_eqs(488)_ 1
     RHS c_u_edge_eqs(489)_ 1
     RHS c_u_edge_eqs(490)_ 1
     RHS c_u_edge_eqs(491)_ 1
     RHS c_u_edge_eqs(492)_ 1
     RHS c_u_edge_eqs(493)_ 1
     RHS c_u_edge_eqs(494)_ 1
     RHS c_u_edge_eqs(495)_ 1
     RHS c_u_edge_eqs(496)_ 1
     RHS c_u_edge_eqs(497)_ 1
     RHS c_u_edge_eqs(498)_ 1
     RHS c_u_edge_eqs(499)_ 1
     RHS c_u_edge_eqs(500)_ 1
     RHS c_u_edge_eqs(501)_ 1
     RHS c_u_edge_eqs(502)_ 1
     RHS c_u_edge_eqs(503)_ 1
     RHS c_u_edge_eqs(504)_ 1
     RHS c_u_edge_eqs(505)_ 1
     RHS c_u_edge_eqs(506)_ 1
     RHS c_u_edge_eqs(507)_ 1
     RHS c_u_edge_eqs(508)_ 1
     RHS c_u_edge_eqs(509)_ 1
     RHS c_u_edge_eqs(510)_ 1
     RHS c_u_edge_eqs(511)_ 1
     RHS c_u_edge_eqs(512)_ 1
     RHS c_u_edge_eqs(513)_ 1
     RHS c_u_edge_eqs(514)_ 1
     RHS c_u_edge_eqs(515)_ 1
     RHS c_u_edge_eqs(516)_ 1
     RHS c_u_edge_eqs(517)_ 1
     RHS c_u_edge_eqs(518)_ 1
     RHS c_u_edge_eqs(519)_ 1
     RHS c_u_edge_eqs(520)_ 1
     RHS c_u_edge_eqs(521)_ 1
     RHS c_u_edge_eqs(522)_ 1
     RHS c_u_edge_eqs(523)_ 1
     RHS c_u_edge_eqs(524)_ 1
     RHS c_u_edge_eqs(525)_ 1
     RHS c_u_edge_eqs(526)_ 1
     RHS c_u_edge_eqs(527)_ 1
     RHS c_u_edge_eqs(528)_ 1
     RHS c_u_edge_eqs(529)_ 1
     RHS c_u_edge_eqs(530)_ 1
     RHS c_u_edge_eqs(531)_ 1
     RHS c_u_edge_eqs(532)_ 1
     RHS c_u_edge_eqs(533)_ 1
     RHS c_u_edge_eqs(534)_ 1
     RHS c_u_edge_eqs(535)_ 1
     RHS c_u_edge_eqs(536)_ 1
     RHS c_u_edge_eqs(537)_ 1
     RHS c_u_edge_eqs(538)_ 1
     RHS c_u_edge_eqs(539)_ 1
     RHS c_u_edge_eqs(540)_ 1
     RHS c_u_edge_eqs(541)_ 1
     RHS c_u_edge_eqs(542)_ 1
     RHS c_u_edge_eqs(543)_ 1
     RHS c_u_edge_eqs(544)_ 1
     RHS c_u_edge_eqs(545)_ 1
     RHS c_u_edge_eqs(546)_ 1
     RHS c_u_edge_eqs(547)_ 1
     RHS c_u_edge_eqs(548)_ 1
     RHS c_u_edge_eqs(549)_ 1
     RHS c_u_edge_eqs(550)_ 1
     RHS c_u_edge_eqs(551)_ 1
     RHS c_u_edge_eqs(552)_ 1
     RHS c_u_edge_eqs(553)_ 1
     RHS c_u_edge_eqs(554)_ 1
     RHS c_u_edge_eqs(555)_ 1
     RHS c_u_edge_eqs(556)_ 1
     RHS c_u_edge_eqs(557)_ 1
     RHS c_u_edge_eqs(558)_ 1
     RHS c_u_edge_eqs(559)_ 1
     RHS c_u_edge_eqs(560)_ 1
     RHS c_u_edge_eqs(561)_ 1
     RHS c_u_edge_eqs(562)_ 1
     RHS c_u_edge_eqs(563)_ 1
     RHS c_u_edge_eqs(564)_ 1
     RHS c_u_edge_eqs(565)_ 1
     RHS c_u_edge_eqs(566)_ 1
     RHS c_u_edge_eqs(567)_ 1
     RHS c_u_edge_eqs(568)_ 1
     RHS c_u_edge_eqs(569)_ 1
     RHS c_u_edge_eqs(570)_ 1
     RHS c_u_edge_eqs(571)_ 1
     RHS c_u_edge_eqs(572)_ 1
     RHS c_u_edge_eqs(573)_ 1
     RHS c_u_edge_eqs(574)_ 1
     RHS c_u_edge_eqs(575)_ 1
     RHS c_u_edge_eqs(576)_ 1
     RHS c_u_edge_eqs(577)_ 1
     RHS c_u_edge_eqs(578)_ 1
     RHS c_u_edge_eqs(579)_ 1
     RHS c_u_edge_eqs(580)_ 1
     RHS c_u_edge_eqs(581)_ 1
     RHS c_u_edge_eqs(582)_ 1
     RHS c_u_edge_eqs(583)_ 1
     RHS c_u_edge_eqs(584)_ 1
     RHS c_u_edge_eqs(585)_ 1
     RHS c_u_edge_eqs(586)_ 1
     RHS c_u_edge_eqs(587)_ 1
     RHS c_u_clique_eqs(1)_ 1
     RHS c_u_clique_eqs(2)_ 1
     RHS c_u_clique_eqs(3)_ 1
     RHS c_u_clique_eqs(4)_ 1
     RHS c_u_clique_eqs(5)_ 1
     RHS c_u_clique_eqs(6)_ 1
     RHS c_u_clique_eqs(7)_ 1
     RHS c_u_clique_eqs(8)_ 1
     RHS c_u_clique_eqs(9)_ 1
     RHS c_u_clique_eqs(10)_ 1
     RHS c_u_clique_eqs(11)_ 1
     RHS c_u_clique_eqs(12)_ 1
     RHS c_u_clique_eqs(13)_ 1
     RHS c_u_clique_eqs(14)_ 1
     RHS c_u_clique_eqs(15)_ 1
     RHS c_u_clique_eqs(16)_ 1
     RHS c_u_clique_eqs(17)_ 1
     RHS c_u_clique_eqs(18)_ 1
     RHS c_u_clique_eqs(19)_ 1
     RHS c_u_clique_eqs(20)_ 1
     RHS c_u_clique_eqs(21)_ 1
     RHS c_u_clique_eqs(22)_ 1
     RHS c_u_clique_eqs(23)_ 1
     RHS c_u_clique_eqs(24)_ 1
     RHS c_u_clique_eqs(25)_ 1
     RHS c_u_clique_eqs(26)_ 1
     RHS c_u_clique_eqs(27)_ 1
     RHS c_u_clique_eqs(28)_ 1
     RHS c_u_clique_eqs(29)_ 1
     RHS c_u_clique_eqs(30)_ 1
     RHS c_u_clique_eqs(31)_ 1
     RHS c_u_clique_eqs(32)_ 1
     RHS c_u_clique_eqs(33)_ 1
     RHS c_u_clique_eqs(34)_ 1
     RHS c_u_clique_eqs(35)_ 1
     RHS c_u_clique_eqs(36)_ 1
     RHS c_u_clique_eqs(37)_ 1
     RHS c_u_clique_eqs(38)_ 1
     RHS c_u_clique_eqs(39)_ 1
     RHS c_u_clique_eqs(40)_ 1
     RHS c_u_clique_eqs(41)_ 1
     RHS c_u_clique_eqs(42)_ 1
     RHS c_u_clique_eqs(43)_ 1
     RHS c_u_clique_eqs(44)_ 1
     RHS c_u_clique_eqs(45)_ 1
     RHS c_u_clique_eqs(46)_ 1
     RHS c_u_clique_eqs(47)_ 1
     RHS c_u_clique_eqs(48)_ 1
     RHS c_u_clique_eqs(49)_ 1
     RHS c_u_clique_eqs(50)_ 1
     RHS c_u_clique_eqs(51)_ 1
     RHS c_u_clique_eqs(52)_ 1
     RHS c_u_clique_eqs(53)_ 1
     RHS c_u_clique_eqs(54)_ 1
     RHS c_u_clique_eqs(55)_ 1
     RHS c_u_clique_eqs(56)_ 1
     RHS c_u_clique_eqs(57)_ 1
     RHS c_u_clique_eqs(58)_ 1
     RHS c_u_clique_eqs(59)_ 1
     RHS c_u_clique_eqs(60)_ 1
     RHS c_u_clique_eqs(61)_ 1
     RHS c_u_clique_eqs(62)_ 1
     RHS c_u_clique_eqs(63)_ 1
     RHS c_u_clique_eqs(64)_ 1
     RHS c_u_clique_eqs(65)_ 1
     RHS c_u_clique_eqs(66)_ 1
     RHS c_u_clique_eqs(67)_ 1
     RHS c_u_clique_eqs(68)_ 1
     RHS c_u_clique_eqs(69)_ 1
     RHS c_u_clique_eqs(70)_ 1
     RHS c_u_clique_eqs(71)_ 1
     RHS c_u_clique_eqs(72)_ 1
     RHS c_u_clique_eqs(73)_ 1
     RHS c_u_clique_eqs(74)_ 1
     RHS c_u_clique_eqs(75)_ 1
     RHS c_u_clique_eqs(76)_ 1
     RHS c_u_clique_eqs(77)_ 1
     RHS c_u_clique_eqs(78)_ 1
     RHS c_u_clique_eqs(79)_ 1
     RHS c_u_clique_eqs(80)_ 1
     RHS c_u_clique_eqs(81)_ 1
     RHS c_u_clique_eqs(82)_ 1
     RHS c_u_clique_eqs(83)_ 1
     RHS c_u_clique_eqs(84)_ 1
     RHS c_u_clique_eqs(85)_ 1
     RHS c_u_clique_eqs(86)_ 1
     RHS c_u_clique_eqs(87)_ 1
     RHS c_u_clique_eqs(88)_ 1
     RHS c_u_clique_eqs(89)_ 1
     RHS c_u_clique_eqs(90)_ 1
     RHS c_u_clique_eqs(91)_ 1
     RHS c_u_clique_eqs(92)_ 1
     RHS c_u_clique_eqs(93)_ 1
     RHS c_u_clique_eqs(94)_ 1
     RHS c_u_clique_eqs(95)_ 1
     RHS c_u_clique_eqs(96)_ 1
     RHS c_u_clique_eqs(97)_ 1
     RHS c_u_clique_eqs(98)_ 1
     RHS c_u_clique_eqs(99)_ 1
     RHS c_u_clique_eqs(100)_ 1
     RHS c_u_clique_eqs(101)_ 1
     RHS c_u_clique_eqs(102)_ 1
     RHS c_u_clique_eqs(103)_ 1
     RHS c_u_clique_eqs(104)_ 1
     RHS c_u_clique_eqs(105)_ 1
     RHS c_u_clique_eqs(106)_ 1
     RHS c_u_clique_eqs(107)_ 1
     RHS c_u_clique_eqs(108)_ 1
     RHS c_u_clique_eqs(109)_ 1
     RHS c_u_clique_eqs(110)_ 1
     RHS c_u_clique_eqs(111)_ 1
     RHS c_u_clique_eqs(112)_ 1
     RHS c_u_clique_eqs(113)_ 1
     RHS c_u_clique_eqs(114)_ 1
     RHS c_u_clique_eqs(115)_ 1
     RHS c_u_clique_eqs(116)_ 1
     RHS c_u_clique_eqs(117)_ 1
     RHS c_u_clique_eqs(118)_ 1
     RHS c_u_clique_eqs(119)_ 1
     RHS c_u_clique_eqs(120)_ 1
     RHS c_u_clique_eqs(121)_ 1
     RHS c_u_clique_eqs(122)_ 1
     RHS c_u_clique_eqs(123)_ 1
     RHS c_u_clique_eqs(124)_ 1
     RHS c_u_clique_eqs(125)_ 1
     RHS c_u_clique_eqs(126)_ 1
     RHS c_u_clique_eqs(127)_ 1
     RHS c_u_clique_eqs(128)_ 1
     RHS c_u_clique_eqs(129)_ 1
     RHS c_u_clique_eqs(130)_ 1
     RHS c_u_clique_eqs(131)_ 1
     RHS c_u_clique_eqs(132)_ 1
     RHS c_u_clique_eqs(133)_ 1
     RHS c_u_clique_eqs(134)_ 1
     RHS c_u_clique_eqs(135)_ 1
     RHS c_u_clique_eqs(136)_ 1
     RHS c_u_clique_eqs(137)_ 1
     RHS c_u_clique_eqs(138)_ 1
     RHS c_u_clique_eqs(139)_ 1
     RHS c_u_clique_eqs(140)_ 1
     RHS c_u_clique_eqs(141)_ 1
     RHS c_u_clique_eqs(142)_ 1
     RHS c_u_clique_eqs(143)_ 1
     RHS c_u_clique_eqs(144)_ 1
     RHS c_u_clique_eqs(145)_ 1
     RHS c_u_clique_eqs(146)_ 1
     RHS c_u_clique_eqs(147)_ 1
     RHS c_u_clique_eqs(148)_ 1
     RHS c_u_clique_eqs(149)_ 1
     RHS c_u_clique_eqs(150)_ 1
     RHS c_u_clique_eqs(151)_ 1
     RHS c_u_clique_eqs(152)_ 1
     RHS c_u_clique_eqs(153)_ 1
     RHS c_u_clique_eqs(154)_ 1
     RHS c_u_clique_eqs(155)_ 1
     RHS c_u_clique_eqs(156)_ 1
     RHS c_u_clique_eqs(157)_ 1
     RHS c_u_clique_eqs(158)_ 1
     RHS c_u_clique_eqs(159)_ 1
     RHS c_u_clique_eqs(160)_ 1
     RHS c_u_clique_eqs(161)_ 1
     RHS c_u_clique_eqs(162)_ 1
     RHS c_u_clique_eqs(163)_ 1
     RHS c_u_clique_eqs(164)_ 1
     RHS c_u_clique_eqs(165)_ 1
     RHS c_u_clique_eqs(166)_ 1
     RHS c_u_clique_eqs(167)_ 1
     RHS c_u_clique_eqs(168)_ 1
     RHS c_u_clique_eqs(169)_ 1
     RHS c_u_clique_eqs(170)_ 1
     RHS c_u_clique_eqs(171)_ 1
     RHS c_u_clique_eqs(172)_ 1
     RHS c_u_clique_eqs(173)_ 1
     RHS c_u_clique_eqs(174)_ 1
     RHS c_u_clique_eqs(175)_ 1
     RHS c_u_clique_eqs(176)_ 1
     RHS c_u_clique_eqs(177)_ 1
     RHS c_u_clique_eqs(178)_ 1
     RHS c_u_clique_eqs(179)_ 1
     RHS c_u_clique_eqs(180)_ 1
     RHS c_u_clique_eqs(181)_ 1
     RHS c_u_clique_eqs(182)_ 1
     RHS c_u_clique_eqs(183)_ 1
     RHS c_u_clique_eqs(184)_ 1
     RHS c_u_clique_eqs(185)_ 1
     RHS c_u_clique_eqs(186)_ 1
     RHS c_u_clique_eqs(187)_ 1
     RHS c_u_clique_eqs(188)_ 1
     RHS c_u_clique_eqs(189)_ 1
     RHS c_u_clique_eqs(190)_ 1
     RHS c_u_clique_eqs(191)_ 1
     RHS c_u_clique_eqs(192)_ 1
     RHS c_u_clique_eqs(193)_ 1
     RHS c_u_clique_eqs(194)_ 1
     RHS c_u_clique_eqs(195)_ 1
     RHS c_u_clique_eqs(196)_ 1
     RHS c_u_clique_eqs(197)_ 1
     RHS c_u_clique_eqs(198)_ 1
     RHS c_u_clique_eqs(199)_ 1
     RHS c_u_clique_eqs(200)_ 1
     RHS c_u_clique_eqs(201)_ 1
     RHS c_u_clique_eqs(202)_ 1
     RHS c_u_clique_eqs(203)_ 1
     RHS c_u_clique_eqs(204)_ 1
     RHS c_u_clique_eqs(205)_ 1
     RHS c_u_clique_eqs(206)_ 1
     RHS c_u_clique_eqs(207)_ 1
     RHS c_u_clique_eqs(208)_ 1
     RHS c_u_clique_eqs(209)_ 1
     RHS c_u_clique_eqs(210)_ 1
     RHS c_u_clique_eqs(211)_ 1
     RHS c_u_clique_eqs(212)_ 1
     RHS c_u_clique_eqs(213)_ 1
     RHS c_u_clique_eqs(214)_ 1
     RHS c_u_clique_eqs(215)_ 1
     RHS c_u_clique_eqs(216)_ 1
     RHS c_u_clique_eqs(217)_ 1
     RHS c_u_clique_eqs(218)_ 1
     RHS c_u_clique_eqs(219)_ 1
     RHS c_u_clique_eqs(220)_ 1
     RHS c_u_clique_eqs(221)_ 1
     RHS c_u_clique_eqs(222)_ 1
     RHS c_u_clique_eqs(223)_ 1
     RHS c_u_clique_eqs(224)_ 1
     RHS c_u_clique_eqs(225)_ 1
     RHS c_u_clique_eqs(226)_ 1
     RHS c_u_clique_eqs(227)_ 1
     RHS c_u_clique_eqs(228)_ 1
     RHS c_u_clique_eqs(229)_ 1
     RHS c_u_clique_eqs(230)_ 1
     RHS c_u_clique_eqs(231)_ 1
     RHS c_u_clique_eqs(232)_ 1
     RHS c_u_clique_eqs(233)_ 1
     RHS c_u_clique_eqs(234)_ 1
     RHS c_u_clique_eqs(235)_ 1
     RHS c_u_clique_eqs(236)_ 1
     RHS c_u_clique_eqs(237)_ 1
     RHS c_u_clique_eqs(238)_ 1
     RHS c_u_clique_eqs(239)_ 1
     RHS c_u_clique_eqs(240)_ 1
     RHS c_u_clique_eqs(241)_ 1
     RHS c_u_clique_eqs(242)_ 1
     RHS c_u_clique_eqs(243)_ 1
     RHS c_u_clique_eqs(244)_ 1
     RHS c_u_clique_eqs(245)_ 1
     RHS c_u_clique_eqs(246)_ 1
     RHS c_u_clique_eqs(247)_ 1
     RHS c_u_clique_eqs(248)_ 1
     RHS c_u_clique_eqs(249)_ 1
     RHS c_u_clique_eqs(250)_ 1
     RHS c_u_clique_eqs(251)_ 1
     RHS c_u_clique_eqs(252)_ 1
     RHS c_u_clique_eqs(253)_ 1
     RHS c_u_clique_eqs(254)_ 1
     RHS c_u_clique_eqs(255)_ 1
     RHS c_u_clique_eqs(256)_ 1
     RHS c_u_clique_eqs(257)_ 1
     RHS c_u_clique_eqs(258)_ 1
     RHS c_u_clique_eqs(259)_ 1
     RHS c_u_clique_eqs(260)_ 1
     RHS c_u_clique_eqs(261)_ 1
     RHS c_u_clique_eqs(262)_ 1
     RHS c_u_clique_eqs(263)_ 1
     RHS c_u_clique_eqs(264)_ 1
     RHS c_u_clique_eqs(265)_ 1
     RHS c_u_clique_eqs(266)_ 1
     RHS c_u_clique_eqs(267)_ 1
     RHS c_u_clique_eqs(268)_ 1
     RHS c_u_clique_eqs(269)_ 1
     RHS c_u_clique_eqs(270)_ 1
     RHS c_u_clique_eqs(271)_ 1
     RHS c_u_clique_eqs(272)_ 1
     RHS c_u_clique_eqs(273)_ 1
     RHS c_u_clique_eqs(274)_ 1
     RHS c_u_clique_eqs(275)_ 1
     RHS c_u_clique_eqs(276)_ 1
     RHS c_u_clique_eqs(277)_ 1
     RHS c_u_clique_eqs(278)_ 1
     RHS c_u_clique_eqs(279)_ 1
     RHS c_u_clique_eqs(280)_ 1
     RHS c_u_clique_eqs(281)_ 1
     RHS c_u_clique_eqs(282)_ 1
     RHS c_u_clique_eqs(283)_ 1
     RHS c_u_clique_eqs(284)_ 1
     RHS c_u_clique_eqs(285)_ 1
     RHS c_u_clique_eqs(286)_ 1
     RHS c_u_clique_eqs(287)_ 1
     RHS c_u_clique_eqs(288)_ 1
     RHS c_u_clique_eqs(289)_ 1
     RHS c_u_clique_eqs(290)_ 1
     RHS c_u_clique_eqs(291)_ 1
     RHS c_u_clique_eqs(292)_ 1
     RHS c_u_clique_eqs(293)_ 1
     RHS c_u_clique_eqs(294)_ 1
     RHS c_u_clique_eqs(295)_ 1
     RHS c_u_clique_eqs(296)_ 1
     RHS c_u_clique_eqs(297)_ 1
     RHS c_u_clique_eqs(298)_ 1
     RHS c_u_clique_eqs(299)_ 1
     RHS c_u_clique_eqs(300)_ 1
     RHS c_u_clique_eqs(301)_ 1
     RHS c_u_clique_eqs(302)_ 1
     RHS c_u_clique_eqs(303)_ 1
     RHS c_u_clique_eqs(304)_ 1
     RHS c_u_clique_eqs(305)_ 1
     RHS c_u_clique_eqs(306)_ 1
     RHS c_u_clique_eqs(307)_ 1
     RHS c_u_clique_eqs(308)_ 1
     RHS c_u_clique_eqs(309)_ 1
     RHS c_u_clique_eqs(310)_ 1
     RHS c_u_clique_eqs(311)_ 1
     RHS c_u_clique_eqs(312)_ 1
     RHS c_u_clique_eqs(313)_ 1
     RHS c_u_clique_eqs(314)_ 1
     RHS c_u_clique_eqs(315)_ 1
     RHS c_u_clique_eqs(316)_ 1
     RHS c_u_clique_eqs(317)_ 1
     RHS c_u_clique_eqs(318)_ 1
     RHS c_u_clique_eqs(319)_ 1
     RHS c_u_clique_eqs(320)_ 1
     RHS c_u_clique_eqs(321)_ 1
     RHS c_u_clique_eqs(322)_ 1
     RHS c_u_clique_eqs(323)_ 1
     RHS c_u_clique_eqs(324)_ 1
     RHS c_u_clique_eqs(325)_ 1
     RHS c_u_clique_eqs(326)_ 1
     RHS c_u_clique_eqs(327)_ 1
     RHS c_u_clique_eqs(328)_ 1
     RHS c_u_clique_eqs(329)_ 1
BOUNDS
 BV BOUND x(0)
 BV BOUND x(1)
 BV BOUND x(2)
 BV BOUND x(3)
 BV BOUND x(4)
 BV BOUND x(5)
 BV BOUND x(6)
 BV BOUND x(7)
 BV BOUND x(8)
 BV BOUND x(9)
 BV BOUND x(10)
 BV BOUND x(11)
 BV BOUND x(12)
 BV BOUND x(13)
 BV BOUND x(14)
 BV BOUND x(15)
 BV BOUND x(16)
 BV BOUND x(17)
 BV BOUND x(18)
 BV BOUND x(19)
 BV BOUND x(20)
 BV BOUND x(21)
 BV BOUND x(22)
 BV BOUND x(23)
 BV BOUND x(24)
 BV BOUND x(25)
 BV BOUND x(26)
 BV BOUND x(27)
 BV BOUND x(28)
 BV BOUND x(29)
 BV BOUND x(30)
 BV BOUND x(31)
 BV BOUND x(32)
 BV BOUND x(33)
 BV BOUND x(34)
 BV BOUND x(35)
 BV BOUND x(36)
 BV BOUND x(37)
 BV BOUND x(38)
 BV BOUND x(39)
 BV BOUND x(40)
 BV BOUND x(41)
 BV BOUND x(42)
 BV BOUND x(43)
 BV BOUND x(44)
 BV BOUND x(45)
 BV BOUND x(46)
 BV BOUND x(47)
 BV BOUND x(48)
 BV BOUND x(49)
ENDATA
